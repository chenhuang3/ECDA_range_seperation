
function [ vcpot, dEdV ] = calc_rpa_potential(vks,norb,tsmear,omega_max,...
    q_cluster,q_total,nfreq,x,fd_chi,levelShift,v_LS,use_total_chi,mu,reg_vxc)


fprintf('\n')
fprintf('Enter calc_rpa_potential()...\n');
fprintf('chemical potential: %f\n',mu);
fprintf('omega_max: %12.5f  \nnfreq: %4d\n',omega_max,nfreq);
fprintf('level_shift: %d  \nuse_total_chi: %d\n',levelShift,use_total_chi);

h = x(2)-x(1);
box_len = x(end);
ngrid = size(x,1);
print = false;
nbuffer = 10;

omega_tiny = 1e-6;
analytical_method = true;


%~~~~~~~~~~~~~~~~~~~~~
% compute dE/dV
%~~~~~~~~~~~~~~~~~~~~~
if analytical_method == false
    
    % finite difference method 
    [ dEdV ] = calc_rpa_dEdV(ngrid,norb,omega_max,nfreq,...
        tsmear,q_cluster,x,vks,h,box_len,levelShift,v_LS,mu);
    dEdV_fd = dEdV;
    %  [ pot ] = solve_vxc_lsqr(x,dEdV,levelShift,vks,v_LS,ngrid,norb,box_len,q,tsmear);
    
else
    if (levelShift)
        % cluster
        [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
        [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
    else
        % total system
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
        [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
    end
    
    [dRPA_dev] = compute_dRPA_dPhi(nfreq,omega_max,x,ee,ev,occ,tsmear,mu);
    [dRPA_dee] = compute_dRPA_dEigen(nfreq,omega_max,x,ee,ev,occ,tsmear,mu);
    
    fprintf('\nassembling dE/dV...\n');
    
    % assemble dE/dV
    dEdV_analyt_occ = zeros([ngrid,1]);
    dEdV_analyt_phi = zeros([ngrid,1]);
    
    for ib=1:ngrid-nbuffer
        gf = green(ib,ev,ee,nbuffer);
        
        % part due to dE/dphi * dphi/dV
        dEdV_analyt_phi = dEdV_analyt_phi + ...
            (h*gf*dRPA_dev(:,ib)).*ev(:,ib);
        
        % part due to dE/d(ee) * d(ee)/dV
        dEdV_analyt_occ = dEdV_analyt_occ + ...
            dRPA_dee(ib)*ev(:,ib).^2;
    end
    
    dEdV = dEdV_analyt_phi + dEdV_analyt_occ;
    % figure
    % plot(x,dEdV_fd,'-r',x,dEdV,'bo');
end


%===========================================================================
% compute static KS response:
% chi(r,r') = d rho(r') / d vks(r)
% chi computed from calc_chi0_finite_diff() is different from that
% from calc_chi(), since it has been normalized by the volume element 'h'.
%===========================================================================
if fd_chi
    fprintf('Use finite difference to compute chi_static for integer occ.\n')
    [ chi ] = calc_chi0_finite_diff(norb,box_len,vks,q_cluster,h,tsmear,levelShift,v_LS);
else
    fprintf('Analytical way for computing chi_static.\n')
    if levelShift
        if use_total_chi
            fprintf('\nUse reponse of total system to avoid null space of response of subsystem ***\n');
            [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
            [occ,mu] = get_occ(norb,ee,q_total,tsmear,false);
            [ chi ]  = calc_chi(mu, tsmear, ev, ee, occ, omega_tiny);
        else
            fprintf('*** WARNING **** Use cluster reponse, be aware of its null space!!! *** \n');
            [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
            [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
            [ chi ]  = calc_chi(mu, tsmear, ev, ee, occ, omega_tiny);
        end
    else
        % density partitioning
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
        [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
        [ chi ]  = calc_chi(mu, tsmear, ev, ee, occ, omega_tiny);
    end
end
chi = (chi+chi')/2.0;


%===============================================
% Solve OEP equation
%   dE_dV(r) = \int dr' chi(r,r')*dE/dn(r)
%
% CGLS method with regularization
% http://web.stanford.edu/group/SOL/software/cgls
%===============================================

fprintf('calc_rpa_potential: solve v_rpa using CGLS\n');
fprintf('regularization parameter -> reg_vxc: %f\n',reg_vxc);
tol     = 1e-16;
maxiter = 10000;
pot = cgls(chi,dEdV,reg_vxc,tol,maxiter);
pot = pot/h;
vcpot = pot;

fprintf('done calc_rpa_potential()\n\n');

end


