function [dEXX_dee]  = compute_dEXX_dEigen(x,ev,occ,ee,tsmear)


ngrid = length(x);
nband = size(ev,2);
h = x(2)-x(1);

% make Coulumb matrix
coul = zeros(ngrid);
for q=1:ngrid
    for q2=1:ngrid
        dist = x(q)-x(q2);
        coul(q,q2) = 1.0/sqrt(dist*dist + 1.0);
    end
end

%
% calculate \sum_i fi*(1-fi)
% used for computing d(chemical potential)/d(eigenvalue)
%
dsum = 0.0;
for i=1:nband
    ftmp = occ(i)/2;
    dsum = dsum + ftmp*(1-ftmp);
end

dEXX_dee = zeros([ngrid,1]);

for n=1:nband
    
    fn = occ(n)/2.0;

    % sum over the m index (see notes for details)
    sum_over_m = 0.0;
    for m=1:nband        
        Cnm = 1+sign(ee(n)-ee(m));
        vec1 = ev(:,n).*ev(:,m);
        sum_over_m = sum_over_m + Cnm*vec1'*coul*vec1*h*h;        
    end
    
    for i=1:nband
        fi = occ(i)/2.0;
        dmu_dee = fi*(1-fi)/dsum; % d(chemical potential)/d(ee(i))
        df_dee = fn*(1-fn)/tsmear*(dmu_dee - Kronecker_Delta(i,n));
        dEXX_dee(i,1) = dEXX_dee(i,1) - df_dee * sum_over_m;
    end
    
    
end

end


