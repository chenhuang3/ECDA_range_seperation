function [ chi ] = calc_chi( mu, tsmear, ev, ee, occ, omega )

nband = size(ev,2);
ngrid = size(ev,1);
chi = zeros(ngrid);

% Spin polarized case can be found in
% PHYSICAL REVIEW B 87, 075111 (2013)
% "Random phase approximation applied to solids, molecules,
% and graphene-metal interfaces: From van der Waals to covalent bonding"

% the code below can be made faster by looping j from i to nband


%%%%% the code below does not consider the symmetry of chi  
%%%%% is about 35% slower than the improved code that consider the 
%%%%% symmetry of response function, then it only for debugging purpose 

% for i=1:nband
%     for j=1:nband
%         % static linear response, i should be different from j.
%         if omega==0 && j==i
%             continue
%         end
%         fac  = (occ(i)/2.0-occ(j)/2.0)/(ee(i)-ee(j)-1i*omega);
%         % speed it up, construction of chi is time consuming
%         if abs(fac) < 1e-10
%             continue
%         end
%         vec1 = ev(:,i).*ev(:,j);
%         chi  = chi + fac * vec1*vec1';
%         if isnan(chi)
%             fprintf('chi contains NaN stop!\n ')
%             stop
%         end
%     end
% end
% chi = 2.0*real(chi);  % real part is nonzero
% % non-spin-polarized case,
% % 2.0 is the factor
% return 

for i=1:nband    
    for j=1:i
    
        if (i==j && omega==0)
            %
            % compute the derivative df/dee at ee(i)
            % if omega/=0, we do not have divergence 
            % if omega=0, this is just zero, which is consistent with 
            % first order perturbation theory in which i should not equal
            % to j.
            %
%            f =  occ(i)/2.0;
%            fac_ij = -f*(1-f)/tsmear;
%            fac_ji = fac_ij;
           fprintf('stop! you set omega=0, if you want to compute static response, just set omega to a very small number such as 1e-6\n')
           stop
        else        
            fac_ij  = (occ(i)/2.0-occ(j)/2.0)/(ee(i)-ee(j)-1i*omega);
            fac_ji  = (occ(j)/2.0-occ(i)/2.0)/(ee(j)-ee(i)-1i*omega);
        end
       
        % speed it up if fac_ij and fac_ji are very small
        if abs(fac_ij)<1e-10 &&  abs(fac_ji)<1e-10
            continue
        end
        
        % construct chi
        vec1 = ev(:,i).*ev(:,j);
        if i == j
            chi  = chi + fac_ji * (vec1*vec1');
        else
            chi  = chi + (fac_ij + fac_ji) * (vec1*vec1');
        end
        
        % test of chi contains NaN, should not happen in principle!
        if isnan(chi)
            fprintf('chi contains NaN stop!\n ')
            stop
        end
    end
end


chi = 2.0*real(chi);  % real part is nonzero
                      % non-spin-polarized case,
                      % 2.0 is the factors

                      
                      
                      
end

