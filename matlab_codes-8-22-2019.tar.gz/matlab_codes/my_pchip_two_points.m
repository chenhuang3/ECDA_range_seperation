function [y,dydt] = my_pchip_two_points(x1,x2,y1,y2,yp1,yp2,t)


% following the interpolation section in the ACSI course
h=x2-x1;

alpha = 3/h/h*(yp1+yp2) + 6/h^3*(y1-y2);

% function value
y = -yp1/2/h*((t-x2).^2-h^2) + yp2/2/h*(t-x1).^2 ...
    + alpha*(t-x1).^2.*( (t-x1)/3 - h/2 ) + y1;

% derivative
dydt = -yp1/2/h*2*(t-x2) + yp2/2/h*2*(t-x1) + ...
    alpha*2*(t-x1)*( (t-x1)/3 - h/2 ) + alpha*(t-x1)^2*(1/3);

end
