
%================================================
% make long-range and short-range VC potentials
%================================================


function [Usr, Ulr] = make_Ulr_Usr(ngrid,rc,soft_coul,x)


fprintf('\n\n >>>> make_Ulr_Usr() <<<< \n')
fprintf('make long-range and short-range VC potentials ...\n')
fprintf(' rc:        %f\n',rc)
fprintf(' soft_coul: %f\n',soft_coul)

Ulr = zeros([ngrid,ngrid]);
Usr = zeros([ngrid,ngrid]);

parfor q=1:ngrid
    for q2=1:ngrid
        d = abs(x(q)-x(q2));
        Ulr(q,q2) = vc_long_range(rc,soft_coul,d);
        Usr(q,q2) = vc_short_range(rc,soft_coul,d);
    end
end
