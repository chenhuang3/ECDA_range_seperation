
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute exchange energy (LDA) 
% based on Phys. Chem. Chem. Phys., 2012, 14, 8581�8590
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ex,vexch] = cal_ex (x,rho)

   dx = x(2)-x(1);
   npt = length(rho);
   vexch = zeros([npt,1]);
   
   % f_rho is the function defined in Eq. 7 in 
   % Phys. Chem. Chem. Phys., 2012, 14, 8581�8590
   
   for j=1:npt
      ret = f_rho(rho(j));        % fun(kF)*rho
      eps(j) = -ret/2;            % exchange energy density per particle
      vexch(j) = eps(j) + eps(j) - f_der_rho2(rho(j))/2; % f_der_rho2 = f(kF)*rho^2 
   end
   
   ex = dot(rho, eps)* dx;
end

