clear all
close all


% % start the matlabpool with maximum available workers
% % control how many workers by setting ntasks in your sbatch script
% pc = parcluster('local')
% parpool(pc)


input_file

ksdft

%epp


[ chi ]  = calc_chi(ev, ee, occ, 0.0);

contour(chi)

