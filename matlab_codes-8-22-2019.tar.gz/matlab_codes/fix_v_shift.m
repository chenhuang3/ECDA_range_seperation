function [pot] = fix_v_shift(xc_type,q,ee,ev,tsmear,occ,x,omega_max,nfreq,pot)

norb = length(x);
match_IE = true;
acfd = true;
prt_RPA = false;
h = x(2)-x(1);

fprintf('xc_type: %d (1-EXX, 2-RPA)\n',xc_type);

%
% compute docc_dN and dExx_dN
% we use the finite difference to compute it
% by changing N -> N \pm delta_Q (see paper for formula)
%
if match_IE
    
    delta_Q = min(1e-2,q/2.0);
    
    %%%%%%%%%%%%%%%% (+) %%%%%%%%%%%%
    
    [occ1,mu] = get_occ(norb,ee,q,tsmear,false);
    % EXX
    if xc_type==1
        if acfd
            [exx1] = calc_exx_energy(ev,ee,occ1,x);
        else
            [exx1] = calc_HF_energy(ev,ee,occ1,x);
        end
    end
    % RPA
    if xc_type==2
        [erpa1,eps_tmp] = compute_rpa_energy(...
            omega_max,nfreq,x,ev,ee,occ1,prt_RPA,mu,tsmear);
    end
    
    %%%%%%%%%%%%%%%% (-) %%%%%%%%%%%%%
    
    [occ2,mu] = get_occ(norb,ee,q-delta_Q,tsmear,false);
    if xc_type==1
        if acfd
            [exx2] = calc_exx_energy(ev,ee,occ2,x);
        else
            [exx2] = calc_HF_energy(ev,ee,occ2,x);
        end
    end
    if xc_type==2
        [erpa2,eps_tmp] = compute_rpa_energy(...
            omega_max,nfreq,x,ev,ee,occ2,prt_RPA,mu,tsmear);
    end
    
    if xc_type==1
        docc_dN = (occ1-occ2)/delta_Q;
        dExx_dN = (exx1-exx2)/delta_Q;
    end
    
    if xc_type==2
        docc_dN = (occ1-occ2)/delta_Q;
        dExx_dN = (erpa1-erpa2)/delta_Q;
    end
    fprintf('[exx_pot] match_IE\n')
    
end

% compute vxc_shift
vxcbar_cum = 0.0;
vxcshift   = 0.0;
for ib = 1:norb
    vxc_bar = h*sum(pot.*ev(:,ib).*ev(:,ib));
    vxcbar_cum = vxcbar_cum + vxc_bar*docc_dN(ib);
end
vxcshift = dExx_dN - vxcbar_cum;   % compute vxcshift
pot = pot + vxcshift;         % remove the shift

fprintf('[fix_v_shift] done. v_shift: %f \n\n',vxcshift);


end
