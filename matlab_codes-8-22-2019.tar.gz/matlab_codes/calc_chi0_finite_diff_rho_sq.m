function [chi] = calc_chi0_finite_diff_rho_sq(norb, box_len, vks, q, h, tsmear, levelShift, v_LS)

    fprintf('computing static chi0 using finite difference (the exact way)...\n');
    ngrid = size(vks,1);
    deltaV = 0.001;
    fprintf('finite difference step: %e, total_q: %f\n',deltaV,q);

    %
    % finite difference 
    % we perturb the potential at x_i and measure the density change
    %
    for i=1:ngrid 
        
        vks_tmp    = vks;
        vks_tmp(i) = vks(i) + deltaV;
        if (levelShift) 
            [ee_tmp,ev_tmp]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
        else
            [ee_tmp,ev_tmp]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
        end
        [occ_tmp,mu_tmp] = get_occ(norb,ee_tmp,q,tsmear,false);
        rho1 = sum(ev_tmp.^2*occ_tmp,2);

        vks_tmp    = vks;
        vks_tmp(i) = vks(i) - deltaV;
        if (levelShift) 
            [ee_tmp,ev_tmp]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
        else
            [ee_tmp,ev_tmp]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
        end
        [occ_tmp,mu_tmp] = get_occ(norb,ee_tmp,q,tsmear,false);
        rho2 = sum(ev_tmp.^2*occ_tmp,2);        
        
        %
        % How the boundary condition is consider in the code? 
        % The solve_ks_eq (qm1d) code considers the x(-1) and x(ngrid+1) 
        % as the two boundary points. See the descript on their website 
        %
        % http://www.cond-mat.de/teaching/DFT/qm1d.f 
        %
        % the comment below is from the website 
        %
        % c --- discretized form of kinetic energy operator (incl. boundary cond.)
        % c     f''(x_i) \approx (f(x_{i-1})-2*f(x_i)+f(x_{i+1}))/dx^2
        % c     by dropping terms from outside the mesh, we have chosen boundary
        % c     conditions such that the phi vanishes outside the mesh
        %
        % In that sense, the change of v_KS at x(1) and x(ngrid) 
        % should be multiplied by "h" instead of "h/2".
        % this also means that wavefunction is not zero at x(1) and x(ngrid)
        % but is zero at x(-1) and x(ngrid+1).
        %
        
        chi(:,i) = (rho1.^0.5-rho2.^0.5)/(2*deltaV*h);
    end
    
    % symmetrize chi
    for i=1:ngrid
        for j=1:ngrid
            chi_sym(i,j) = (chi(i,j)+chi(j,i))/2.0;
        end
    end
    
    chi=chi_sym;
    
    fprintf('done static chi0 [symmetrized] \n\n');

end