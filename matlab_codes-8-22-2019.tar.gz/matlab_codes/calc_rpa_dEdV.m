%
% Compute dE_RPA / dvKS using finite difference method 
%
function [ dEdV ] = calc_rpa_dEdV(ngrid,norb,omega_max,nfreq,...
    tsmear,q,x,vks,h,box_len,levelShift,v_LS,mu)
%
% loop over all points in the system
%
dEdV = zeros([ngrid,1]);
deltaV = 0.01;
print = false;

order = 2;

fprintf('\n\nIn calc_rpa_dEdV(). computing dEdV for rpa ...\n');

parfor j = 1:ngrid
    
    %%%%%%%%%% second order finite difference %%%%%%%%  
    if order == 2
        if mod(j,5)==0
            fprintf('[rpa_pot] progress: %4d/%4d  <second order>\n',j,ngrid);
        end               
              
        vks_tmp = vks;
        vks_tmp(j) = vks(j)+deltaV;
        if levelShift
            [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
        else
            [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
        end
        [occ,mu] = get_occ(norb,ee,q,tsmear,false);
        [rpa1]   = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,print,mu,tsmear);
        
        vks_tmp = vks;
        vks_tmp(j) = vks(j)-deltaV;
        if levelShift
            [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
        else
            [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
        end
        [occ,mu] = get_occ(norb,ee,q,tsmear,false);
        [rpa2]   = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,print,mu,tsmear);
        
        dEdV(j,1) = (rpa1-rpa2)/2/deltaV;
    end
    
    
    
    %%%%%%%%%% fourth order finite difference %%%%%%%%%%%
    if (order==4) 
        if mod(j,5)==0
            fprintf('[rpa_pot] progress: %4d/%4d  <4th order>\n',j,ngrid);
        end
        
        vks_tmp = vks;
        vks_tmp(j) = vks(j)+2*deltaV;
        if levelShift
            [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
        else
            [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
        end
        [occ,mu] = get_occ(norb,ee,q,tsmear,false);
        [rpa1]   = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,print,mu,tsmear);
        
        vks_tmp = vks;
        vks_tmp(j) = vks(j)-2*deltaV;
        if levelShift
            [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
        else
            [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
        end
        [occ,mu] = get_occ(norb,ee,q,tsmear,false);
        [rpa2]   = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,print,mu,tsmear);
        
        vks_tmp = vks;
        vks_tmp(j) = vks(j)+deltaV;
        if levelShift
            [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
        else
            [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
        end
        [occ,mu] = get_occ(norb,ee,q,tsmear,false);
        [rpa3]   = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,print,mu,tsmear);
        
        vks_tmp = vks;
        vks_tmp(j) = vks(j)-deltaV;
        if levelShift
            [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
        else
            [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
        end
        [occ,mu] = get_occ(norb,ee,q,tsmear,false);
        [rpa4]   = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,print,mu,tsmear);
        
        dEdV(j,1) = (-rpa1+rpa2+8*rpa3-8*rpa4)/12/deltaV;
        
    end
end

% include the spacing h.
dEdV = dEdV / h;
end



