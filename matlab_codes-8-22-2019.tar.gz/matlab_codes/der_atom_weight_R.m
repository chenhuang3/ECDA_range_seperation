function [dAtomW_dR] = der_atom_weight_R(ngrid,natom,x,coord)


coord_back = coord;
delta = 0.01;
dAtomW_dR = zeros(ngrid,natom,natom); % the first index is grid points 
                                      % the second index is the atom index
                                      % the last index is {R}

for j=1:natom 
    coord = coord_back;
    coord(j) = coord_back(j)+delta;
    [ atom_weight1 ] = becke_aim( natom, coord, x, false );
    
    coord = coord_back;
    coord(j) = coord_back(j)-delta;
    [ atom_weight2 ] = becke_aim( natom, coord, x, false );
    
    dAtomW_dR(:,:,j) = (atom_weight1-atom_weight2)/2/delta;
end


end