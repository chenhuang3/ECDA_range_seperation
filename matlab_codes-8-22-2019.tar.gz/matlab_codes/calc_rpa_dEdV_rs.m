%
% Compute dE_RPA / dvKS using finite difference method
%
function [ dEdV ] = calc_rpa_dEdV_rs(part,Usr,Ulr,ngrid,norb,omega_max,nfreq,...
    tsmear,q,x,vks,h,box_len,levelShift,v_LS,nlambda,rc)


fprintf('\n\nEnter calc_rpa_dEdV_rs() ...\n');
fprintf(' part: %s\n\n',part);


dEdV = zeros([ngrid,1]);
deltaV = 0.01;
print = false;


parfor j = 1:ngrid
    
    %%%%%%%%%% second order finite difference %%%%%%%%
    if mod(j,5)==0
        fprintf(' progress: %4d/%4d  <second order>\n',j,ngrid);
    end
    
    vks_tmp = vks;
    vks_tmp(j) = vks(j)+deltaV;
    if levelShift
        [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
    else
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    end
    [occ,mu] = get_occ(norb,ee,q,tsmear,false);
    [rpa1]   = compute_rpa_energy_rs(part,Usr,Ulr,omega_max,nfreq,x,ev,ee,occ,print,mu,tsmear,nlambda,rc);
    
    vks_tmp = vks;
    vks_tmp(j) = vks(j)-deltaV;
    if levelShift
        [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
    else
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    end
    [occ,mu] = get_occ(norb,ee,q,tsmear,false);
    [rpa2]   = compute_rpa_energy_rs(part,Usr,Ulr,omega_max,nfreq,x,ev,ee,occ,print,mu,tsmear,nlambda,rc);
    
    dEdV(j,1) = (rpa1-rpa2)/2/deltaV;
    
end

% include the spacing h.
dEdV = dEdV / h;
end



