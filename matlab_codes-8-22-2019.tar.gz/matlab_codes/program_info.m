function program_info(fid)

fprintf(fid,'Program started at %s\n\n',datetime('now'));
fprintf(fid,'Revisions:\n');
fprintf(fid,'---------\n');
fprintf(fid,'  OEP equations are now solved using CGLS with reg_lamdba=1e-4\n');
fprintf(fid,'  Harris functional is calculated\n');
fprintf(fid,'  New keywords reg_vxc and reg_z are used to regularize CGLS calculations.\n');
fprintf(fid,'  density mixing is added.\n');
fprintf(fid,'  RPA energy and energy density is defined based on vc^(1/2)*chi*vc^(1/2)\n');
fprintf(fid,'  A sever bug in RPA energy calculations is fixed (4/17/2018)\n');
fprintf(fid,'  MATLAB BFGS fminunc() is used (4/18/2018)\n');
fprintf(fid,'  Local fermi codes are removed. ECDA again is based on system Fermi level.(1/3/2019)\n');
fprintf(fid,'  Full forces are available. (1/3//2018)\n');
fprintf(fid,'  ECDA energy is minimized fully variationally (1/3/2018)\n');
fprintf(fid,'  The freq axis of RPA energy is integrated using scaled Gauss qaud. (1/6/2018)\n');
fprintf(fid,'  Range seperation is added. (7/9/2019)\n');

end
