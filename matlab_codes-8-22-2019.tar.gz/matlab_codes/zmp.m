
% ZMP method ~~~~~~~~~~~~~~
fprintf('ZMP method \n');
vemb = zeros(ngrid,1);
vemb_old2 = zeros(ngrid,1);
vemb_old1 = zeros(ngrid,1);
vemb_old  = zeros(ngrid,1);
for j=1:1000
    [ee_clu,ev_clu] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_clu+vemb);
    [ee_env,ev_env] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_env+vemb);
    [occ_clu,occ_env,Ef_emb] = get_occ_comm(norb,ee_clu,q_clu,ee_env,q_env,tsmear,false);
    rho_clu = sum(ev_clu.^2*occ_clu,2);
    rho_env = sum(ev_env.^2*occ_env,2);
    rho_diff = rho_clu+rho_env-ref_rho;
    
    ke = 0.0;
    for iband = 1:norb
        tmpke = ee_clu(iband) - dot(ev_clu(:,iband),ev_clu(:,iband).*(vks_clu+vemb))*h;
        ke = ke + tmpke*occ_clu(iband);
    end    
    
    %[eh_tmp,vhart_tmp] = cal_hartree(x,rho_diff);
    vhart_tmp = rho_diff;
    
    % anderson mixing
    vemb_old3 = vemb_old2;
    vemb_old2 = vemb_old;
    vemb_old  = vemb;
    vemb      = vhart_tmp*30.0;
    
    resid2 = resid1;            % residual
    resid1 = vemb - vemb_old;   % residual
    
    fprintf('rho_diff: %e  resid: %e  ke: %e\n',norm(rho_diff),norm(resid1),ke);
    if (norm(resid1)<1e-4)
        stop
    end
    
    if j>=3
        anderson_mix = ...
            -dot(resid2,resid1-resid2)/dot(resid1-resid2,resid1-resid2);
        m_beta = 0.02;
        vemb = (vemb_old +m_beta*resid1)*anderson_mix ...
            + (vemb_old2+m_beta*resid2)*(1-anderson_mix);
    else
        fprintf('\n>>>> simple mixing with coeff=0.1 <<<<  \n');
        alpha = 0.999;
        vemb = vemb_old*alpha + (1-alpha)*vemb;
    end
end
figure
plot(x,rho_clu+rho_env,x,ref_rho,x,vemb,x,rho_clu,x,rho_env)