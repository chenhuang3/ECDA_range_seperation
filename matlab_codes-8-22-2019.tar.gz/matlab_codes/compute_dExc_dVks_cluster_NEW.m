%
% compute dExc/dV for RPA and EXX for a cluster
%
% xc_type = 1 => EXX
% xc_type = 2 => RPA
%
function [dEdV,hvec,zg,dExx_dvks_part1,dExx_dvks_part2] = compute_dExc_dVks_cluster_NEW( ...
    range_sep,part,Usr,Ulr,nlambda,rc, ...
    natom,ia,xc_type,xcep_comm_ef,ref_rho,...
    tsmear,mu_system,vac,q_clu,q_env,q_total,...
    box_len,x,atom_weight,dClusterW_dR,dmu_dvks,dRho_dN_clu,dRho_dN_env,...
    deps_dN_clu,vks,vks_clu,vks_env,vemb,clu_weight,env_weight,chi_system,...
    nfreq,omega_max,reg_z)


fprintf('\n\nEnter compute_dExc_dVks_cluster_NEW() for atom %d\n',ia);
fprintf(' part: %s\n',part);
fprintf(' xc_type: %d (1-EXX, 2-RPA)\n',xc_type);
fprintf(' xcep_comm_ef: %d\n',xcep_comm_ef);
fprintf(' reg. parameter for solving z => reg_z: %e\n',reg_z);

ngrid = length(vks);
norb = length(vks);
deltaV = 0.001;
h = x(2)-x(1);
prt_RPA = false;  % print RPA information


% get the response function in matrix form
W_clu = diag(clu_weight(:,ia));
W_env = diag(env_weight(:,ia));

envW = env_weight(:,ia);
cluW = clu_weight(:,ia);


%=========================================
% compute d eps(r')/d vemb(r)
% (with cluster electron number fixed)
%=========================================
fprintf('\nComputing matrix: d eps(x)/d vemb(r) using finite diff method ... \n');
vemb_backup = vemb;
deps_dvks = zeros([ngrid,ngrid]);



%=============================
% loop over all grid points
%=============================
parfor ipt=1:ngrid

    % finite difference
    for id=1:2
        vemb = vemb_backup;
        if id==1
            vemb(ipt) = vemb(ipt) + deltaV;
        else
            vemb(ipt) = vemb(ipt) - deltaV;
        end
        
        % get the cluster
        [ee_clu,ev_clu,occ_clu,mu_clu] = get_cluster(tsmear,...
            vks_clu,vks_env,box_len,x,xcep_comm_ef,q_total,q_clu,q_env,vks,vemb);
        
        % exx and RPA energy density
        if xc_type==1
            [~,eps_tmp] = calc_exx_energy(ev_clu,ee_clu,occ_clu,x);
        end
        if xc_type==2
            if range_sep == false
                [~,eps_tmp] = compute_rpa_energy(omega_max,nfreq,x,...
                    ev_clu,ee_clu,occ_clu,prt_RPA,mu_clu,tsmear);
            else
                [~,eps_tmp] = compute_rpa_energy_rs(part,Usr,Ulr,omega_max,nfreq,x,...
                    ev_clu,ee_clu,occ_clu,prt_RPA,mu_clu,tsmear,nlambda,rc);
            end
        end
        if id==1
            eps1 = eps_tmp;
        else
            eps2 = eps_tmp;
        end        
    end % end of finite difference
    deps_dvks(:,ipt) = (eps1-eps2)/2/(h*deltaV);
    
    
    % progress monitor
    if xc_type==2 && mod(ipt-1,10)==0
        fprintf(' progress [%d/%d]\n',ipt,ngrid)
    end
end

vemb = vemb_backup;
y = atom_weight(:,ia)'*deps_dvks*h;



%=========================
% Part I
%=========================
dExx_dvks_part1 = y'.*cluW;


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% solve the response equations
%  two ways:
%  (1) fix the chemical potential of the entire system
%  (2) fix the electron number in cluster
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[chi_clu,chi_env,chi_tot] = calc_emb_chi_finite_diff(...
    tsmear,norb,box_len,vks_clu,vks_env,xcep_comm_ef,q_total,q_clu,q_env,x,vks,vemb);


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% CGLS methood (conjugate gradient for least squared problems (CGLS))
% for solving large sparse least squares problem
%   |Ax-b|^2+lambda*|x|^2
% see % http://web.stanford.edu/group/SOL/software/lsqr/
% the last term is the Tikhonov regularization.
%
% We therefore need to solve A'*Ax + lambda*I*x = A'*b
%
% Below is the brute force method for CGLS, which just solve
% z = conjgrad(chi_tot'*chi_tot + eye(ngrid)*1e-6,chi_tot'*y');
%
% Here we use the code from http://web.stanford.edu/group/SOL/software/lsqr/
% cgls.m file implements the Hesterns and Stiefel method which do not apply
% the large A matrix consecutively twice on the same vector.
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

tol = 1e-12;
maxiter = 1000;
z = cgls(chi_tot,y',reg_z,tol,maxiter);
z = z/h;



%=====================================
% quantities for force calculations
%=====================================
hvec = y.*(vks'-mu_system-vac);
zg = zeros(natom,1);

for ir = 1:natom % loop over all the atom {R}
    dNclu_dR = dot(ref_rho, dClusterW_dR(:,ia,ir))*h;
    dNenv_dR = dot(ref_rho,-dClusterW_dR(:,ia,ir))*h;
    
    % compute <z,g> in notes
    zg(ir) = ...
        z'*chi_clu*h.*(vks'-mu_system-vac)*  dClusterW_dR(:,ia,ir)*h + ...
        z'*chi_env*h.*(vks'-mu_system-vac)*(-dClusterW_dR(:,ia,ir))*h + ...
        z'*dRho_dN_clu*h*dNclu_dR + ...
        z'*dRho_dN_env*h*dNenv_dR;
end


%=========================
% Part II
%=========================
dExx_dvks_part2 = z'*(chi_system - chi_clu*W_clu - chi_env*W_env)*h;

dExx_dvks_part2b = ...
    - ( z'*chi_clu*h*envW*h*dmu_dvks' ...
    + z'*chi_env*h*cluW*h*dmu_dvks' ...
    + z'*dRho_dN_clu*h*cluW'*chi_system*h ...
    + z'*dRho_dN_env*h*envW'*chi_system*h);


%=========================
% Part III
%=========================
dExx_dvks_part3 = y*envW*h*dmu_dvks';


%===================================
% Part IV: due to dExc/dN_cluster
%===================================
dNclu_dvks = chi_system*cluW*h;
dExx_dvks_part4 = dot(atom_weight(:,ia),deps_dN_clu)*h*dNclu_dvks;


%=========================
% Collect all results
%=========================
dEdV = dExx_dvks_part1'  ...
     + dExx_dvks_part2 + dExx_dvks_part2b ...
     + dExx_dvks_part3 + dExx_dvks_part4';


fprintf('\nsum(dExx/dVks)/ngrid: %e for atom %d\n',sum(dEdV)/ngrid,ia);
fprintf('done compute_dExc_dVks_cluster_NEW()\n\n\n');



end
