function [yfit,dydt] = my_pchip_function(x,y,t)


y1 = y(1);
y2 = y(2);
y3 = y(3);


% slope for x1
yp1 = -3/2*y1 + 2*y2 - 1/2*y3; % forward finite difference (3 points)
% see https://en.wikipedia.org/wiki/Finite_difference_coefficient
yp1_sign = (y(2)-y(1))/(x(2)-x(1));
if yp1*yp1_sign<0
    yp1 = 0;  % just set to zero, if sign differs
    % directly follow the paper by Fritsch and Carlson
    % SIAM Journal on Numerical Analysis, 1980, Vol. 17, No. 2 : pp. 238-246
end

% slope for x2
ytmpL = (y(2)-y(1))/(x(2)-x(1));
ytmpR = (y(3)-y(2))/(x(3)-x(2));
if ytmpR*ytmpL<0 
    yp2 = 0.0;
else
    yp2 = 1/(1/2*(1/ytmpL+1/ytmpR));
end

% slope for x3
yp3 = 0.5*y1 - 2*y2 + 3/2*y3; % forward finite difference (3 points)
% see https://en.wikipedia.org/wiki/Finite_difference_coefficient
yp3_sign = (y(3)-y(2))/(x(3)-x(2));
if yp3*yp3_sign<0
    yp3 = 0;  % just set to zero, if sign differs
    % directly follow the paper by Fritsch and Carlson
    % SIAM Journal on Numerical Analysis, 1980, Vol. 17, No. 2 : pp. 238-246
end


% ============ interpolating =======
% following the interpolation section in the ACSI course
h=x(2)-x(1);
if t>x(2)
    % reset the region
    yp1 = yp2;
    yp2 = yp3;
    y1 = y(2);
    y2 = y(3);
    x1 = x(2);
    x2 = x(3);
else
    x1 = x(1);
    x2 = x(2);
end

alpha = 3/h/h*(yp1+yp2) + 6/h^3*(y1-y2);

% function value
yfit = -yp1/2/h*((t-x2).^2-h^2) + yp2/2/h*(t-x1).^2 ...
    + alpha*(t-x1).^2.*( (t-x1)/3 - h/2 ) + y1;

% derivative
dydt = -yp1/2/h*2*(t-x2) + yp2/2/h*2*(t-x1) + ...
    alpha*2*(t-x1)*( (t-x1)/3 - h/2 ) + alpha*(t-x1)^2*(1/3);

end
