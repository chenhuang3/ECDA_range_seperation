%
% Compute the d(E_RPA) / d phi
%
% where E_RPA is the RPA correlation energy, and phi is the KS orbital
%
% output:
%    dERPA_dPhi(1:ngrid,1:norb)

function [dRPA_dPhi] = compute_dRPA_dPhi(nfreq,omega_max,x,ee,ev,occ,tsmear,mu)

fprintf('\nenter compute_dRPA_dPhi()...\n');
fprintf('tsmear: %f   \nchemical potential: %f\n',tsmear,mu);
fprintf('omega_max: %8.2f  nfreq: %d\n',omega_max,nfreq);

ngrid = size(ev,1);
norb = size(ev,2);
h = x(2)-x(1);  % spacing 

% make Coulumb matrix
coul = zeros(ngrid);
for q=1:ngrid
    for q2=1:ngrid
        dist = x(q)-x(q2);
        coul(q,q2) = 1.0/sqrt(dist*dist + 1.0);
    end
end



% make Gauss-Legendre points and weights
%[freq,int_w]=lgwt(nfreq,0,omega_max);
[freq,int_w]=lgwt_RPA(nfreq,omega_max);
dRPA_dPhi = zeros([ngrid]);
rpa_energy = 0.0;



% loop over frequences (see my notes/paper for details)
for q=1:nfreq
    
    chi = calc_chi(mu, tsmear, ev, ee, occ, freq(q));
    
    % M matrix 
    COUL = coul*h;  % convert to matrix representation in basis function (grids)
    CHI  = chi*h;   % convert to matrix representation in basis function (grids)
    M = inv(eye(ngrid)-COUL*CHI)*(-COUL*CHI*COUL);
    
% %%%%%%%%%%%%% debug M matrix %%%%%%%%%%%%
%     delta = 0.0001;Z
%     n1=20; n2=23;
%     chi_tmp = chi;
%     chi_tmp(n1,n2) = chi(n1,n2)+delta;
%     PP1 = trace(logm(eye(ngrid)-coul*chi_tmp)+coul*chi_tmp);
%     
%     chi_tmp = chi;
%     chi_tmp(n1,n2) = chi(n1,n2)-delta;
%     PP2 = trace(logm(eye(ngrid)-coul*chi_tmp)+coul*chi_tmp);
%     (PP1-PP2)/2/delta
%     M(n2,n1)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %rpa_energy = rpa_energy + trace(logm(eye(ngrid)-coul*chi)+coul*chi)*h*h*int_w(q)/pi/2;
    
    parfor i=1:norb        
        % W matrix (depend on freq)
        W = zeros(ngrid);
        
        for m = 1:norb
            omega_sq = freq(q)^2;
            
            coeff = (occ(i)-occ(m))/2.0*2.0* ...
                (ee(i)-ee(m))/( (ee(i)-ee(m))^2 + omega_sq );
            
            if abs(coeff)<1e-8
                continue
            end    
            W = W + coeff*(ev(:,i).*ev(:,m))*ev(:,m)';
        end
        
        % compute d(RPA)/d(phi)        
        vec1 = zeros([ngrid,1]);  % \int M(r,b)*W(b,r) 
        vec2 = zeros([ngrid,1]);  % \int M(a,r)*W(a,r)  
        
        for k=1:ngrid
            % Since M is expanded in the basis functions, 
            % we divide M by h to obtain the function M(x,x'), 
            vec1(k) = sum(M(k,:)'/h.*W(:,k))*h;  % h accouts for the integral
            vec2(k) = sum(M(:,k) /h.*W(:,k))*h;  % h accouts for the integral 
        end

        dRPA_dPhi(:,i) = dRPA_dPhi(:,i) + 1.0/pi*int_w(q)*(vec1+vec2);
        
    end % orbital 
end  % freq


end