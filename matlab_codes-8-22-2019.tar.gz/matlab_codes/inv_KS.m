
function [vks,vks_rec] = inv_KS(ngrid,norb,tsmear,x,box_len,ref_rho,vtrial,levelShift,v_LS)

fprintf('\nsolve Wu-Yang OEP with L-BFGS ...\n');

if levelShift==false
    v_LS = 0.0;
end

h = x(2)-x(1);
q = h*sum(ref_rho);

f_handler = @(vks)(WuYang(ngrid,norb,tsmear,x,box_len,ref_rho,vks,levelShift,v_LS));
options = optimset('GradObj','on','Display','Iter','MaxIter',1e8);
[vks] = fminlbfgs(f_handler,vtrial+rand(ngrid,1),options);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reconstruct vks from orbital
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[ee1,ev1] = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vtrial)+v_LS);

[ee,ev] = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
[occ,mu] = get_occ(norb,ee,q,tsmear,false);
rho = sum(ev.^2*occ,2);

% kinetic energy density
tau = zeros([ngrid,1]);
for j=1:ngrid
    f = occ(j)/2.0;

    %tau = tau + f*ev(:,j).* (v_LS * ev(:,j));
    %order = 4;
    %g_phi = get_gradient(x,ev(:,j),order);
    %tau = tau + f*g_phi.*g_phi/2.0;
    v_LS1 = zeros([ngrid,ngrid]);
    tau = tau + f*get_ke_density(ngrid,0,box_len,ev(:,j),v_LS1);
end

eps_orb_sq = zeros([ngrid,1]);
for j=1:ngrid
    f = occ(j)/2.0;
    eps_orb_sq = eps_orb_sq + f*ev(:,j).^2*ee(j);    
end

sum_phi_sq = zeros([ngrid,1]);
for j=1:ngrid
    f = occ(j)/2.0;
    sum_phi_sq = sum_phi_sq + f*ev(:,j).^2;    
end
    
vks_rec = -(tau - eps_orb_sq)./sum_phi_sq;

return


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  compute W and gradient associated with the Wu-Yang OEP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    function [w,g] = WuYang(ngrid,norb,tsmear,x,box_len,ref_rho,vks,levelShift,v_LS)
        
        h = x(2)-x(1);
        q = h*sum(ref_rho);
        
        [ee,ev] = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
        [occ,mu] = get_occ(norb,ee,q,tsmear,false);
        rho = sum(ev.^2*occ,2);
        sum_ee = dot(occ,ee);
        
        % entropy term (non-spin polarized case now)
        entropy = 0.0;
        for k=1:norb
            % cluster entropy
            occ_tmp = occ(k)/2.0;
            if abs(occ_tmp-1.0)>1e-8 && abs(occ_tmp)>1e-8
                entropy = entropy + ...
                    tsmear*occ_tmp*log(occ_tmp)+tsmear*(1-occ_tmp)*log(1-occ_tmp);
            end
        end
        entropy = entropy*2.0;
        
        % W function
        w = sum_ee + entropy - h*sum(vks.*ref_rho);
        g = rho - ref_rho;
        
        w = -w;
        g = -g;
        
        g = reshape(g,1,ngrid);
        
    end

end