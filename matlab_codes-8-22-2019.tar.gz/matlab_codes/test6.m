% >>>>>>>>>>> common settings  <<<<<<<<<<

use_total_chi = true;
do_plot = false;
do_patching = true;
shift_epp = false;
localizeOrbital = false;
do_exx = true;
do_rpa = true;
use_acfd_exx = true;

% >>>>>>>>>> system setup <<<<<<<<<<<<<

ion_soft = 1.0;                      % soft constant for v_ext potential
nspin = 1;                           % number of spin
tsmear = 0.000001/27.2114;                % in hartree
ngrid = 80;                          % include the last point
box_len = 25;                        % box stars at zero, in bohr
natom = 8;
%atom_Z = ones(natom,1)*1.2;          % 14 H atoms
atom_Z = [1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 ];
dx=2.0;
a1 = 5;
%coord = [5.0 6.5   8.5 10.0   12.0 13.5   15.5 17.0];
coord = [a1:dx:a1+dx*(natom-1)];     % cooridates
norb = ngrid;                        % number of orbitals to solve.
pen_coeff = 1e-4;                    % pen_coeff for regularizing vemb.
q_total = 8;                         % total electron number in system



%>>>>>>>>>>> EXX and RPA parameters <<<<<<<<<
omega_max = 5;
nfreq  = 10;

%>>>>>>>>>>>>>> definition of xcpp <<<<<<<<<<<<<<<
comm_chempot = true;
sub_tsmear = 0.1/27.2114;
buffer    = cell(natom,100);
buffer{1} = [2 3];
buffer{2} = [1 3 4];
buffer{3} = [1 2 4 5];
buffer{4} = [2 3 5 6];
buffer{5} = [3 4 6 7];
buffer{6} = [4 5 7 8];
buffer{7} = [5 6 8];
buffer{8} = [6 7];

%>>>>>>> orbitals to have for the atom <<<<<<<<<
nLocOrb = zeros([natom,1]);
nLocOrb(1) = 3;
nLocOrb(2) = 3;
nLocOrb(3) = 3;
nLocOrb(4) = 3;
nLocOrb(5) = 3;
nLocOrb(6) = 3;
nLocOrb(7) = 3;
nLocOrb(8) = 3;

ksdft
epp

