%
% make the laplacian operator
% using five-point finite difference method
% http://web.media.mit.edu/~crtaylor/calculator.html
% set order = 2 and use five points
%
%  Chen Huang 12/15/2017
%
function [lap] = lap_matrix(n)

lap = zeros([n,n]);

dd=12;

% f_xx = (-1*f[i-2]+16*f[i-1]-30*f[i+0]+16*f[i+1]-1*f[i+2])/(12*1.0*h**2)
% the coefficicents are: -1 , 16 , -30 , 16 , -1

% note that lap is symmetric by construction. 
% we assume that f values beyond thte boundary points are zero.

for i=1:n
    if i==1  % first line of matrix lap
        lap(1,1) = -30/dd;
        lap(1,2) =  16/dd;
        lap(1,3) =  -1/dd;
    elseif i==2  % second line of lap matrix 
        lap(2,1)=  16/dd;
        lap(2,2)= -30/dd;
        lap(2,3)=  16/dd;
        lap(2,4)=  -1/dd;
    elseif i==n-1
        lap(n-1,n-3)=  -1/dd;        
        lap(n-1,n-2)=  16/dd;
        lap(n-1,n-1)= -30/dd;
        lap(n-1,n)  =  16/dd;        
    elseif i==n
        % last line of lap matrix 
        lap(n,n-2)= -1/dd;
        lap(n,n-1)= 16/dd;
        lap(n,n)  = -30/dd;
    else
        % lines between 3 and n-2
        lap(i,i-2) = -1/dd;
        lap(i,i-1) = 16/dd;
        lap(i,i)   = -30/dd;
        lap(i,i+1) = 16/dd;
        lap(i,i+2) = -1/dd;
    end
end
end