function [dmu_dvks] = compute_dfermi_dvks(x,ee,ev,q,tsmear)

norb = length(x);
ngrid = length(x);

[occ,~] = get_occ(norb,ee,q,tsmear,false);

sum_occ =0.0;
for i=1:norb
    occ1 = occ(i)/2;
    sum_occ = sum_occ + occ1*(1-occ1);
end
sum_occ = sum_occ*2; % non-spin-polarized case


% get d(mu)/d(vks)
dmu_dvks = zeros(ngrid,1);
for i=1:norb
    occ1 = occ(i)/2;
    dfermi_deigen = occ1*(1-occ1)/sum_occ;
    dmu_dvks = dmu_dvks + dfermi_deigen*ev(:,i).^2;
end


dmu_dvks = dmu_dvks*2.0; % non-spin-polarized case

end