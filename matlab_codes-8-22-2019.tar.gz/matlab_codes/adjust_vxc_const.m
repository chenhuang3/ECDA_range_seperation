%
% the cluster's xc potentials are only determined to a given constant. 
% we determine these constants here by adjusting them to match the patched dExc/dV(r). 
% The cluster's xc potentials are then functions of vxc_shifts. 
% for a given vxc_shifts, we compute the new dExc/dV(r) and compare that to
% the pacthed dExc/dV(r). The residuls is then defined as 
%
%            |r> = |dExc/dV w/ shift> - |dExc/dV pached> 
%
% cost function is f=<r|r>. The gradient for minimizing such mismatch is easy to compute. 
% 
%            |g> = <r| \chi |atom_weight>
%
% where \chi is the KS linear response function. All term above can be
% computed using the finite difference due to the use of linear reponse
% funciotn \chi. So we do not need to explicitly compute \chi in practice. 
% which means that XCPP is applicable to large scale materials. 
%
%
function [f,g] = adjust_vxc_const(vxc_const,dExxdV_patched,vxc_cluster,natom,ngrid,x,atom_weight,chi)

h = x(2)-x(1);  % grid spacing 

%vxc_const = zeros(natom,1);

vxc_patched = zeros(ngrid,1);      

for ia = 1:natom    
    contrib2 = (vxc_cluster(:,ia)+vxc_const(ia)) .* atom_weight(:,ia);;
    vxc_patched = vxc_patched + contrib2;    
end

% obtain dEdV and compute residual
dEdV  = chi * vxc_patched * h;  % new dExc/dV
resid = dEdV - dExxdV_patched;  % residual 

% <resid|resid>
f = norm(resid)^2;  % <r|r>

% gradient 
g = zeros(natom,1);
for ia=1:natom 
    g(ia,1) = resid'*(chi*atom_weight(:,ia));
end






