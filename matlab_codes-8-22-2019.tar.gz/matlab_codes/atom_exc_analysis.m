%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Analysis of xc energy on atoms, compared to benchmark
% for DM partitioning and do_cpp = true
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


if do_rpa
    if range_sep==false 
        fprintf('\n  atom  rpa_atom  rpa_atom_benchmark            diff\n');
    else 
        fprintf('\n  atom  rpa_atom[w/ rpa_lr]  rpa_atom_benchmark            diff\n');
    end
    for ia=1:natom
        fprintf(' %3d  %14.6f   %14.6f   %14.6f \n',...
            ia,rpa_atom(ia),rpa_atom_benchmark(ia),rpa_atom(ia)-rpa_atom_benchmark(ia));
    end
    fprintf('------------------------------------------------\n ');
    fprintf('     %14.6f   %14.6f [sum] \n ',sum(rpa_atom),sum(rpa_atom_benchmark));
    
    % exchange energy per atom
    fprintf('\n\n  atom  exx_atom  exx_atom_benchmark          diff\n');
    for ia=1:natom
        fprintf(' %3d  %14.6f   %14.6f   %14.6f \n',...
            ia,exx_atom(ia),exx_atom_benchmark(ia),exx_atom(ia)-exx_atom_benchmark(ia));
    end
    fprintf('------------------------------------------------\n ');
    fprintf('     %14.6f   %14.6f [sum] \n\n ',sum(exx_atom),sum(exx_atom_benchmark));
end



% for density partitioning
if range_sep==false 
    fprintf('\n  atom      exc_atom      exc_atom_benchmark     diff\n');
else 
    fprintf('\n  atom      exc_atom(w/rpa_lr)      exc_atom_benchmark     diff\n');
end
for ia=1:natom
    fprintf(' %3d  %14.6f   %14.6f   %14.6f \n',...
        ia,exc_atom(ia),exc_atom_benchmark(ia),exc_atom(ia)-exc_atom_benchmark(ia));
end
fprintf('---------------------------------------------------------\n ');
fprintf('     %14.6f   %14.6f [sum] \n ',sum(exc_atom),sum(exc_atom_benchmark));



if do_rpa
    if iter==1
        save -ascii rpa_eps0_iter0.txt rpa_eps0
        save -ascii rpa_eps_iter0.txt  rpa_eps
        save -ascii exx_eps0_iter0.txt exx_eps0
        save -ascii exx_eps_iter0.txt  exx_eps
        tmp1 = exx_eps0+rpa_eps0;
        save -ascii exc_eps0_iter0.txt tmp1
        tmp1 = exx_eps +rpa_eps;
        save -ascii exc_eps_iter0.txt  tmp1
    else
        save -ascii rpa_eps0.txt rpa_eps0
        save -ascii rpa_eps.txt  rpa_eps
        save -ascii exx_eps0.txt exx_eps0
        save -ascii exx_eps.txt  exx_eps
        tmp1 = exx_eps0+rpa_eps0;
        save -ascii exc_eps0.txt tmp1
        tmp1 = exx_eps +rpa_eps;
        save -ascii exc_eps.txt  tmp1
    end
end





