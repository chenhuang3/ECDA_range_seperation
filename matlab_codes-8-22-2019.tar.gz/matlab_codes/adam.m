
V = vks_clu;
NPTS = ngrid;

b = box_len;
a = 0;

j=1:ngrid; % indexes for main diagonal
L=b-a;
h=L/(ngrid-1); % space step
x=j*h+a;
%V=cell2mat(f_pot_handle(x));

main_diag=2/h^2+V(j);
sub_diag=-1/h^2*ones(1,ngrid-1);

% make Hamiltonian matrix
Ham = zeros(NPTS,NPTS);
for i=1:NPTS
    Ham(i,i) = main_diag(i);
    if i<NPTS
        Ham(i+1,i) = sub_diag(i);
        Ham(i,i+1) = sub_diag(i);
    end
end

for i=1:4
    for j=1:4
        aaa(i,j) = ev(:,i)'*Ham*ev(:,j);
    end
end

[vtmp,etmp] = eig(aaa);
new_ev = ev(:,1:4)*vtmp;

plot(x,new_ev(:,1).^2+new_ev(:,2).^2);

hold on;
plot(x,order_locWfr(:,1).^2*2+order_locWfr(:,2).^2*2)
tmp2 = zeros(size(coord));
plot(coord,tmp2,'ro');