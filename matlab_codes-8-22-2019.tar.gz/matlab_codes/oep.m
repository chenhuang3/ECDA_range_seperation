



for j=1:1000  
   
   [ dEdV ] = calc_exx_dExcdV(ngrid,norb,tsmear,q,x,vks,h,box_len,acfd,levelShift,v_LS);
   
end 

