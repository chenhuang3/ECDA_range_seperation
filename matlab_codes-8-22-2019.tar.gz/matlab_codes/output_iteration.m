%~~~~~~~~~~~~~~~~~~~~~~~~
% output
%~~~~~~~~~~~~~~~~~~~~~~~~

function [conv_flag] = output_iteration(maxiter,one_step,iter,resid1,...
    etotal,old_etotal,old_etotal2,ke,ex,rpa_energy,TS_total)


echg1 = etotal - old_etotal;
echg2 = etotal - old_etotal2;

if (iter==1) 
    echg1=0.0;
end


fid = fopen('iteration_epp.txt','a');
fprintf(fid,'Iter: %3d  etot: %10.6f de: %9.2e  vres: %5.2e ke: %10.6f  ex: %8.4f rpa: %8.4f  -TS: %8.4f\n',...
    iter,etotal,echg1,norm(resid1),ke,ex,rpa_energy,-TS_total);
%%%fprintf(fid,'%f  %f  %f  %f  %f\n',abs(echg1),abs(echg2),etotal,old_etotal,old_etotal2)    
fclose(fid);

conv_flag = -1;


if abs(echg1)<1e-6 & abs(echg2)<1e-6 & iter>=10
    fprintf('energy converged to 1e-6, XCPP finished.  \n>>> Happy Landing <<<\n\n\n');
    fid = fopen('iteration_epp.txt','a');
    fprintf(fid,'energy converged to 1e-6, XCPP finished.  \n>>> Happy Landing <<<\n\n\n');
    fclose(fid);
    conv_flag = 1;
end

if iter==maxiter | one_step
    fid = fopen('iteration_epp.txt','a');
    fprintf(fid,'maxiter reached. XCEP finished.  \n>>> Happy Landing <<<\n\n\n');
    fclose(fid);
    conv_flag = 1;
end
