
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% density matrix partitioning
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


fprintf('\n\ndensity matrix partitioning...\n\n')
fprintf('box-length: %f \nngrid: %d  \ndx: %f\n',box_len,ngrid,x(2)-x(1));
fprintf('q_tot: %f  \nq_clu: %f  \nq_env: %f\n\n',q_total,q_clu,q_env);

% Make total density matrix
noccupied = 0;
dm_tot = zeros(ngrid);
for ib=1:norb
    dm_tot = dm_tot + occ(ib)*ev(:,ib)*ev(:,ib)';
end

q_total = trace(dm_tot)*h;
q_clu = q_total / 2.0;
q_env = q_total - q_clu;

ref_rho = rho;
ref_vks = vks;

% Initialize KS potential for cluster and env.
vext_clu = zeros(length(vext),1);
vext_env = zeros(length(vext),1);
for j=1:ngrid        
     for i=1:natom
         dist = coord(i) - x(j);
         pot = -atom_Z(i)/sqrt(dist*dist+1.0);     
         location = find(atom_list_clu==i);
         if  length(location)==1           
             % this atom belongs to cluster
             vext_clu(j) = vext_clu(j) + pot;
         else
             % this atom belong to env.
             vext_env(j) = vext_env(j) + pot;
         end
     end     
end
vks_clu = vext_clu;
vks_env = vext_env;

% f_handler = @(vemb)wrap_W_dm(vemb,nspin,x,comm_chempot,box_len,ev_len,ngrid,norb,...
%         tsmear,q_clu,q_env,vks_clu,vks_env,dm_tot);
% options = optimset('Display','iter');
% [vemb2,fval,exitflag,output] = lbfgs(f_handler, reshape(vemb,1,ngrid^2), options);
% vemb = reshape(vemb,ngrid,ngrid);

vemb = zeros( ngrid );
tsmear = 0.1/27.2114;

for iter=1:10
    
    % ----- BFGS minimize (-W) functional -----
    fprintf('solve for vemb (L-BFGS) ...\n\n');
    f_handler = @(vemb)(wrap_W_dm(vemb,nspin,x,comm_chempot,box_len,ngrid,norb,...
            tsmear,q_clu,q_env,vks_clu,vks_env,dm_tot));    
    options = optimset('GradObj','on','Display','Iter','MaxIter',1000);    
    [vemb,final_W] = fminlbfgs(f_handler,reshape(vemb,1,ngrid^2),options);
    vemb = reshape(vemb,ngrid,ngrid);
    
    [W,grad,rho_clu,rho_env,dm_clu,dm_env]=W_dm(vemb,nspin,x,comm_chempot,box_len,ngrid,norb,...
        tsmear,q_clu,q_env,vks_clu,vks_env,dm_tot);
    
    vks_clu_old = vks_clu;
    vks_env_old = vks_env;
    
figure
surf(dm_clu)
hold on
surf(dm_env)
figure 
plot(x,rho_clu,x,rho_env);
    
    % update vks_clu and vks_env
    fprintf('update vks of cluster and env.\n');        
    vks_clu =0.d0;
    vks_env =0.d0;
    % exchange
    [ex,vks_clu] = cal_ex(x, rho_clu);
    [ex,vks_env] = cal_ex(x, rho_env);
    % hartree 
    [ex,vtmp] = cal_hartree(x, rho_clu); vks_clu = vks_clu + vtmp;
    [ex,vtmp] = cal_hartree(x, rho_env); vks_env = vks_env + vtmp;
    % external 
    vks_clu = vks_clu + vext_clu;
    vks_env = vks_env + vext_env;
    
    % mixing 
    vks_clu = (vks_clu_old+vks_clu)/2.0;
    vks_env = (vks_env_old+vks_env)/2.0;    
end

% plot
figure
plot(x,ref_rho);
hold on;
plot(x,rho_clu);
plot(x,rho_env);
plot(x,rho_clu+rho_env,'ro');




