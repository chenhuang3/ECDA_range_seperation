
% >>>>>>>>>>> common settings  <<<<<<<<<<

use_total_chi = true;
do_plot = false;
do_patching = true;
shift_epp = false;
localizeOrbital = true;
do_exx = true;
do_rpa = true;
use_acfd_exx = true;

% >>>>>>>>>> system setup <<<<<<<<<<<<<

ion_soft = 1.0;                      % soft constant for v_ext potential
nspin = 1;                           % number of spin
tsmear = 0.001/27.2114;                % in hartree
ngrid = 120;                          % include the last point
box_len = 40;                        % box stars at zero, in bohr
natom = 16;
atom_Z = ones(natom,1)*1.2;          % 14 H atoms
%atom_Z = [1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 ];
dx=2.0;
a1 = 5;
%coord = [5.0 6.5   8.5 10.0   12.0 13.5   15.5 17.0];
coord = [a1:dx:a1+dx*(natom-1)];     % cooridates
norb = ngrid;                        % number of orbitals to solve.
pen_coeff = 1e-4;                    % pen_coeff for regularizing vemb.
q_total = 16;                         % total electron number in system



%>>>>>>>>>>> EXX and RPA parameters <<<<<<<<<
omega_max = 5;
nfreq  = 10;

%>>>>>>>>>>>>>> definition of xcpp <<<<<<<<<<<<<<<
comm_chempot = true;
buffer    = cell(natom,100);
buffer{1} = [2 3];
buffer{2} = [1 3 4];
buffer{3} = [1 2 4 5];
buffer{4} = [2 3 5 6];
buffer{5} = [3 4 6 7];
buffer{6} = [4 5 7 8];
buffer{7} = [5 6 8];
buffer{8} = [6 7];


%>>>>>>> orbitals to have for the atom <<<<<<<<<
nLocOrb = zeros([natom,1]);
nLocOrb(1) = 2;
nLocOrb(2) = 2;
nLocOrb(3) = 2;
nLocOrb(4) = 2;
nLocOrb(5) = 2;
nLocOrb(6) = 2;
nLocOrb(7) = 2;
nLocOrb(8) = 2;

ksdft
epp

