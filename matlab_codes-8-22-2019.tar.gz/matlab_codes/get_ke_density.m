function [tau] = get_ke_density(ngrid,a,b,phi,V)



NPTS = ngrid;

% check dimension of nonlocal potential V.
if size(V,1) ~= NPTS
    disp('size(V,1) ~= NPTS')
    stop
end
if size(V,2) ~= NPTS
    disp('size(V,2) ~= NPTS')
    stop
end


L=b-a;
h=L/(NPTS-1); % space step
V = V*2.0; % convert from Hartree to Ry

% ======= 4th order ===========
% ======= 4th order ===========
Ham = zeros(NPTS,NPTS);
for i=1:NPTS
    % the first two points are treated with central finite difference
    if i==1
        Ham(i,i) = 2/h^2;
        Ham(1,2) = -1/h^2;
    end
    if i==2
        Ham(i,i) = 2/h^2;
        Ham(2,1) = -1/h^2;
        Ham(2,3) = -1/h^2;
    end
    % the last two points are treated with central finite difference
    if i==NPTS
        Ham(i,i)         = 2/h^2;
        Ham(NPTS,NPTS-1) = -1/h^2;
    end
    if i==NPTS-1
        Ham(i,i) = 2/h^2;
        Ham(NPTS-1,NPTS)   = -1/h^2;
        Ham(NPTS-1,NPTS-2) = -1/h^2;
    end
    %The inner points are treated by the centered difference formulas for five-point stencils
    %https://en.wikipedia.org/wiki/Five-point_stencil
    if i>2 && i<NPTS-1
        Ham(i,i)  =  30/12/h^2;
        Ham(i,i-2)=  1/12/h^2;
        Ham(i,i-1)= -16/12/h^2;
        Ham(i,i+1)= -16/12/h^2;
        Ham(i,i+2)=  1/12/h^2;
    end
end

Ham = Ham + V;

tau = phi.* (Ham * phi);
tau = tau/2.0;  % Ry to Hartree

end