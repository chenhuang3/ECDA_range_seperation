xx= [0:1e-5:1e1];

eps = 1e-4;
rho0 = 1e-5;
sigma = rho0;

y = eps*(1+exp(-rho0/sigma))./(1+exp((xx-rho0)/sigma));

figure
semilogx(xx,y)



rho = sum(ev.^2*occ,2);
reg_mat = diag(eps*(1+exp(-rho0/sigma))./(1+exp((rho-rho0)/sigma)));


pot = cgls_chen_reg(chi,dEdV,reg_mat,tol,maxiter);
pot2 = cgls(chi,dEdV,1e-4,tol,maxiter);

figure
plot(x,pot,'-k',x,pot2,'b-o')
figure
plot(x,diag(reg_mat))

figure; plot(x,rho)


pot3 = cgls_chen_reg(chi,dEdV,reg_mat,reg_vxc,tol,maxiter);