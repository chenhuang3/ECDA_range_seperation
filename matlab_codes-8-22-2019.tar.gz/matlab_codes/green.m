%
% Compute the green's function 
%
%  G(r,r') = \sum_{k/=j} phi_k(r) phi_k(r') / (e_j - e_k)
%
function [gf] = green(i_orbital,phi,eig,nbuffer)

   ngrid = size(phi,1);
   norb  = size(phi,2);
   
   gf = zeros([ngrid,ngrid]);
   
   %
   % for some unknown reason the highest two eigenvalues can be the same
   % so I just remove them in the calculation of the green's function
   % for the purpose of safety, i remove 5 bands from the top
   %
   for j=1:norb-nbuffer
       if i_orbital==j
           continue 
       end
       gf = gf + phi(:,j)*phi(:,j)' / (eig(i_orbital)-eig(j));
   end
   
end 