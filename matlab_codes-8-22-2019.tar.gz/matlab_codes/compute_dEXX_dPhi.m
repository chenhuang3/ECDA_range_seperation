

function [dEXX_dPhi] = compute_dEXX_dPhi(x,ev,occ,eig)

ngrid = length(x);
nband = size(ev,2);
h = x(2)-x(1);

% make Coulumb matrix
coul = zeros(ngrid);
for q=1:ngrid
    for q2=1:ngrid
        dist = x(q)-x(q2);
        coul(q,q2) = 1.0/sqrt(dist*dist + 1.0);
    end
end

dEXX_dPhi = zeros(ngrid);

for i = 1:nband
    
    for j=1:nband
        
        fi = occ(i)/2.0;
        fj = occ(j)/2.0;
        
        Cij = 1+sign(eig(i)-eig(j));
        Cji = 1+sign(-eig(i)+eig(j));
        
        if fi*Cij<1e-8 && fj*Cji<1e-8
            continue
        end
        
        vec1 = ev(:,j).*ev(:,i);
        vec2 = coul*vec1*h;
        
        if fi*Cij > 1e-8
            dEXX_dPhi(:,i) = dEXX_dPhi(:,i) - fi*Cij*2*vec2.*ev(:,j);
        end
        
        if fj*Cji > 1e-8
            dEXX_dPhi(:,i) = dEXX_dPhi(:,i) - fj*Cji*2*vec2.*ev(:,j);
        end
        
    end    
    
end