function [y] = vc_short_range(rc,soft_coul,x)

vg_sr = @(q)2*besselk(0,abs(q)*soft_coul).*(1-exp(-(q*rc).^2));
y = integral(@(q)cos(-q*x).*vg_sr(q),-Inf,Inf)/2/pi;

end