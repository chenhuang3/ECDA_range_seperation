
% >>>>>>>>>>> common settings  <<<<<<<<<<

use_total_chi = true;
do_plot     = false;
do_patching = true;
shift_epp   = false;
localizeOrbital = 0;
do_exx = true;
do_rpa = true;
do_cpp = false;
use_acfd_exx = true;

% >>>>>>>>>> system setup <<<<<<<<<<<<<

ion_soft = 1.0;                      % soft constant for v_ext potential
nspin = 1;                           % number of spin
tsmear = 0.000001/27.2114;           % in hartree
sub_tsmear = 0.1/27.2114;
ngrid = 160;                         % include the last point
box_len = 55;                        % box stars at zero, in bohr
natom   = 20;
atom_Z = ones(natom,1)*1.2;          % 14 H atoms
%dx=1.5;
%a1 = 10;
% alternating bond a=1.5 b=2.0
coord = [10.0 11.5   13.5 15.0   17.0 18.5  20.5 22.0  24.0 25.5  27.5 29.0 ...
         31.0 32.5   34.5 36.0   38.0 39.5  41.5 46.5  ]
%coord = [a1:dx:a1+dx*(natom-1)];       % cooridates
norb      = ngrid;                      % number of orbitals to solve.
pen_coeff = 1e-4;                       % pen_coeff for regularizing vemb.
q_total   = 20;                         % total electron number in system

%>>>>>>>>>>> EXX and RPA parameters <<<<<<<<<
omega_max = 10;
nfreq     = 15;

%>>>>>>>>>>>>>> definition of xcpp <<<<<<<<<<<<<<<
comm_chempot = true;
buffer    = cell(natom,100);
buffer{1} =  999;
buffer{2} =  999;
buffer{3} =  999;
buffer{4} =  999;
buffer{5} =  999;
buffer{6} =  999;
buffer{7} =  999;
buffer{8} =  999;
buffer{9} =  999;
buffer{10} = 999;
buffer{11} = 999;
buffer{12} = 999;
buffer{13} = 999;
buffer{14} = 999;
buffer{15} = 999;
buffer{16} = 999;
buffer{17} = 999;
buffer{18} = 999;
buffer{19} = 999;
buffer{20} = [18 19];

ksdft
epp