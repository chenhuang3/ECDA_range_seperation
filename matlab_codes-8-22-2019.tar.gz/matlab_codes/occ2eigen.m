function eigen = occ2eigen(tsmear, fermi, occ)
  nband = length(occ);
  for j=1:nband
      eigen(j,1) = log(1/(occ(j)/2.0)-1)*tsmear+fermi;
  end
end