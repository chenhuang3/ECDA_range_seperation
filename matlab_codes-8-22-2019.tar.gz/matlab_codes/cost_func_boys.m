
function [f,g] = cost_func_boys(norb,points,new_wfr,inwfr,h)

  %%%%%%%%%% get the <r^2> %%%%%%%%
  
  for i=1:norb
     arr = new_wfr(:,i).^2;
     x(i) = sum(arr.*points)*h;
  end

  %
  % cost function 
  % 
  L = 0.0;
  for ii=1:norb 
     for jj=1:norb 
          L = L + ( x(ii)-x(jj) )^2;
     end
  end
  
  %
  % gradient dL/dU_ij 
  %
  dL_dUmatrix = zeros(norb);
  for ii=1:norb 
     for jj=1:norb 
     
        arr = new_wfr(:,jj).*inwfr(:,ii);
        cross_term = sum(arr.*points)*h;
                
        for q=1:norb 
            dtmp = x(jj) - x(q);
            dL_dUmatrix(ii,jj) = dL_dUmatrix(ii,jj) + 8.0*dtmp*cross_term;
        end
        
     end
  end
  
  f = L;
  g = dL_dUmatrix;
  
  
end