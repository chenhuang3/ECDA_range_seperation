% >>>>>>>>>>> common settings  <<<<<<<<<<

use_total_chi = true;
do_plot = true;
do_patching = true;
shift_epp = false;
partition_method = 3; % 1: rho_partition
                      % 2: boys localization
                      % 3: density matrix splitting
do_exx = true;
do_rpa = true;
use_acfd_exx = true;
do_draw_EPS = false;

% >>>>>>>>>> system setup <<<<<<<<<<<<<

ion_soft = 1.0;                      % soft constant for v_ext potential
nspin = 1;                           % number of spin
tsmear = 0.9/27.2114;             % in hartree
ngrid = 100;                         % include the last point
box_len = 35;                        % box stars at zero, in bohr
natom = 10;
atom_Z = ones(natom,1)*1.2;              % 14 H atoms
%atom_Z = [1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 ];
dx = 1.6;
a1 = 10;
%coord = [5.0 6.5   8.5 10.0   12.0 13.5   15.5 17.0];
coord = [a1:dx:a1+dx*(natom-1)];     % cooridates
norb = ngrid;                        % number of orbitals to solve.
pen_coeff = 1e-4;                    % pen_coeff for regularizing vemb.
q_total = 10;                         % total electron number in system

%>>>>>>>>>>> EXX and RPA parameters <<<<<<<<<
omega_max = 5;
nfreq  = 10;

%>>>>>>>>>>>>>> definition of xcpp <<<<<<<<<<<<<<<
comm_chempot = true;
sub_tsmear = 0.01/27.2114;
buffer    = cell(natom,100);
buffer{1} = [2 3];
buffer{2} = [1 3 4];
buffer{3} = [1 2 4 5];
buffer{4} = [2 3 5 6];
buffer{5} = [3 4 6 7];
buffer{6} = [4 5 7 8];
buffer{7} = [5 6 8];
buffer{8} = [6 7];

%>>>>>>> orbitals to have for the atom <<<<<<<<<
nLocOrb = zeros([natom,1]);
nLocOrb(1) = 3;
nLocOrb(2) = 3;
nLocOrb(3) = 3;
nLocOrb(4) = 3;
nLocOrb(5) = 3;
nLocOrb(6) = 3;
nLocOrb(7) = 3;
nLocOrb(8) = 3;

%>>>>>>>>> density matrix splitting <<<<<<<<<<<<
dms_tsmear = 0.1/27.2114;
atom_list_clu = [1 2 3 4];         % atoms grouped to form cluster
atom_list_env = [5 6 7 8];         % atoms grouped to form environment
q_clu = q_total/2.0;
q_env = q_total - q_clu;

ksdft

% Make total density matrix
noccupied = 0;
dm_tot = zeros(ngrid);
for ib=1:norb
    dm_tot = dm_tot + occ(ib)*ev(:,ib)*ev(:,ib)';
end

for ib=1:norb
    phir(:,ib)=occ(ib)^0.5*ev(:,ib);
end

dm_tot2 = phir * phir';

um = orth(randn(norb,norb));

psi = um*phir';
psi = psi';

% ---------------- Ham -------------
a = 0.0;
b = box_len;
h = x(2)-x(1);
V = vks; % convert from Hartree to Ry
%pot_dat=load(pot_filename);
j=1:ngrid; % indexes for main diagonal
L=b-a;
h=L/(ngrid-1); % space step
x=j*h+a;
main_diag=2/h^2+V(j);
sub_diag=-1/h^2*ones(1,ngrid-1);
% make Hamiltonian matrix
Ham = zeros(ngrid,ngrid);
for i=1:ngrid
   Ham(i,i) = main_diag(i);
   if i<ngrid
      Ham(i+1,i) = sub_diag(i);
      Ham(i,i+1) = sub_diag(i);
   end
end



%eigen = occ2eigen(tsmear,fermi,occ(1:8));
%epp
%dm_split


