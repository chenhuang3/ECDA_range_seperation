

function [vxpot, dEdV] = calc_exx_potential(x,vks,q_cluster,q_total,...
    tsmear,norb,fd_chi,acfd,levelShift,v_LS,use_total_chi,mu,reg_vxc)

fprintf('[exx_pot] computing EXX potential ...\n')
fprintf('level_shift: %d \nuse_total_chi: %d\n',levelShift,use_total_chi);

box_len = x(end);
ngrid = size(x,1);
nband = size(x,1);
h = x(2) - x(1);
nbuffer = 10;
omega_tiny = 1e-6;

%
% computer dEdV 
%
analytical_method = true;

if analytical_method == false    
    
    [ dEdV ] = calc_exx_dEdV(ngrid,norb,tsmear,q_cluster,x,vks,h,box_len,acfd,levelShift,v_LS);
    %[ pot ] = solve_vxc_lsqr(x,dEdV,levelShift,vks,v_LS,ngrid,norb,box_len,q,tsmear);
    dEdV_fd = dEdV;
    
else    
    if (levelShift)
        % cluster
        [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
        [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
    else
        % total system
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
        [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
    end
    
    [dEXX_dPhi] = compute_dEXX_dPhi(x,ev,occ,ee);
    [dEXX_dee]  = compute_dEXX_dEigen(x,ev,occ,ee,tsmear);
    
    dEdV = zeros([ngrid,1]);
    
    for ib=1:nband-nbuffer
        gf = green(ib,ev,ee,nbuffer);
        dEdV = dEdV ...
            + (h*gf*dEXX_dPhi(:,ib)).*ev(:,ib) ... % dE/dphi * dphi/dV
            + dEXX_dee(ib)*ev(:,ib).^2;            % dE/d(ee) * d(ee)/dV    
    end
%     figure
%     plot(x,dEdV,'kx-',x,dEdV_fd,'ro')
end


%
% compute static KS response:
%
%chi(r,r') = d rho(r') / d vks(r)
%chi computed from calc_chi0_finite_diff() is different from that
%from calc_chi(), since it has been normalized by the volume element 'h'.
%
if fd_chi
    fprintf('code here is not ready to run!!! stop!!!')
    stop
    fprintf('[exx_pot] finite difference way to compute chi_static\n');
    [ chi ] = calc_chi0_finite_diff(norb,box_len,vks,q,h,tsmear,levelShift,v_LS);
else
    %
    % Analytical way of computing chi_static
    %
    fprintf('[exx_pot] Analytical way of computing chi_static, valid for integer occ only.\n')
    if levelShift
        if use_total_chi
            fprintf('*** Use reponse of total system to avoid null space of response of subsystem *** \n');
            [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
            [occ,mu] = get_occ(norb,ee,q_total,tsmear,false);
            [ chi ]  = calc_chi(mu,tsmear,ev, ee, occ, omega_tiny);
        else
            fprintf('\n For EXX, Use response of subsystem, be aware of its NULL space!\n');
            [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
            [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
            [ chi ]  = calc_chi(mu,tsmear,ev, ee, occ, omega_tiny);
        end
    else
        % density partitioning
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
        [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
        [ chi ]  = calc_chi(mu,tsmear,ev, ee, occ, omega_tiny);
    end
end
chi = (chi+chi')/2.0;

%
% Solve OEP equation
%   dE_dV(r) = \int dr' chi(r,r')*dE/dn(r)
%
% CGLS method with regularization
% http://web.stanford.edu/group/SOL/software/cgls
%
fprintf('calc_exx_potential: solve v_rpa using CGLS\n');
fprintf('regularization parameter, reg_vxc: %f\n',reg_vxc);
tol     = 1e-16;
maxiter = 10000;
pot = cgls(chi,dEdV,reg_vxc,tol,maxiter);
pot = pot / h;
vxpot = pot;
fprintf('done calc_exx_potential().\n\n');




end





