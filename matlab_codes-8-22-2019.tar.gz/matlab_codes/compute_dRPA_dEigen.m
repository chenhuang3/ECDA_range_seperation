%
% The derivative of RPA energy with respect to occupation numbers
%
% Input:
%   mu: chemical potential
%   tsmear: kB*T
%   occ: occupation numbers
%   ee: eigenvalues
%
function [dRPA_dee] = compute_dRPA_dEigen(nfreq,omega_max,x,ee,ev,occ,tsmear,mu)


fprintf('\nenter compute_dRPA_dEigen()...\n');
fprintf('omega_max: %8.2f  nfreq: %d  \nchemical potential: %f \n',omega_max,nfreq,mu);

ngrid = size(ev,1);
norb  = size(ev,2);
h     = x(2)-x(1);  % grid spacing

% make Coulumb matrix
coul = zeros(ngrid);
for q=1:ngrid
    for q2=1:ngrid
        dist = x(q)-x(q2);
        coul(q,q2) = 1.0/sqrt(dist*dist + 1.0);
    end
end
COUL = coul*h;  % in matrix rep. with grid points as basis functions


% make Gauss-Legendre points and weights
%[freq,int_w]=lgwt(nfreq,0,omega_max);
[freq,int_w]=lgwt_RPA(nfreq,omega_max);

dRPA_dee1 = zeros([norb,1]);
dRPA_dee2 = zeros([norb,1]);


dsum = 0.0;
for i=1:norb
    ftmp = occ(i)/2;
    dsum = dsum + ftmp*(1-ftmp);
end


% M matrix in my notes
M = zeros(ngrid,ngrid,nfreq);
for q=1:nfreq
    chi = calc_chi(mu, tsmear, ev, ee, occ, freq(q));    
    CHI =  chi*h;   % in matrix rep. with grid points as basis functions 
    M(:,:,q) = inv(eye(ngrid)-COUL*CHI)*(-COUL*CHI*COUL);
end


% comptue Part 1A (derivative with occupation numbers only, see notes for details )
for n=1:norb
    for m=1:norb
        
        fn = occ(n)/2.0;
        fm = occ(m)/2.0;
        delta_ee = ee(n)-ee(m);
        
        % loop over freq.
        M_int = zeros([ngrid,ngrid]);
        for q=1:nfreq
            factor1 = 2*fn*(1-fn)/tsmear*2*delta_ee/(delta_ee^2+freq(q)^2);
            M_int = M_int + M(:,:,q)*factor1*int_w(q);
        end
        
        vec = ev(:,m).*ev(:,n);
        VEC = vec*vec'*h; % in matrix rep. with grid points as basis functions 
        dtmp = 1/2/pi*trace(M_int*VEC);
        
        for i=1:norb
            % d(chemical potential)/d(ee(i))
            fi = occ(i)/2.0;
            dmu_dee = fi*(1-fi)/dsum;
            dRPA_dee1(i,1) = dRPA_dee1(i,1) + dtmp * dmu_dee;
        end
    end
end



% comptue Part 1B (derivative with occupation numbers only, see notes for details )
for i=1:norb
    for m=1:norb
        
        fi = occ(i)/2.0;
        delta_ee = ee(i)-ee(m);
        
        % loop over freq.
        M_int = zeros([ngrid,ngrid]);
        for q=1:nfreq
            factor1 = -2*fi*(1-fi)/tsmear*2*delta_ee/(delta_ee^2+freq(q)^2);
            M_int = M_int + M(:,:,q)*factor1*int_w(q);
        end
        
        vec = ev(:,i).*ev(:,m);
        VEC = vec*vec'*h; % in matrix rep. with grid points as basis functions 
        dRPA_dee1(i,1) = dRPA_dee1(i,1) + 1/2/pi*trace(M_int*VEC);
    end
end



% compute Part2 (derivative with eigenvalues numbers only )
for i=1:norb
    
    fi = occ(i)/2.0;
    for n=1:norb
        vec_computed = false;
        
        % loop over freq.
        M_int = zeros([ngrid,ngrid]);
        for q=1:nfreq
            
            fn = occ(n)/2.0;
            delta_ee = ee(i)-ee(n);
            
            factor2 = - 2.0 * ( fi-fn ) * 2 * ...
                ( delta_ee^2 - freq(q)^2)/( delta_ee^2 + freq(q)^2 )^2;
            
            M_int = M_int + M(:,:,q)*factor2*int_w(q);
        end
        
        vec = ev(:,i).*ev(:,n);
        VEC = vec*vec'*h; % in matrix rep. with grid points as basis functions 
        dRPA_dee2(i,1) = dRPA_dee2(i,1) + 1/2/pi*trace(M_int*VEC);
    end    
end

dRPA_dee = dRPA_dee1 + dRPA_dee2;

%fprintf('part1: %f\n',dRPA_dee1(11))
%fprintf('part2: %f\n',dRPA_dee2(11))

end
