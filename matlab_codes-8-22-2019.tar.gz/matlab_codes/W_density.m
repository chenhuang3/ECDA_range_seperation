%
% the W function to be maximized for DM partitioning
%
function [W,g,rho_clu,rho_env,Ef_emb,mu_clu,mu_env] = W_density( ...
    vemb,nspin,x,comm_chempot,box_len,ngrid,norb,...
    tsmear,q_total,q_clu,q_env,vks_clu,vks_env,rho_tot)
    
    [ee_clu,ev_clu] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_clu+vemb);
    [ee_env,ev_env] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_env+vemb);
    
    h = x(2)-x(1);
    
    % occupation numbers 
    if (comm_chempot)
        q_clu = 0.0;
        q_env = q_total;
        [occ_clu,occ_env,Ef_emb] = get_occ_comm(norb,ee_clu,q_clu,ee_env,q_env,tsmear,false);
    else
        Ef_emb = 0.0;
        [occ_clu,mu_clu] = get_occ(norb,ee_clu,q_clu,tsmear,false);
        [occ_env,mu_env] = get_occ(norb,ee_env,q_env,tsmear,false);
    end
    
    % density
    rho_clu = sum(ev_clu.^2*occ_clu,2);    
    rho_env = sum(ev_env.^2*occ_env,2);
    
    % sum of eigenvalues 
    sum_ee_clu = dot(occ_clu,ee_clu);
    sum_ee_env = dot(occ_env,ee_env);
    
    % entropy term 
    if  nspin==1
        entropy_clu = 0.0;
        entropy_env = 0.0;
        for q=1:norb 
            % cluster entropy 
            occ_tmp = occ_clu(q)/2.0;
            if abs(occ_tmp-1.0)>1e-20 && abs(occ_tmp)>1e-20
                entropy_clu = entropy_clu + ...
                    tsmear*occ_tmp*log(occ_tmp)+tsmear*(1-occ_tmp)*log(1-occ_tmp);
            end
            % env entropy 
            occ_tmp = occ_env(q)/2.0;
            if abs(occ_tmp-1.0)>1e-20 && abs(occ_tmp)>1e-20
                entropy_env = entropy_env + ...
                    tsmear*occ_tmp*log(occ_tmp)+tsmear*(1-occ_tmp)*log(1-occ_tmp);            
            end
        end
        entropy_env = entropy_env*2.0;
        entropy_clu = entropy_clu*2.0;
    else 
        stop
    end
    
    % W function 
    W = sum_ee_clu + entropy_clu + ...
        sum_ee_env + entropy_env - h*dot(vemb,rho_tot);   
    
%     % form density matrix 
%     dm_clu = zeros(ev_len,1);
%     dm_env = zeros(ev_len,1);
%     for ib=1:norb 
%         dm_clu = dm_clu + occ_clu(ib)*ev_clu(:,ib)*ev_clu(:,ib)';
%         dm_env = dm_env + occ_env(ib)*ev_env(:,ib)*ev_env(:,ib)';
%     end
    
    % update embedding potential (steepest decent)
    W = -W;
    g = rho_clu +  rho_env -rho_tot;
    g = -g;
end
