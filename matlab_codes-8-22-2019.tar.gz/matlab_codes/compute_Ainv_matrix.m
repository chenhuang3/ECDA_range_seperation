
%=================
% get A matrix
%=================

function [AAcluInv, AAenvInv, dmu_dvks_clu, dmu_dvks_env] = compute_Ainv_matrix(ia,x,norb,ngrid,tsmear,...
    clu_weight,env_weight,ev_clu,ev_env,ee_clu,ee_env,q_clu,q_env)


h = x(2) - x(1);

[occ_clu,~] = get_occ(norb,ee_clu,q_clu,tsmear,false);
[occ_env,~] = get_occ(norb,ee_env,q_env,tsmear,false);

sum_occ =0.0;
for i=1:norb
    occ = occ_clu(i)/2;
    sum_occ = sum_occ + occ*(1-occ);
end
sum_occ = sum_occ*2; % non-spin-polarized case


% get d(mu)/d(vks) [cluster]
dmu_dvks_clu = zeros(ngrid,1);
for i=1:norb
    occ = occ_clu(i)/2;
    dfermi_deigen = occ*(1-occ)/sum_occ;
    dmu_dvks_clu = dmu_dvks_clu + dfermi_deigen*ev_clu(:,i).^2;
end

dmu_dvks_clu = dmu_dvks_clu*2.0; % non-spin-polarized case
AAclu = eye(ngrid) - (1-clu_weight(:,ia))*dmu_dvks_clu'*h;
AAcluInv = inv(AAclu);


% get d(mu)/d(vks) [env]
dmu_dvks_env = zeros(ngrid,1);
for i=1:norb
    occ = occ_env(i)/2;
    dfermi_deigen = occ*(1-occ)/sum_occ;
    dmu_dvks_env = dmu_dvks_env + dfermi_deigen*ev_env(:,i).^2;
end

dmu_dvks_env = dmu_dvks_env*2.0; % non-spin-polarized case
AAenv = eye(ngrid) - (1-env_weight(:,ia))*dmu_dvks_env'*h;
AAenvInv = inv(AAenv);

end
