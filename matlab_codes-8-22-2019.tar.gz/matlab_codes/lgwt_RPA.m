%
% Rescaled weights and nodes for Gaussian quadrature for RPA.
% nodes are dense near the origin.
%
% References: Olsen and Thygesen (PRB 87, 075111 (2013))
%
% The derivation of weights and nodes directly follows GPAW's code.
% It seems that our formula is different from the paper
% [Olsen and Thygesen (PRB 87, 075111 (2013))],
% but ours is the same to GPAW code. This might be a typo in their paper.
% It should be (alpha*x)^(1/B) rather than alpha*x^(1/B).
%
%==================================================================

function  [node, weight] = lgwt_RPA(nfreq,umax)

% generate nodes and weights in [0,1]
[t, w] = lgwt(nfreq,0,1);

% sort t from small to large
[ts,index] = sort(t);
ws = w(index);

B=2.0;
alpha = (-log(ts(1)))^B/umax;

% rescaled nodes and weights
node = (-log(ts)).^B/alpha;
weight = B/alpha./ts.*(-log(ts)).^(B-1).*ws;

end