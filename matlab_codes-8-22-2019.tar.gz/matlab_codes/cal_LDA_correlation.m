function [ ecorr, vc, eps ] = cal_LDA_correlation( x, rho )

   % compute the correlation energy and potential based on LDA
   % reference: PHYSICAL REVIEW A 83, 032503 (2011)
   % for non-spin polarized case only 
   
   % paramters (for unpolarized case)
   
   A = 18.40;
   B = 0.0;
   C = 7.501;
   D = 0.10185;
   E = 0.012827;
   alpha = 1.511;
   beta  = 0.258;
   m = 4.424;
   
   ecorr = 0.0;
   
   for i=1:length(x)
       
       rs = 1/(2*rho(i)); % see definition below in Eq. (8) in Wagner et al.  Phys. Chem. Chem. Phys., 2012, 14, 8581�8590
       
       % formula from Eq. (4) in PHYSICAL REVIEW A 83, 032503 (2011)
       denom = (A+B*rs+C*rs*rs+D*rs*rs*rs);       
       logTerm = log(1+alpha*rs+beta*rs^m);
       
       ec = -0.5*(rs+E*rs*rs) / denom * logTerm;
       eps(i,1) = ec*rho(i);
       ecorr = ecorr + ec*rho(i);
       
       % ----- correlation potential ------
       % formula is based on the Eq. (4) in PHYSICAL REVIEW A 83, 032503 (2011)
       % d(ec) / d(rs)
       dec_drs = -0.5*( (1+E*2*rs)/denom*logTerm ...
           - (rs+E*rs*rs)/denom/denom*(B+2*C*rs+3*rs*rs*D)*logTerm ...
           + (rs+E*rs*rs)/denom/(1+alpha*rs+beta*rs^m)*(alpha+beta*m*rs^(m-1)) );
       
       drs_drho = -0.5/rho(i)^2;       
       vc(i,1) = ec + dec_drs * drs_drho*rho(i);
       
   end 
  
   ecorr = ecorr*(x(2)-x(1));
end

