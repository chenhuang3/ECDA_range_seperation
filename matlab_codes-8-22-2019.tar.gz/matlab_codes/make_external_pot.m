%
% natom: number of atom 
% atom_type: atomic number 
% coord: 1 x natom 
% box_len: box length (box start from zero by default)
% ngrid: number of points on the mesh, include the last point.
%
function [vext] = make_external_pot(ion_soft,x,natom,atom_Z,coord,ngrid)
 
  vext = zeros(ngrid,1);
  for j=1:ngrid
     for i=1:natom 
        dist = coord(i) - x(j);        
        pot = -atom_Z(i)/sqrt(dist*dist + ion_soft);
        vext(j) = vext(j) + pot;        
     end     
  end
  
  
end