function [deps_dN] = compute_dExx_eps_dN(x,occ,ee,ev)

ngrid = size(x,1);

if ngrid==1
    fprintf('ngrid is 1 in compute_dExx_eps_dN() error! ')
    stop
end

% make Coulumb matrix
coul = zeros(ngrid);
for q=1:ngrid
    for q2=1:ngrid
        dist = x(q)-x(q2);
        coul(q,q2) = 1.0/sqrt(dist*dist + 1.0);
    end
end


deps_dN = zeros(ngrid,1);


for ib=1:ngrid
    
    % dccc/dN with v_{KS} fixed    
    occ_tmp = occ(ib)/2;
    docc_dN = occ_tmp*(1-occ_tmp)/2/sum((1-occ/2).*occ/2); % for non spin polarized case
    
    for ib2=1:ngrid
        factor = (1-sign(ee(ib2)-ee(ib)));
        vec1 = ev(:,ib).*ev(:,ib2);
        vec2 = coul*vec1*(x(2)-x(1));
        deps_dN = deps_dN - docc_dN*factor*vec1.*vec2;
    end
    
end