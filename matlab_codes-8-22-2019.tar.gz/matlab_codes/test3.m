
% >>>>>>>>>>> common settings  <<<<<<<<<<

use_total_chi   = true;
do_plot         = false;
do_patching     = false;
shift_epp       = false;
localizeOrbital = true;
do_exx          = true;
do_rpa          = false;
use_acfd_exx    = true;

% >>>>>>>>>> system setup <<<<<<<<<<<<<

ion_soft = 1.0;                      % soft constant for v_ext potential
nspin = 1;                           % number of spin
tsmear = 0.1/27.2114;                % in hartree
ngrid = 100;                         % include the last point
box_len = 45;                        % box stars at zero, in bohr
natom = 20;
atom_Z = ones(natom,1)*1.2;          % 14 H atoms
%atom_Z = [1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6];
bond=1.6;
delta=0.0;
a1 = 8;
coord(1) = a1;
for i=2:natom 
    if mod(i,2)==1
        coord(i) = coord(i-1) + bond-delta;
    else
        coord(i) = coord(i-1) + bond+delta;
    end
end
%coord = [5.0 6.5   8.5 10.0   12.0 13.5   15.5 17.0];
%coord = [a1:dx:a1+dx*(natom-1)];     % cooridates
norb = ngrid;                        % number of orbitals to solve.
pen_coeff = 1e-4;                    % pen_coeff for regularizing vemb.
q_total = 20;                        % total electron number in system



%>>>>>>>>>>> EXX and RPA parameters <<<<<<<<<
omega_max = 5;
nfreq  = 10;

%>>>>>>>>>>>>>> definition of xcpp <<<<<<<<<<<<<<<
comm_chempot = true;
buffer    = cell(natom,100);
buffer{1} = [2 3];
buffer{2} = [1 3 4];
buffer{3} = [1 2 4 5];
buffer{4} = [2 3 5 6];
buffer{5} = [3 4 6 7];
buffer{6} = [4 5 7 8];
buffer{7} = [5 6 8 9];
buffer{8} = [6 7 9 10];
buffer{9} = [7 8 10 11];
buffer{10} = [8 9 11 12];
buffer{11} = [9 10 12 13];
buffer{12} = [10 11 13 14];
buffer{13} = [11 12 14 15];
buffer{14} = [12 13 15 16];
buffer{15} = [13 14 16];
buffer{16} = [14 15];

%>>>>>>> orbitals to have for the atom <<<<<<<<<
nLocOrb = zeros([natom,1]);
nLocOrb(1) = 3;
nLocOrb(2) = 3;
nLocOrb(3) = 3;
nLocOrb(4) = 3;
nLocOrb(5) = 3;
nLocOrb(6) = 3;
nLocOrb(7) = 3;
nLocOrb(8) = 3;
nLocOrb(9) = 3;
nLocOrb(10) = 3;
nLocOrb(11) = 3;
nLocOrb(12) = 3;
nLocOrb(13) = 3;
nLocOrb(14) = 3;
nLocOrb(15) = 3;
nLocOrb(16) = 3;

ksdft
epp
