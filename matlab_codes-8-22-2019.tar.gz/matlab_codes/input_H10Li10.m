clear all
%close all


% ========= common settings ==========
vac   = 10.0/27.2114; % in Hartree
reg_z = 1e-3;         % regularization parameter for solving z 
reg_vxc = 1e-3;       % regularization parameter for solving total vexx and vrpa
use_total_chi = false;
do_plot       = true;
do_patching   = true;
shift_epp     = false;
localizeOrbital = false;
do_exx = true;
do_rpa = false;
use_acfd_exx  = true;
one_step = false;
fix_cluster_q = false;


% >>>>>>>>>> system setup <<<<<<<<<<<<<
ion_soft = 1.0;                       % soft constant for v_ext potential
nspin  = 1;                           % number of spin
tsmear = 0.1/27.2114;                 % in hartree
natomH = 8;
natomLi = 8;
natom = natomH + natomLi;
atom_Z = ones(natom,1);               
atom_Z(1:natomH) = 1.2;
atom_Z(natomH+1:natom) = 3.6;
atom_Z_real  = ones(natom,1)*1.0;     % 14 H atoms
q_total   = natomH*1+natomLi*3;       % total electron number in system




% === define alternating H chain ===
eq_dist = 2.2;
bond = 1.8;   % equilirium distance (for LDA energy) for eq_dist=2.2
dist = (eq_dist*(natomH-1) - bond*natomH/2)/(natomH/2-1);
coord = zeros(natom,1);
coord(1) = 10.0;
for i=1:natomH
    if (mod(i,2)==1)
        coord(i+1)=coord(i) + bond;
    else
        coord(i+1)=coord(i) + dist;
    end
end

for i=1:natomLi
    if (i==1)
        coord(i+natomH)=coord(natomH) + 2.5;
    else
        coord(i+natomH)=coord(i+natomH-1) + 4.0;
    end
end


%>>>>>>>>  get box length <<<<<<<<<<<<<<<<<<<
box_len = coord(end)+10;            % box stars at zero, in bohr
ngrid   = floor(box_len*3)          % include the last point
norb    = ngrid;                    % number of orbitals to solve.


%>>>>>>>>>>> EXX and RPA parameters <<<<<<<<<
omega_max = 10;
nfreq     = 15;


%>>>>>>>>>>>>>> definition of xcep <<<<<<<<<<
comm_chempot = false;
xcep_comm_ef = false;


buffer = cell(natom,natom);
nbuf   = 3;
for j=1:natom
  buffer{j} = union(max(1,j-nbuf):1:j-1, j+1:1:min(j+nbuf,natom));
  buffer{j}
end


% set cluster electron numbers
q_cluster_fix = zeros([natom,1]);
for j=1:natom
    q_cluster_fix(j) = atom_Z_real(j);
    for ii=1:length(buffer{j})
        atomID = buffer{j}(ii);
        q_cluster_fix(j) = q_cluster_fix(j) + atom_Z_real(atomID);
    end
end
fix_cluster_q
q_cluster_fix




ksdft
xcep
%debug_XC_force

