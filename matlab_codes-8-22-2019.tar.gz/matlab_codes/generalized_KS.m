%
% solve the system using the generalized KS method.
%
function generalized_KS(x, vext, q_total, norb, ...
                     box_len, tsmear, e_ion, print_occ)

ngrid = length(vext);

vks = vext;
vks_old = vks;
ngrid = size(x,1);
h = x(2)-x(1);
tol_ksdft = 1e-7; % tolerance for stopping KSDFT

old_ke = 0.0;
ke = 0.0;
iter = 0;
resid1 = zeros([length(vext),1]);

fprintf('Solving generalized KS DFT ...\n')
fprintf('ngrid:  %d\n',ngrid)
fprintf('boxlen: %f\n',box_len)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generalized KS DFT loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

while (1)
    
  iter = iter +1;
  % solve KS equation 
  [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
  [occ,mu,Ef] = get_occ(norb,ee,q_total,tsmear,print_occ);

  % kinetic energy   
  old_ke = ke;
  ke = 0.0;
  for iband = 1:norb
      tmpke = ee(iband) - dot(ev(:,iband),ev(:,iband).*vks)*h;
      ke = ke + tmpke*occ(iband);
  end  
 
  % new density
  rho = sum(ev.^2*occ,2);
  
  % new exchange, hartree potentials
  [ex,vexch] = cal_ex(x, rho);
  [eh,vhart] = cal_hartree(x, rho);
  [ec,vcorr] = cal_LDA_correlation(x,rho); % we do not have correlation now
  
  % total energy  
  etotal = ke + ex + ec + eh + dot(rho,vext)*h + e_ion;
  %fprintf('it: %3d  etot: %f  ke: %f  eh: %f ex: %f\n',...
  %        iter,etotal,ke,eh,ex);
  fprintf('it: %3d  etot: %10.6f  ke: %8.6f  ex: %6.4f  ec: %6.4f  fermi: %8.4f\n',iter,etotal,ke,ex,ec,Ef);  
      
  % exit?
  if iter>=10 && abs(old_ke-ke)<tol_ksdft
      break;
  end
  
  %
  % update Kohn-Sham potential (Anderson mixing)
  % ref: http://www.physics.metu.edu.tr/~hande/teaching/741-lectures/lecture-10.pdf
  %      https://wiki.fysik.dtu.dk/gpaw/documentation/densitymix/densitymix.html
  %
  vks_old2 = vks_old;
  vks_old = vks;
  vks = vexch + vext + vcorr + vhart;  
  resid2 = resid1;          % residual 
  resid1 = vks - vks_old;   % residual 
  if iter>=3 
      % Anderson mixing
      anderson_mix = -dot(resid2,resid1-resid2)/dot(resid1-resid2,resid1-resid2);
      m_beta = 0.1;
      vks = (vks_old +m_beta*resid1)*anderson_mix ...
          + (vks_old2+m_beta*resid2)*(1-anderson_mix);
  else
      alpha = 0.8;
      vks = vks_old*alpha + (1-alpha)*vks;
  end
end


end 