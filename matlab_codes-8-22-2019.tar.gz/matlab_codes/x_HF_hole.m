%
% compute the exchange hole for the ACFD-derived exact exchange
% input: x0_index -> the index of the x point to consider its hole
%        ev: orbitals
%        ee: orbital energies
%        occ: occupation numbers
%

function [hole] = x_HF_hole(x,x0_index,rho,ev,ee,occ)

fprintf('\n\n x_HF_hole ...\n\n');

nband = size(ev,2);
ngrid = size(ev,1);
dx = x(2)-x(1);

% make Coulumb matrix
coul = zeros(ngrid);
for q=1:ngrid
    for q2=1:ngrid
        dist = x(q)-x(q2);
        coul(q,q2) = 1.0/sqrt(dist*dist + 1.0);
    end
end


hole = zeros([ngrid,1]); % x hole for each points
for ip=1:ngrid
    % compute exchange hole for each point
    for ib=1:nband
        for ib2=1:nband
            
            vec1 = ev(ip,ib)*ev(ip,ib2);
            vec2 = ev(x0_index,ib)*ev(x0_index,ib2);
            
            %               factor = (1-sign(ee(ib2)-ee(ib)));
            %               if occ(ib)<1e-8 || factor < 1e-8
            %                   continue
            %               end
            %hole(ip) = hole(ip) - factor*occ(ib)/2*vec1*vec2/rho(x0_index);
            hole(ip) = hole(ip) - occ(ib2)/2*occ(ib)/2*vec1*vec2/rho(x0_index)*2;
        end
    end
end

%%%%%%%%%%%% debug the code %%%%%%%%%%%%%%
[ex0,exx_eps0] = calc_HF_energy(ev,ee,occ,x);
fprintf('exchange energy density from calc_exx_energy(): %f\n',exx_eps0(x0_index));

% compute exchange energy desnity at x0_index
eps = 0.0;
for ip=1:ngrid
    eps = eps + rho(x0_index)*coul(x0_index,ip)*hole(ip)*dx/2;
end
fprintf('Exchange energy density at x0 is %f. Do they match?\n',eps);

end