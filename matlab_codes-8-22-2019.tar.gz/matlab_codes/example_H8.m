
ion_soft = 1.0;                      % soft constant for v_ext potential
nspin = 1;                           % number of spin
tsmear = 0.1/27.2114;                % in hartree
ngrid = 80;                          % include the last point
box_len = 25;                        % box stars at zero, in bohr
natom = 6;
atom_Z = ones(natom,1)*1.2;          % 14 H atoms
atom_Z = [1.2 1.2 1.2 1.2 2.0 2.0];
dx=2.0;
%a1 = 5;
coord = [5 7.0 10.0 12.0 15.0 17.0];
%coord = [a1:dx:a1+dx*(natom-1)];     % cooridates  
norb = ngrid;                        % number of orbitals to solve.
pen_coeff = 1e-4;                    % pen_coeff for regularizing vemb.
q_total = 8;                         % total electron number in system

