

%~~~~~~~~~~~~~~~~~~~~~~
% plotting
%~~~~~~~~~~~~~~~~~~~~~~

if (do_patching)
    fprintf('\nplotting EPS files...\n')
    if (do_rpa && do_exx)
        figure('Visible','off');
        %plot(x,vxc_patched,'r-',x,vexx0+vrpa0,'k-',x,vxc_patched_noshift,'b--');
        plot(x,vexx0+vrpa0,'k-',x,vxc_xcep,'r-');
        title('V_{EXX}+V_{RPA}')
        legend('benchmark','XCEP');
        print('-depsc2','-r300','vxc_compare.eps');
        figure('Visible','off');
        %
        figure('Visible','off');
        plot(x,dExx_dVks+dErpa_dVks,'ro-',x,dEdV0_rpa+dEdV0_exx,'k-');
        title('d(EXX+RPA)/dV_{KS}')
        legend('XCEP','benchmark');
        print('-depsc2','-r300','dExc_dV_compare.eps');
    end
    
    if (do_exx)
        figure('Visible','off');
        plot(x,vexx0,'k-',x,vexx_xcep,'r-');
        title('V_{EXX}');
        legend('benchmark','XCEP');
        print('-depsc2','-r300','vexx_compare.eps');
        if iter ==1
            save -ascii vexx0_iter0.txt vexx0
            save -ascii vexx_xcep_iter0.txt vexx_xcep
        else
            save -ascii vexx0.txt vexx0
            save -ascii vexx_xcep.txt vexx_xcep
        end
        %
        figure('Visible','off');
        plot(x,dExx_dVks,'ro-',x,dEdV0_exx,'k-');
        title('dEXX/dV_{KS}');
        legend('XCEP','benchmark');
        print('-depsc2','-r300','dEXX_dV_compare.eps');
    end
    
    if (do_rpa)
        figure('Visible','off');
        plot(x,vrpa0,'r-',x,vrpa_xcep,'k-');
        title('V_{RPA} compare');
        legend('benchmark','XCEP');
        print('-depsc2','-r300','vrpa_compare.eps');
        if iter==1
            save -ascii vrpa0_iter0.txt vrpa0
            save -ascii vrpa_xcep_iter0.txt vrpa_xcep
        else
            save -ascii vrpa0.txt vrpa0
            save -ascii vrpa_xcep.txt vrpa_xcep
        end
        %
        figure('Visible','off');
        title('dE_{RPA}/dV_{KS} compare');
        plot(x,dErpa_dVks,'ro-',x,dEdV0_rpa,'k-');
        legend('XCEP','benchmark');
        print('-depsc2','-r300','dRPA_dV_compare.eps');
    end
    
else
    %%%%%%%%%%%%%%%%% no XCEP %%%%%%%%%%%%%%%%    
    
    fprintf('\nplotting EPS files...\n')
    if (do_rpa && do_exx)
        figure('Visible','off');        
        plot(x,vrpa+vexch,'k-');
        title('V_{EXX}+V_{RPA}')
        legend('benchmark');
        print('-depsc2','-r300','vxc.eps');
        figure('Visible','off');
    end
    
    if (do_exx)
        figure('Visible','off');
        plot(x,vexch,'k-');
        title('V_{EXX}');
        legend('benchmark');
        print('-depsc2','-r300','vexx.eps');
    end
    
    if (do_rpa)
        figure('Visible','off');
        plot(x,vrpa,'k-');
        title('V_{RPA} compare');
        legend('benchmark');
        print('-depsc2','-r300','vrpa.eps');
    end
end