clear all
close all

input_file 

ksdft 

epp 