

% reconstruct cluster's KS system
q_tmp = 18;
[ee,ev] = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
[occ,mu] = get_occ(norb,ee,q_tmp,tsmear,false);
rho = sum(ev.^2*occ,2);



%%%%%%%%%%%%%%%%%% plot EXX hole %%%%%%%%%%%%%%%
x0_index = 70;
hole_exx = x_hole(x,x0_index,rho,ev,ee,occ);
hole_HF = x_HF_hole(x,x0_index,rho,ev,ee,occ);
figure
plot(x,hole_exx,x,hole_HF)
hold on
plot(x(x0_index),0,'x')
title('exchange hole')
sum(hole_exx)*h
sum(hole_HF)*h


%%%%%%%%%%%%%%%%%% plot RPA correlation hole %%%%%%%%%%%%%%%

hole_rpa = rpa_corr_hole(x,x0_index,rho,tsmear,mu,ev,ee,occ,nfreq,omega_max);
figure
plot(hole_rpa)
title('RPA correlation hole')
hold on
plot(x0_index,0,'x')


figure
plot(x,hole_exx,x,hole_rpa,x,hole_exx+hole_rpa)
hold on
plot(x(x0_index),0,'x')

x(x0_index)
