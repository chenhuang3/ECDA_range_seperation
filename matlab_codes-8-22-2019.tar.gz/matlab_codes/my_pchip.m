x = [1 2 3];
y = [3.4  -10.6  10.0];
plot(x,y,'-b')

%%%%%%%%%%%% get pchip %%%%%%%%%%

t = [1:0.1:3];
t1 = [1:0.1:2];
t2 = [2:0.1:3];
p  = pchip(x,y,t);
hold on
plot(t,p,'o-')


for k=1:length(t)
    [C(k),Cp(k)] = my_pchip_function(x,y,t(k));
    C1 = my_pchip_function(x,y,t(k)+0.01);
    C2 = my_pchip_function(x,y,t(k)-0.01);
    Cptest(k) = (C1-C2)/2/0.01;
end

hold on
plot(t,C,'xk',t,Cp,'ro-',t,Cptest,'y-')
