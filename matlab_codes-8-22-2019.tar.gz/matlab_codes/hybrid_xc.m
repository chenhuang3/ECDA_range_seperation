function [Ex,Vx] = hybrid_xc(ev,ee,occ,x,alpha)


% EXX
if use_acfd_exx
    [ex,exx_eps] = calc_exx_energy(ev,ee,occ,x);
else
    [ex] = calc_HF_energy(ev,ee,occ,x);
end


level_shift = false;
[vexch] = calc_exx_potential(x,vks,q_total,q_total,tsmear,norb,...
    false,use_acfd_exx,level_shift,v_LS,false,mu,reg_vxc);


end