%
% This wrapper makes two things 
%     1) make W --> -W  for minimization 
%     2) reshape input vemb to 1-D
%     3) reshape output grad to 1-D
%
function [W,g] = wrap_W_dm(vemb,nspin,x,comm_chempot,box_len,ngrid,norb,...
    tsmear,q_clu,q_env,vks_clu,vks_env,dm_tot)

    vemb = reshape(vemb,ngrid,ngrid);
    
%     dm_tot = (dm_tot+dm_tot')/2.0;
%     vemb   = (vemb + vemb')/2.0;
    
    [W,g,rho_clu,rho_env]=W_dm(vemb,nspin,x,comm_chempot,box_len,ngrid,norb,...
        tsmear,q_clu,q_env,vks_clu,vks_env,dm_tot);
    
    W= -W;
    g = -g;    
    g = reshape(g,1,ngrid*ngrid);
end 
