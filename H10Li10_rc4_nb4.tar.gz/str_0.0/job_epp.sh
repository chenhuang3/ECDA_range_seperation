#!/bin/bash
#SBATCH -J "xcep"
#SBATCH -N 1
#SBATCH --ntasks-per-node=16
####SBATCH --ntasks=16
#SBATCH -p huang_q
####SBATCH -p  backfill2
#SBATCH --time=48:00:00
#SBATCH -o log.txt
#SBATCH -e output.e


module purge 
module load matlab

codePATH=/gpfs/research/huang/chenh/jobs_ECDA_range_sep/matlab_codes

export MATLABPATH=$SLURM_SUBMIT_DIR:$codePATH

ulimit -s unlimited
cd $SLURM_SUBMIT_DIR/

rm *.eps


matlab  -nodisplay -nodesktop -r "run driver1.m"

wait

