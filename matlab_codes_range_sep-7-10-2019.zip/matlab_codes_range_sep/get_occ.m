%
% get the occupation number for the given eigenvalues (ee)
% norb:  number of orbitals 
% ee:   ee(1:norb) eigenvalues 
% tsmear: smearing temperature (in hartree)
% mu: chemical potential
% ne: electron number 
%
function [occ, mu] = get_occ(norb, ee, ne, tsmear, print)

    occ = zeros(norb,1);
    
    max_iter = 100000;
    b_mu = ee(1)-100.0;
    u_mu = ee(end)+100.0;

    db = 2.0;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % bisecting to get the mu and occ 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    iter = 0;
    while (1)
        
      iter = iter+1;
      mu = ( b_mu + u_mu )/2.0;
    
      % get total electron number in the subsystem
      old_occ = occ;
      tmp_Q = 0.0;
      for j = 1:norb
         expo = (ee(j)-mu)/ tsmear;
         occ(j) = db*1.0/( exp( expo ) +1.0);
         tmp_Q = tmp_Q + occ(j);
      end
      
      % bisecting
      if tmp_Q > ne 
         u_mu = mu;
      else 
         b_mu = mu;      
      end
      
      % cannot converge after 100000 bisecting 
      if iter>100000
          ee
          ne
          fprintf('get_occ: upper: %f lower: %f\n',u_mu,b_mu);
          abs(tmp_Q-ne)
          max(abs(old_occ-occ))
          abs(b_mu-u_mu)
          stop
      end
      
      % converge?
      if abs(tmp_Q-ne)<1e-12 && iter>=3 && ...
         max(abs(old_occ-occ))<1e-12 && abs(b_mu-u_mu)<1e-12
          break;
      end
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % end of bisecting
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % display 
    occupied = 0;
    for j=1:norb
        if (occ(j)>1e-12)
            occupied = occupied + 1;
        end
    end    
    if print
        fprintf('band       eigen     occ \n');
        for j=1:min(occupied+20,norb)
            fprintf('%3d  %12.6f  %8.6f\n',j,ee(j),occ(j));
        end
    end    
end
