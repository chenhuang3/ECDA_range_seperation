clear r 
for i=1:ngrid
%     g = [1/200,1/150,1/100];
%     y=[vxc200(i),vxc150_int(i),vxc100_int(i)];
%     P = polyfit(g,y,1);
%     r(i,1) = polyval(P,0.0)
%     
    g = [1/200,1/150];
    y=[vxc200(i),vxc150_int(i)];
    P = polyfit(g,y,1);
    r(i,1) = polyval(P,0.0)    
end

figure
plot(x200,r)


figure
plot(x200,vxc100_int,x200,vxc150_int,x200,vxc200)



%%%%%%%%%%%%%%%%%%%%%
x380 = [0:95/(380-1):95];
x427 = [0:95/(427-1):95];
plot(x380,vxc380,x427,vxc427)
vxc380_fit = interp1(x380,vxc380,x427);
figure
plot(x427,vxc380_fit,x427,vxc427)


clear r 
for i=1:427
%     g = [1/200,1/150,1/100];
%     y=[vxc200(i),vxc150_int(i),vxc100_int(i)];
%     P = polyfit(g,y,1);
%     r(i,1) = polyval(P,0.0)
%     
    g = [1/427,1/380];
    y=[vxc427(i),vxc380_fit(i)];
    P = polyfit(g,y,1);
    r(i,1) = polyval(P,0.0);
end

figure
plot(x427,r)


%%%%%%%%%%%%%%%%%
load tmp2
x380 = [0:95/(380-1):95];
x427 = [0:95/(427-1):95];
x = [0:95/(522-1):95];
vxc380_fit = interp1(x380,vxc380,x);
vxc427_fit = interp1(x427,vxc427,x);

plot(x,vxc380_fit,x,vxc427_fit,x,vxc522)