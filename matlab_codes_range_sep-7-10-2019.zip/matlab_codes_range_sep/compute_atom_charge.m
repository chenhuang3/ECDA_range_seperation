function [q_atom] = compute_atom_charge(natom, x, atom_weight, rho)

h = x(2)-x(1);

fprintf('\n------- number of electrons on atoms ------\n');
fprintf('atom_ID   N_electron\n')
for ia=1:natom
   q_atom(ia,1) = sum(atom_weight(:,ia).*rho(:))*h;
   fprintf('%3d   %12.4f\n',ia,q_atom(ia));
end

end
