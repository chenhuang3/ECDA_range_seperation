%
%  inwfr: input orbitals (normalized)
%  occ: occupation numbers (0 < occ < 2)
%
%  output: 
%    outwfr: is normalized 
%    newocc: is the new occupation numbers from 0 to 2.
%

function [outwfr,newocc] = localization_MOs_fracOcc(x,inwfr,occ)

norb = size(inwfr,2);
ngrid = size(inwfr,1);
h = x(2)-x(1);

occ_p = sqrt(occ/2.0);

for j=1:norb
    pinwfr(:,j) = inwfr(:,j)*occ_p;
end

U = eye(norb);
points = zeros(ngrid,1);

% get the cooridates of all the grid points
for i=1:ngrid
    points(i) = (i-1)*h;
end

%%%%%%%%%%%%%%%%%%%%%%%%%
% cg loop %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%

for icg=1:10000
    
    new_wfr = pinwfr*U;
    
    [f,g] = cost_func_boys_fracOcc(norb,points,new_wfr,inwfr,h);
    
    g = g*U' - U*g';
    
    g_norm = norm(g)*h;
        
    if (icg>10 && g_norm < 1e-10)
        disp('done')
        break;
    end
    
    if (mod(icg-1,5)==0) 
        fprintf('loc_MO: cg_iter: %4d cost_fun: %12.4f g_norm: %8.2e \n',icg,f,g_norm);
    end
    if (icg>=10 && g_norm<1e-3) 
        break
    end
    
    %%%%%%%%%%% cg direction %%%%%%%%%%%
    if icg==1
        cg_dir = g;
    else
        cg_gamma =  sum(sum(g.*(g-g_old))) / sum(sum(g_old.*g_old));
        cg_gamma = max(0.0,cg_gamma);
        %cg_gamma = 0.0;
        cg_dir = g + cg_gamma*cg_dir;        
    end
    
    if sum(sum(cg_dir.*g))<0
        cg_dir = g;
    end
    g_old = g;
    
    temp_A = cg_dir * 1i;
    [ev,ee] = eig(temp_A);   
    
    mu = 0.0;
    dstep = 0.01/max(abs(diag(ee)));
    mode_calc = 'BOUND';
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%% line search %%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %fprintf('line search...\n');
    iline = 0;
    while (1)
        iline = iline+1;
        % new U matrix
        D = eye(norb);
        for q=1:norb
            dtmp = -mu*ee(q,q);
            D(q,q) = cos(dtmp) + 1i*sin(dtmp);
        end
        % tmpU = eV*exp(-I*mu*ee)*eV'*U
        tmpU = ev * D;
        tmpU = tmpU * conj(transpose(ev));
        tmpU = tmpU * U;
        
        % Unitary transformation
        outwfr = pinwfr * tmpU;
        
        [f,g] = cost_func_boys_fracOcc(norb,points,outwfr,inwfr,h);
        
        mat_tmp = g*transpose(tmpU);
        mat_tmp = mat_tmp * transpose(cg_dir);
        
        % compute d(cost_function) / d (mu)
        % Eq. 14 of the paper
        % Abrudan et al. / Signal Processing 89 (2009) 1704 1714
        dL_dmu = 0.0;
        % trace
        for q=1:norb
            dL_dmu = dL_dmu + real(mat_tmp(q,q));
        end
        
        %
        % search for boundary
        %
        if strcmp(mode_calc,'BOUND') ==1
            if iline==1 && dL_dmu<0
                disp('error, dLdmu<0 at the start of line serach');
                stop
            end
            if iline==1
                dL_dmu0 = dL_dmu;
            end
            if dL_dmu<0.0
                right_mu = mu;
                left_mu = mu -dstep ;
                mode_calc = 'BISECT';
                mu = (right_mu + left_mu)/2.0;
                %fprintf('left_mu, right_mu: %f  %f  \n',left_mu,right_mu);
                continue
            end
            %fprintf('mu: %f  cost: %f  dL_dmu: %f\n',mu,f,dL_dmu);
            iline = iline + 1;
            mu = mu + dstep;
        end
        
        %%%%%%%%%%% bisecting %%%%%%%%%
        if strcmp(mode_calc,'BISECT') == 1
            if dL_dmu < 0
                right_mu = mu;
            else
                left_mu = mu;
            end
            % if gradient drops to 10% exit line search
            if  abs(dL_dmu) < abs(dL_dmu0)*0.1
                mu_min = mu;
                %fprintf('done bisecting, mu=%f \n',mu_min);
                break;
            else
                mu = (right_mu + left_mu)/2.0;
              %  fprintf('left/right mu: %f  %f\n',left_mu,right_mu);
            end
        end
    end % loop for line search
    
    % make new U matrix
    D = eye(norb);
    for q=1:norb
        dtmp = -mu_min*ee(q,q);
        D(q,q) = cos(dtmp) + 1i*sin(dtmp);
    end
    tmpU = ev * D;
    tmpU = tmpU * conj(transpose(ev));
    U    = tmpU * U;    
    
    %
    % purify U matrix, due to numerical errors, 
    % U becomes not very unitary over time! 
    % We need to make it unitary by Gram�Schmidt  orthonormalising
    %
    orth = zeros(norb);
    for ii=1:norb
        orth(:,ii) = real(U(:,ii));
        % all previous vectors
        for jj=1:ii-1
           orth(:,ii) = orth(:,ii)- ...
               sum( orth(:,ii).*orth(:,jj) ) * orth(:,jj);
        end
        % normalize
        orth(:,ii) = orth(:,ii) / sqrt(sum(orth(:,ii).^2));
    end
    U = orth;
    
end  % cg loop for localizing orbitals


for j=1:norb
    newocc(j) = 2.0*sum(new_wfr(:,j).^2*h);
    outwfr(:,j) = new_wfr(:,j)/sqrt(newocc(j)/2.0);
end

end


