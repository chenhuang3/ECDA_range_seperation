clear all
close all

do_parallel = -1;

% start the matlabpool with maximum available workers
% control how many workers by setting ntasks in your sbatch script
if do_parallel==1 
    pc = parcluster('local')
    parpool(pc)
end

omega_tiny = 1e-6;

input_file

ksdft

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute the xc kernel 
%%%%%%%%%%%%%%%%%%%%%%%%%%%

dVxc_dVks = zeros(ngrid,ngrid);
delta=0.01;
v_LS = zeros([ngrid,ngrid]);

% EX kernel 
dVxc_dVks = zeros(ngrid,ngrid);
delta=0.01;
v_LS = zeros([ngrid,ngrid]);

for ipoint = 1:ngrid
    
    vks_tmp = vks;
    vks_tmp(ipoint) = vks(ipoint)+delta;
    
    fprintf('ipoint: %d / %d\n',ipoint,ngrid);
    [ee1,ev1] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    [occ1,mu_tmp] = get_occ(norb,ee1,q_total,tsmear,false);
    use_acfd_exx = 1;
    [vexx1, dEdV_exx1] = ...
        calc_exx_potential(x,vks_tmp,q_total,q_total,tsmear,norb, ...
        false,use_acfd_exx,false,v_LS,false);
    
    %--------------    
    vks_tmp = vks;
    vks_tmp(ipoint) = vks(ipoint)-delta;
        
    [ee1,ev1] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    [occ1,mu_tmp] = get_occ(norb,ee1,q_total,tsmear,false);
    rho = sum(ev1.^2*occ1,2);
    use_acfd_exx = 1;
    [vexx2, dEdV_exx2] = ...
        calc_exx_potential(x,vks_tmp,q_total,q_total,tsmear,norb, ...
        false,use_acfd_exx,false,v_LS,false);    
    
    dVxc_dVks(:,ipoint)=(vexx1-vexx2)/delta/2;  
end

[ chi ]  = calc_chi(ev, ee, occ, 1e-6);
figure
surf(dVxc_dVks)

reg_lambda = 1e-3;
y = eye(ngrid);
y = diag(y);         % make y = [1,1,1,....,1] the null space vector
y = y/norm(y);       % normalize y
AA = chi + 10*y*y';   % add teh null space in

for ipt=1:ngrid    
    %fxc(ipt,:) = lsqr(AA,dVxc_dVks(ipt,:)');
    fxc(ipt,:) = lsqr_reg(AA,dVxc_dVks(ipt,:)',reg_lambda,1e-10,10000)+7;    
end
fxc = fxc / h;

figure
[X,Y] = meshgrid(0:box_len/(ngrid-1):box_len);
surf(X,Y,fxc)
for j=1:natom
    hold on
    plot(coord(j),coord(j),'x')
end

save ex_kernel.txt fxc -ascii

stop







for ipoint = 1:ngrid
    
    vks_tmp = vks;
    vks_tmp(ipoint) = vks(ipoint)+2*delta;
    
    fprintf('ipoint: %d / %d\n',ipoint,ngrid);
    [ee1,ev1] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    [occ1,mu_tmp] = get_occ(norb,ee1,q_total,tsmear,false);
    rho = sum(ev1.^2*occ1,2);
    [dtmp,vexx1] = cal_ex (x,rho);
    
    
    vks_tmp = vks;
    vks_tmp(ipoint) = vks(ipoint)-2*delta;
    
    fprintf('ipoint: %d / %d\n',ipoint,ngrid);
    [ee1,ev1] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    [occ1,mu_tmp] = get_occ(norb,ee1,q_total,tsmear,false);
    rho = sum(ev1.^2*occ1,2);
    [dtmp,vexx2] = cal_ex (x,rho);    
        
    %use_acfd_exx = 1;
    %[vexx1, dEdV_exx1] = ...
    %    calc_exx_potential(x,vks_tmp,q_total,q_total,sub_tsmear,norb, ...
    %    false,use_acfd_exx,false,v_LS,false);
    

    
    % 
    vks_tmp = vks;
    vks_tmp(ipoint) = vks(ipoint)+delta;
    
    fprintf('ipoint: %d / %d\n',ipoint,ngrid);
    [ee1,ev1] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    [occ1,mu_tmp] = get_occ(norb,ee1,q_total,tsmear,false);
    rho = sum(ev1.^2*occ1,2);
    [dtmp,vexx3] = cal_ex (x,rho);     
    
    
    vks_tmp = vks;
    vks_tmp(ipoint) = vks(ipoint)-delta;
    
    fprintf('ipoint: %d / %d\n',ipoint,ngrid);
    [ee1,ev1] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    [occ1,mu_tmp] = get_occ(norb,ee1,q_total,tsmear,false);
    rho = sum(ev1.^2*occ1,2);
    [dtmp,vexx4] = cal_ex (x,rho);     
    
    %use_acfd_exx = 1;
    %[vexx2, dEdV_exx2] = ...
    %    calc_exx_potential(x,vks_tmp,q_total,q_total,sub_tsmear,norb, ...
    %    false,use_acfd_exx,false,v_LS,false);    
    
       
    %dVxc_dVks(:,ipoint)=(vexx1-vexx2)/delta/2;  
    dVxc_dVks(:,ipoint) = (-vexx1+vexx2+8*vexx3-8*vexx4)/12/delta;
end

[ chi ]  = calc_chi(ev, ee, occ, 1e-6);

figure
surf(dVxc_dVks)

reg_lambda = 1e-3;
y = eye(ngrid);
y = diag(y);         % make y = [1,1,1,....,1] the null space vector
y = y/norm(y);       % normalize y
AA = chi + 10*y*y';   % add teh null space in

for ipt=1:ngrid    
    %fxc(ipt,:) = lsqr(AA,dVxc_dVks(ipt,:)');
    fxc(ipt,:) = lsqr_reg(AA,dVxc_dVks(ipt,:)',reg_lambda,1e-10,10000)+7;    
end
fxc = fxc / h;

figure
[X,Y] = meshgrid(0:box_len/(ngrid-1):box_len);
surf(X,Y,fxc)
for j=1:natom
    hold on
    plot(coord(j),coord(j),'x')
end



figure
[X,Y] = meshgrid(0:box_len/(ngrid-1):box_len);
surf(X,Y,chi)
for j=1:natom
    hold on
    plot(coord(j),coord(j),'x')
end




% LDA%%%%%%%%%%%%%%%%%%%%%%%
dtmp = 0.001;
for ipoint = 1:ngrid
    ipoint
    rho_tmp = rho;
    rho_tmp(ipoint) = rho(ipoint)+dtmp;
    [ex2,vexx1] = cal_ex(x,rho_tmp);
    rho_tmp = rho;
    rho_tmp(ipoint) = rho(ipoint)-dtmp;
    [ex1,vexx2] = cal_ex(x,rho_tmp);
    for ip2=1:ngrid
        fxc2(ipoint,ip2) = (vexx1(ip2)-vexx2(ip2))/2/dtmp;
    end
end

% LDA%%%%%%%%%%%%%%%%%%%%%%%
dtmp = 0.001;
fxc2 = zeros([ngrid,ngrid]);
for ipoint = 1:ngrid
    ipoint
    rho_tmp = rho;
    rho_tmp(ipoint) = rho(ipoint)+dtmp;
    [dtmp1,vexx1] = cal_ex(x,rho_tmp);
    rho_tmp = rho;
    rho_tmp(ipoint) = rho(ipoint)-dtmp;
    [dtmp2,vexx2] = cal_ex(x,rho_tmp);
    rho_tmp = rho;
    [dtmp0,vexx2] = cal_ex(x,rho_tmp);
fxc2(ipoint,ipoint) = (dtmp1+dtmp2-dtmp0*2)/2/dtmp;
end

figure
[X,Y] = meshgrid(0:box_len/(ngrid-1):box_len);
surf(X,Y,fxc2)
for j=1:natom
    hold on
    plot(coord(j),coord(j),'x')
end



















figure
[X,Y] = meshgrid(0:box_len/(ngrid-1):box_len);
contour(X,Y,chi);
for j=1:natom
    hold on
    plot(coord(j),coord(j),'x')
end


figure
[X,Y] = meshgrid(0:box_len/(ngrid-1):box_len);
mesh(X,Y,chi);
for j=1:natom
    hold on
    plot(coord(j),coord(j),'x')
end
grid off


for i=1:ngrid
    [vexch] = calc_exx_potential(x,vks,q_total,q_total,tsmear,norb,...
    false,use_acfd_exx,false,v_LS,false);
end
