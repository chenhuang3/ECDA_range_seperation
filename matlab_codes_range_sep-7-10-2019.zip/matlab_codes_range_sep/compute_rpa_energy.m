%  Compute RPA energy
%
%  output: rpa is the RPA energy
%          eps_rps is the RPA energy density, E_{RPA} = \int eps_rpa(r) dr
%
function [rpa, eps] = compute_rpa_energy(omega_max,nfreq,x,ev,ee,...
    occ,print,mu,tsmear)

if nargin~=9
    fprintf('compute_rpa_energy => nargin is not 9, BUG stop.')
    stop
end


ngrid = size(ev,1);
eps = zeros(ngrid,1);
soft_cutoff = 1.0;


%=======================
% make Coulumb matrix
%=======================
coul = zeros(ngrid);
for q=1:ngrid
    for q2=1:ngrid
        dist = x(q)-x(q2);
        coul(q,q2) = 1.0/sqrt(dist*dist + soft_cutoff);
    end
end


%=========================================
% make Gauss-Legendre points and weights
%=========================================
%[freq,int_w]=lgwt(nfreq,0,omega_max);

[freq,int_w]=lgwt_RPA(nfreq,omega_max);

if print
    fprintf('\nenter compute_rpa_energy()...\n');
    fprintf('omega_max: %8.2f  nfreq: %d\n',omega_max,nfreq);
end


%=======================================
% integration over frequence
%=======================================
for q=1:nfreq
    chi = calc_chi(mu, tsmear, ev, ee, occ, freq(q) );
    %chi = calc_chi_extrap(x, mu, tsmear, ev, ee, occ, freq(q) );
    [rpa_w(q),eps_tmp] = calc_rpa_corr_omega(x,chi,coul);
    if print
        fprintf('[%3i/%3i] omega: %10.6f  rpa(omega): %10.6f \n',...
            q,nfreq,freq(q),rpa_w(q));
    end
    eps = eps + eps_tmp*int_w(q);
end

% integrate RPA energy (just summing up the weighted nodes)
rpa = sum(rpa_w'.*int_w);


%plot(freq,rpa_w,'bo-');
if print
    fprintf('done RPA energy! RPA energy: %f\n\n',rpa);
end

end
