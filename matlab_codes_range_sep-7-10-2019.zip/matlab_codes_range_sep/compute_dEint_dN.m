function [dEint_dN] = compute_dEint_dN(tsmear,q_clu,vks,vemb,x,box_len)


ngrid = length(x);
norb = length(x);

if (nspin==2)
    fprintf('compute_dEint_dN() has not been implemented for nspin=2 stop')
    stop
end


%%%%%%%%%%%%%%%%%% finite difference method %%%%%%%%%%%%%%%%
Eint = zeros(2,1);
step = 0.01;

for j=1:2
    
    [ee,ev] = solve_ks_eq(ngrid,norb,0.0,box_len,vks+vemb);
    
    if j==1
        [occ,mu] = get_occ(norb,ee,q_clu+step,tsmear,false);
    else
        [occ,mu] = get_occ(norb,ee,q_clu-step,tsmear,false);
    end    
    
    entropy = 0.0;
    
    for q=1:norb
        % cluster entropy
        occ_tmp = occ(q)/2.0;
        if abs(occ_tmp-1.0)>1e-20 && abs(occ_tmp)>1e-20
            entropy = entropy + tsmear*occ_tmp*log(occ_tmp)+tsmear*(1-occ_tmp)*log(1-occ_tmp);
        end        
    end    
    entropy = entropy*2.0;   
    
    Eint(j) = dot(occ,ee) + entropy + h*dot(vemb,rho_tot); 
end

dEint_dN = (Eint(1)-Eint(2))/step/2;


end