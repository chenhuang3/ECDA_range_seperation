function [rpa, eps] = calc_rpa_corr_omega(x, chi, coul)

if nargin~=3 
    fprintf('calc_rpa_corr_omega => nargin is not 3, BUG stop.')
    stop
end

dim = size(chi,1);
dx = x(2)-x(1);


%%%%%%%%% old and wrong code %%%%%%%%%%%%%%%%
% sqrt_coul = sqrtm(coul); % such that sqrt_coul*sqrt_coul = coul
% mat = sqrt_coul*chi*sqrt_coul;
% [ev,ee] = eig(mat);
% rpa = sum(log(1-diag(ee)) + diag(ee));
% rpa = rpa*dx*dx/2/pi


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% We compute the eigenvalues of vc^{1/2} \chi vc^{1/2}
% Generally speaking, if we compute the eigenvalue of M(r,r')
% we actually solve the integral equation:
%
%   \int M(r,r')g(r')dr' = lambda*g(r)
%
% In matrix form, this is
%
%   \sum_i M(r_i,r_j)g(r_j)*dx = lambda*g(r_i)
%
% where r_i and r_j are grid points.
% Thus, we solve the eigenvalues of matrix M*dx rather than M.
%
%
% Another way to consider the vc*chi matrix is to consider it is
% expanded in the normalized basis phi(x) which is 1/sqrt(dx) at the
% point x and 0 in all other region. This makes \phi is normalized to 1
% that is, \int dx \phi(x)^2 = 1. Then the (i,j) matrix element is
%
%  \int dx'' phi(x'') \int dx M(x'',x') phi(x') = M(x_i,x_j)*dx
%
% Again, we in fact deal with M(x_i,x_j)*dx rather than M(x_i,x_j).
%
%
% In fact, we can adopt an even simpler approach:
% For any function f(x,x'), we just expand it with the basis phi(x)
% [phi(x) which is 1/sqrt(dx) at the point x and 0 in all other region.].
%
% Then the (i,j) element of matrix F is just
%
%      F_ij = f(x_i,x_j)*dx
%
% For example, chi(x,x') in the matrix rep. is just CHI=chi(x_i,x_j)*dx
%              vc(x,x') in the matrix rep. is just VC=vc(x_i,x_j)*dx
%              Then vc(x,x')*chi(x,x') in the matrix rep. is just CHI*VC
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


VC = coul*dx;    % expand coul(x,x') in basis functions (grid points)
CHI = chi*dx;    % expand chi(x,x')  in basis functions (grid points)

% no symmetric formulation to be consistent with long-range short-range
% method.
mat = VC*CHI;
[ev,ee] = eig(mat);
rpa = sum(log(1-diag(ee)) + diag(ee));
rpa = rpa/2/pi;

% sqrtVC = sqrtm(VC);  % if matrix is ngeative we cannot do sqrtm(M)
% mat = sqrtVC*(CHI)*sqrtVC;
% [ev,ee] = eig(mat);
% rpa = sum(log(1-diag(ee)) + diag(ee));
% rpa = rpa/2/pi;


% RPA energy density
mat1 = logm(eye(dim)-mat) + mat;
eps = diag(mat1)/2/pi;
eps = eps/dx;      % convert to energy density
eps = real(eps);


end
