%
% compute -TS based on occupation numbers and smearing 
%
function [TS] = get_entropy(ngrid,occ,tsmear)

TS = 0.0;

for ii=1:ngrid
    occ_tmp = occ(ii)/2;
    if abs(occ_tmp-1.0)>1e-10 && abs(occ_tmp)>1e-10
        TS = TS - ...
            2*(tsmear*occ_tmp*log(occ_tmp)+tsmear*(1-occ_tmp)*log(1-occ_tmp));
    end
end


end