function [ dEdV ] = calc_exx_dEdV(ngrid,norb,tsmear,q,x,vks,h,box_len,acfd,levelShift,v_LS)
   % 
   % finie difference for computing dE_exx / dV_KS
   %    
   second_order = false;
   deltaV = 0.001;
   
   fprintf('\nIn calc_exx_dExcdV(). computing dEdV for exact exchange ...\n')
   
   parfor j = 1:ngrid       
       if (mod(j,10)==0) 
           if second_order
               fprintf('[dExx_dV] progress %3d/%3d <2nd order>\n',j,ngrid);
           else
               fprintf('[dExx_dV] progress %3d/%3d <4th order>\n',j,ngrid);
           end
       end
       if (second_order)
           
           % second order finite difference  
           vks_tmp = vks;
           vks_tmp(j) = vks(j)+deltaV;
           if levelShift 
               [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
           else
               [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
           end
           [occ,mu] = get_occ(norb,ee,q,tsmear,false);
           if acfd
               [ex1] = calc_exx_energy(ev,ee,occ,x);
           else
               [ex1] = calc_HF_energy(ev,ee,occ,x);
           end
           
           vks_tmp = vks;
           vks_tmp(j) = vks(j)-deltaV;
           if levelShift 
               [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
           else
               [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
           end
           [occ,mu] = get_occ(norb,ee,q,tsmear,false);
           if acfd
               [ex2] = calc_exx_energy(ev,ee,occ,x);
           else
               [ex2] = calc_HF_energy(ev,ee,occ,x);
           end
           
           dEdV(j) = (ex1-ex2)/2/deltaV;
       else
           % fourth order 
           vks_tmp = vks;
           vks_tmp(j) = vks(j)+2*deltaV;
           if levelShift 
               [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
           else
               [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
           end
           [occ,mu] = get_occ(norb,ee,q,tsmear,false);
           if acfd
               [ex1] = calc_exx_energy(ev,ee,occ,x);
           else
               [ex1] = calc_HF_energy(ev,ee,occ,x);
           end
           
           vks_tmp = vks;
           vks_tmp(j) = vks(j)-2*deltaV;
           if levelShift 
               [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
           else
               [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
           end
           [occ,mu] = get_occ(norb,ee,q,tsmear,false);
           if acfd
               [ex2] = calc_exx_energy(ev,ee,occ,x);
           else
               [ex2] = calc_HF_energy(ev,ee,occ,x);
           end
           
           vks_tmp = vks;
           vks_tmp(j) = vks(j)+deltaV;
           if levelShift 
               [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
           else
               [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
           end
           [occ,mu] = get_occ(norb,ee,q,tsmear,false);
           if acfd
               [ex3] = calc_exx_energy(ev,ee,occ,x);
           else
               [ex3] = calc_HF_energy(ev,ee,occ,x);
           end
           
           vks_tmp = vks;
           vks_tmp(j) = vks(j)-deltaV;
           if levelShift 
               [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
           else
               [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
           end
           [occ,mu] = get_occ(norb,ee,q,tsmear,false);
           if acfd
               [ex4] = calc_exx_energy(ev,ee,occ,x);
           else
               [ex4] = calc_HF_energy(ev,ee,occ,x);
           end
           
           dEdV(j) = (-ex1+ex2+8*ex3-8*ex4)/12/deltaV;
       end
   end
   
   % divid the spacing to make [r,r+h] -> r
   dEdV = dEdV / h;
   dEdV = dEdV';

end

