function [ dm_clu, dm_env, vemb ] = dm_partition( ...
    tsmear, x, vks_clu, vks_env, nspin, norb, box_len, ngrid, ...
    dm_tot, q_clu, q_env, comm_chempot )


    q_total  = q_clu + q_env;
    
    fprintf('\n\ndensity matrix partitioning...\n\n')
    fprintf('box-length: %f \nngrid: %d  \ndx: %f\n',box_len,ngrid,x(2)-x(1));
    fprintf('q_tot: %f  \nq_clu: %f  \nq_env: %f\n\n',q_total,q_clu,q_env);

    vemb = zeros( ngrid );
    
    % ----- BFGS minimize (-W) functional -----
    fprintf('solve for vemb (L-BFGS) ...\n\n');
    
    f_handler = @(vemb)(wrap_W_dm(vemb,nspin,x,comm_chempot,box_len,ngrid,norb,...
        tsmear,q_clu,q_env,vks_clu,vks_env,dm_tot));
    
    options = optimset('GradObj','on','Display','Iter','MaxIter',1e8);
    
    [vemb,final_W] = fminlbfgs(f_handler,reshape(vemb,1,ngrid^2),options);
    
    vemb = reshape(vemb,ngrid,ngrid);

    [W,grad,rho_clu,rho_env,dm_clu,dm_env]= W_dm(vemb,nspin,x,comm_chempot, ...
        box_len,ngrid,norb,tsmear,q_clu,q_env,vks_clu,vks_env,dm_tot);   
    



end

