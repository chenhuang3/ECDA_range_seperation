function [e_ion] = make_ionic_energy(natom, coord, atom_Z)


% ion-ion energy
e_ion = 0.0;
for j=1:natom
    for q=1:natom
        if j ~= q
            r_tmp = coord(q)-coord(j);
            e_ion = e_ion + atom_Z(j)*atom_Z(q)/sqrt(r_tmp*r_tmp+1);
        end
    end
end
e_ion = e_ion / 2.0;


end