%
% becke's atom in molecule partitioning method.
%
function [ atom_weight ] = becke_aim( natom, coord, x, do_plot )

xlen = length(x);
P = zeros(xlen,natom); % cell function for each atom

for ia=1:natom
    P(:,ia) = 1.0;
    for j=1:natom
        if j == ia
            continue
        end
        % compute the S_AB
        % loop over all points on the grid
        for q=1:xlen
            r = x(q);
            rA = coord(ia);
            rB = coord(j);
            mu = (norm(rA-r)-norm(rB-r))/norm(rA-rB);
            f1=mu/2*(3-mu*mu);
            S_AB(q,1) = 1/2*(1-f1);
            %f2=f1/2*(3-f1*f1);
            %f3=f2/2*(3-f2*f2);
            %S_AB(q,1) = 1/2*(1-f3);
        end
        P(:,ia)=P(:,ia).*S_AB;
    end
end


% compute atomm weight
if do_plot
    figure
    hold on
end
for ia=1:natom
    atom_weight(:,ia) = P(:,ia) ./ sum(P,2);
    if do_plot
        plot(x,atom_weight(:,ia));
    end
end

if do_plot
    title(' atom weight using Becke AIM ')
    fprintf('press any key to continue ....\n');
    pause;
end


end

