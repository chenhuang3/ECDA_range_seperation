function [xsol] = solve_vxc_lsqr(x,dEdV,...
    levelShift,vks,v_LS,ngrid,norb,box_len,q,tsmear)

fprintf('\nIn solve_vxc_lsqr(), use lsqr to solve for vxc...\n ');

maxit = 10000;
tol = 1e-10;
xsol = lsqr(@afun,dEdV,tol,maxit);

%plot(x,dEdV,x,afun(xsol,'final'),'ro');

fprintf('done solve_vxc_lsqr().\n\n');


%% nested function for computing Ax with the perturbation theroy %

    function y = afun(x,transp_flag)                   
        lambda = 0.001; % finite difference step size
        
        % a positve step 
        vks1 = vks + lambda*x;        
        if (levelShift)
            [ee_tmp,ev_tmp]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks1)+v_LS);
        else
            [ee_tmp,ev_tmp]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks1);
        end
        [occ_tmp,mu_tmp] = get_occ(norb,ee_tmp,q,tsmear,false);
        rho1 = sum(ev_tmp.^2*occ_tmp,2);
        
        % a negative step 
        vks1 = vks - lambda*x;
        if (levelShift)
            [ee_tmp,ev_tmp]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks1)+v_LS);
        else
            [ee_tmp,ev_tmp]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks1);
        end
        [occ_tmp,mu_tmp] = get_occ(norb,ee_tmp,q,tsmear,false);
        rho2 = sum(ev_tmp.^2*occ_tmp,2);
        
        % centeral finite difference.
        y = (rho1-rho2)/lambda/2.0;      
    end

end