%====================
% make Coulumb matrix
%====================



fprintf('\n\n >>> range_sep_coul()<<< \n\n')
fprintf(' soft_coul:   %f\n',soft_coul)
fprintf(' tail_cutoff: %f\n',tail_cutoff)


% x axis ==============
xmin = -50.0;
xmax = 50.0;
dx = 0.1;
x = xmin:dx:xmax;
nx = length(x);


%% vc in q-space ===========
vg = @(q)2*besselk(0,abs(q)*soft_coul);
% vg = zeros([nq,1]);
% %intg = @(x,q,tail_cutoff)cos(x*q).*1./sqrt(x.*x+1.0).*exp(-(x/tail_cutoff).^2);
% intg = @(x,q,tail_cutoff)cos(x*q).*1./sqrt(x.*x+1.0);
% 
% % Fourier transform
% fprintf('\nFourier transform vc(r)...\n')
% for i = 1:nq
%     intg_q = @(x)intg(x,q(i),tail_cutoff); % redefine the integrand for given q(i)
%     vg(i) = integral(intg_q,-Inf,Inf);
% end
% pp = pchip(q,vg); % pchip is more accurate than cubic spline!
% figure 
% plot(q,vg)
% title('VC in q-space')



%% inverse Fourier transform
vr = zeros([nx,1]);
fprintf('\ninverse Fourier transform vc(q) ...\n')
for i = 1:nx
    xx = x(i);
    integrand = @(q)cos(-q*xx).*2.*besselk(0,abs(q)*soft_coul);
    vr(i) =  integral(integrand,-Inf,Inf)/2/pi;
    %vr(i) = integral(@(q)cos(-q*xx).*ppval(pp,q),qmin,qmax)/2/pi;
end
figure
plot(x,vr,'x',x,vc0(x))
title('compare vc and that from inverse FT')


%% long range vc
vg_lr = @(q)2*besselk(0,abs(q)*soft_coul).*exp(-(q*rc).^2);
figure
plot(q,vg(q),q,vg_lr(q))
title('long-range potential in q-space')



%% convert LR to real space
fprintf('\ninverse Fourier transform of LR potential...\n')
vr_lr = zeros([nx,1]);
for i = 1:nx
    xx = x(i);
    vr_lr(i) = integral(@(q)cos(-q*xx).*vg_lr(q),-Inf,Inf)/2/pi;
end

figure
plot(x,vr,x,vr_lr)
title('long-range VC in real space')



%% SR Columb potential  
vg_sr = @(q)2*besselk(0,abs(q)*soft_coul).*(1-exp(-(q*rc).^2));
figure
plot(q,vg(q),q,vg_sr(q))
title('short-range VC in q-space')

vr_sr = zeros([nx,1]);
fprintf('\ninverse Fourier transform of SR potential...\n')
for i = 1:nx
    xx = x(i);
    vr_sr(i) = integral(@(q)cos(-q*xx).*vg_sr(q),-Inf,Inf)/2/pi;
end

figure
plot(x,vr,x,vr_sr)
title('short-range VC in real space')






