%
% compute d(rho)/d(N_cluster) and d(rho/d(N_env)) with vks_cluster and
% vks_env fixed.
%
function [dRho_dN] = compute_drho_dN(vks,ngrid,norb,box_len,tsmear,q)

[ee,ev] = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
[occ,~] = get_occ(norb,ee,q,tsmear,false);

sum0 = 0.0;
for ib=1:norb
    occ_t = occ(ib)/2;
    sum0 = sum0 + occ_t*(1-occ_t);
end


dRho_dN = zeros(ngrid,1);


for ib=1:norb
    occ_t = occ(ib)/2;
    dRho_dN = dRho_dN + occ_t*(1-occ_t)*ev(:,ib).^2;
end

dRho_dN = dRho_dN*2/(2*sum0);  % factor "2" for spin


end