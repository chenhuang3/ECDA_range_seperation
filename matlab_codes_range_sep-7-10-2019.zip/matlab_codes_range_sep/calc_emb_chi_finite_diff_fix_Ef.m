%
%
% computing  d(rho1)/d(vemb)
%            d(rho2)/d(vemb)
% and the sum of them
%
%
function [chi_cluS,chi_envS,chi_totS] = calc_emb_chi_finite_diff_fix_Ef(...
    tsmear,Ef_emb,norb,box_len,vks_clu,vks_env,...
    q_total,q_clu,q_env,x,vks,vemb)

fprintf('\nenter calc_emb_chi_finite_diff().\ncomputing d(rho1)/d(vemb) and d(rho2)/d(vemb) using finite difference.\n');
fprintf('\n******** fix Fermi level *********\n')
Ef_emb

ngrid = size(vks,1);
deltaV = 0.01;
h = x(2)-x(1);

fprintf('finite difference step: %f \n',deltaV);
fprintf(' q_total: %f\n',q_total);
fprintf(' q_clu:   %f\n',q_clu);
fprintf(' q_env:   %f\n',q_env);

%
% finite difference
% we perturb the potential at x_i and measure the density change
%
for i=1:ngrid
    
    
    %%%%%%%%%%%%%%%%%%% (+) %%%%%%%%%%%%%%%
    vemb_test = vemb;
    vemb_test(i) = vemb_test(i) + deltaV;
    vks_clu_tmp = vks_clu + vemb_test;
    vks_env_tmp = vks_env + vemb_test;
    
    [ee_clu,ev_clu] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_clu_tmp);
    [ee_env,ev_env] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_env_tmp);
    
    [occ_clu] = get_occ_for_Ef(norb, ee_clu, tsmear, Ef_emb);
    [occ_env] = get_occ_for_Ef(norb, ee_env, tsmear, Ef_emb);
    
    rho_clu1 = sum(ev_clu.^2*occ_clu,2);
    rho_env1 = sum(ev_env.^2*occ_env,2);
    
    %%%%%%%%%%%%%%%%% (-) %%%%%%%%%%%%%%%%
    vemb_test = vemb;
    vemb_test(i) = vemb_test(i) - deltaV; 
    vks_clu_tmp = vks_clu + vemb_test;
    vks_env_tmp = vks_env + vemb_test;
    
    [ee_clu,ev_clu] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_clu_tmp);
    [ee_env,ev_env] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_env_tmp);
    
    [occ_clu] = get_occ_for_Ef(norb, ee_clu, tsmear, Ef_emb);
    [occ_env] = get_occ_for_Ef(norb, ee_env, tsmear, Ef_emb);
    
    rho_clu2 = sum(ev_clu.^2*occ_clu,2);
    rho_env2 = sum(ev_env.^2*occ_env,2);
    
    %
    % How the boundary condition is consider in the code?
    % The solve_ks_eq (qm1d) code considers the x(-1) and x(ngrid+1)
    % as the two boundary points. See the descript on their website
    %
    % http://www.cond-mat.de/teaching/DFT/qm1d.f
    %
    % the comment below is from the website
    %
    % c --- discretized form of kinetic energy operator (incl. boundary cond.)
    % c     f''(x_i) \approx (f(x_{i-1})-2*f(x_i)+f(x_{i+1}))/dx^2
    % c     by dropping terms from outside the mesh, we have chosen boundary
    % c     conditions such that the phi vanishes outside the mesh
    %
    % In that sense, the change of v_KS at x(1) and x(ngrid)
    % should be multiplied by "h" instead of "h/2".
    % this also means that wavefunction is not zero at x(1) and x(ngrid)
    % but is zero at x(-1) and x(ngrid+1).
    %
    chi_clu(:,i) = (rho_clu1-rho_clu2)/(2*deltaV*h);
    chi_env(:,i) = (rho_env1-rho_env2)/(2*deltaV*h);
    
end % grid points


chi_tot = chi_clu + chi_env;


%
% symmetrize chi
%
for i=1:ngrid
    for j=1:ngrid
        chi_cluS(i,j) = (chi_clu(i,j)+chi_clu(j,i))/2.0;
        chi_envS(i,j) = (chi_env(i,j)+chi_env(j,i))/2.0;
        chi_totS(i,j) = (chi_tot(i,j)+chi_tot(j,i))/2.0;
    end
end



fprintf('done computing embedding response function [symmetrized] \n\n');

end