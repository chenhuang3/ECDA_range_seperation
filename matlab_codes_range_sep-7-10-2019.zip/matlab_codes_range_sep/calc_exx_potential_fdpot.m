function [vxpot, dEdV] = calc_exx_potential_fdpot(x,vks,q_cluster,q_total,...
    tsmear,norb,fd_chi,acfd,levelShift,v_LS,use_total_chi,mu)


fprintf('[exx_pot] computing EXX potential (fd_pot method) ...\n')
fprintf('level_shift: %d \nuse_total_chi: %d\n',levelShift,use_total_chi);

box_len = x(end);
ngrid = size(x,1);
h = x(2) - x(1);
match_IE = true;
nbuffer = 5;

%
% computer dEdV
%
analytical_method = true;

if analytical_method == false
    
    [ dEdV ] = calc_exx_dEdV(ngrid,norb,tsmear,q_cluster,x,vks,h,box_len,acfd,levelShift,v_LS);
    %[ pot ] = solve_vxc_lsqr(x,dEdV,levelShift,vks,v_LS,ngrid,norb,box_len,q,tsmear);
    dEdV_fd = dEdV;
    
else
    
    if (levelShift)
        % cluster
        [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
        [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
    else
        % total system
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
        [occ,mu] = get_occ(norb,ee,q_total,tsmear,false);
    end
    
    [dEXX_dPhi] = compute_dEXX_dPhi(x,ev,occ,ee);
    [dEXX_dee]  = compute_dEXX_dEigen(x,ev,occ,ee,tsmear);
    
    dEdV = zeros([ngrid,1]);
    
    for ib=1:ngrid-nbuffer
        gf = green(ib,ev,ee,nbuffer);
        dEdV = dEdV ...
            + (h*gf*dEXX_dPhi(:,ib)).*ev(:,ib) ... % dE/dphi * dphi/dV
            + dEXX_dee(ib)*ev(:,ib).^2;            % dE/d(ee) * d(ee)/dV
    end
    %     figure
    %     plot(x,dEdV,'kx-',x,dEdV_fd,'ro')
end



%fprintf('[exx_pot] computing vexx_shift ...\n');
if levelShift
    [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
else
    [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
end
[occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
rho = sum(ev.^2*occ,2);


d =0.01;
[vks1,vks1_rec] = inv_KS(ngrid,norb,tsmear,x,box_len,rho,vks,levelShift,v_LS);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute the vxc_shift
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('[exx_pot] computing vexx_shift ...\n');
if levelShift
    [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
else
    [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
end
[occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);

%
% compute docc_dN and dExx_dN
% we use the finite difference to compute it
% by changing N -> N \pm delta_Q (see paper for formula)
%
if match_IE
    delta_Q = min(1e-2,q_cluster/2.0);
    [occ1,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
    if acfd
        [exx1] = calc_exx_energy(ev,ee,occ1,x);
    else
        [exx1] = calc_HF_energy(ev,ee,occ1,x);
    end
    [occ2,mu] = get_occ(norb,ee,q_cluster-delta_Q,tsmear,false);
    if acfd
        [exx2] = calc_exx_energy(ev,ee,occ2,x);
    else
        [exx2] = calc_HF_energy(ev,ee,occ2,x);
    end
    docc_dN = (occ1-occ2)/delta_Q;
    dExx_dN = (exx1-exx2)/delta_Q;
    fprintf('[exx_pot] match_IE\n')
else
    delta_Q = 1e-2;
    [occ1,mu] = get_occ(norb,ee,q_cluster+delta_Q,tsmear,false);
    if acfd
        [exx1] = calc_exx_energy(ev,ee,occ1,x);
    else
        [exx1] = calc_HF_energy(ev,ee,occ1,x);
    end
    [occ2,mu] = get_occ(norb,ee,q_cluster-delta_Q,tsmear,false);
    if acfd
        [exx2] = calc_exx_energy(ev,ee,occ2,x);
    else
        [exx2] = calc_HF_energy(ev,ee,occ2,x);
    end
    docc_dN = (occ1-occ2)/delta_Q/2;
    dExx_dN = (exx1-exx2)/delta_Q/2;
    fprintf('[exx_pot] match I+A !!!!!!!!!!! WARNING !!!!!!!!!!\n')
end

% compute vxc_shift
vxcbar_cum = 0.0;
vxcshift   = 0.0;
for ib = 1:norb
    vxc_bar = h*sum(pot.*ev(:,ib).*ev(:,ib));
    vxcbar_cum = vxcbar_cum + vxc_bar*docc_dN(ib);
end
vxcshift = dExx_dN - vxcbar_cum;   % compute vxcshift
vxpot    = pot + vxcshift;         % remove the shift

fprintf('[exx_pot] done EXX potential. vexx_shift: %f \n',vxcshift);


end

