%
% construct weights based on Becke's atom-in-molecule method
%
function [atom_weight,clu_weight,env_weight,dAtomW_dR,dClusterW_dR] = ...
    make_weights(natom,ngrid,coord,x,do_plot,rho,buffer)

% make weights for clusters (becke AIM)
fprintf('making weights (becke_aim)\n')

[atom_weight] = becke_aim( natom, coord, x, do_plot);


% derivatives of atom and cluster weights w.r.t. atom coordinates
% the first index is grid points
% the second index is the atom index
% the last index is {R}
[dAtomW_dR] = der_atom_weight_R(ngrid,natom,x,coord);

dClusterW_dR = zeros(ngrid,natom,natom); % the first index is grid points
                                         % the second index is the cluster index
                                         % the last index is {R}


% get number of electrons on each atom via Becke-AIM
compute_atom_charge(natom,x,atom_weight,rho);

clu_weight = zeros(ngrid, natom);
env_weight = zeros(ngrid, natom);

% cluster weights for density partitioning.
for ia=1:natom  % loop over clusters 
    
    if buffer{ia}==999
        % the cluster is just the whole system
        clu_weight(:,ia) = sum(atom_weight,2);
    else
        % construct cluster's weight, which is
        % just the sum of buffer atoms' weights
        
        clu_weight(:,ia) = atom_weight(:,ia);
        dClusterW_dR(:,ia,:) = dAtomW_dR(:,ia,:);
        
        % add buffer atoms 
        for ibuffer = 1:length(buffer{ia})
            jatom = buffer{ia}(ibuffer);
            clu_weight(:,ia) = clu_weight(:,ia) + atom_weight(:,jatom);
            dClusterW_dR(:,ia,:) = dClusterW_dR(:,ia,:) + dAtomW_dR(:,jatom,:);
        end
    end
    env_weight(:,ia) = 1 - clu_weight(:,ia);
end



1+1;




