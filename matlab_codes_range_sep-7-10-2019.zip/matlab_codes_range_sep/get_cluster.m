%
% For given vks and v_emb, cluster's KS system is solved. 
% chemical potentials between cluster and env can be equilibrated. 
%

function [ee_clu,ev_clu,occ_clu,mu_clu] = get_cluster(tsmear,...
    vks_clu,vks_env,box_len,x,comm_chempot,q_total,q_clu,q_env,vks,vemb)

ngrid = length(vks);
norb = ngrid;

[ee_clu,ev_clu] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_clu+vemb);
[ee_env,ev_env] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_env+vemb);

h = x(2)-x(1);

% occupation numbers
if (comm_chempot)
    q_clu = 0.0;
    q_env = q_total;
    [occ_clu,occ_env] = get_occ_comm(norb,ee_clu,q_clu,ee_env,q_env,tsmear,false);
else
    [occ_clu,mu_clu] = get_occ(norb,ee_clu,q_clu,tsmear,false);
    [occ_env,mu_env] = get_occ(norb,ee_env,q_env,tsmear,false);
end

end