clear all
close all


% % start the matlabpool with maximum available workers
% % control how many workers by setting ntasks in your sbatch script
% pc = parcluster('local')
% parpool(pc)


input_file

ksdft

%epp


%%%%%%%%%%%%%%%%%%%%%%%
% compute the xc kernel 

dV_xc_dV_KS = zeros(ngrid,ngrid);
delta=0.01;
v_LS = zeros([ngrid,ngrid]);

for ipoint = 1:ngrid
    
    vks_tmp = vks;
    vks_tmp(ipoint) = vks(ipoint)+delta;
    
    fprintf('ipoint: %d / %d\n',ipoint,ngrid);
    [ee1,ev1] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    [occ1,mu_tmp] = get_occ(norb,ee1,q_total,sub_tsmear,false);
    
    use_acfd_exx = 1;
    [vexx1, dEdV_exx1] = ...
        calc_exx_potential(x,vks_tmp,q_total,q_total,sub_tsmear,norb, ...
        false,use_acfd_exx,false,v_LS,false);

end



[ chi ]  = calc_chi(ev, ee, occ, 0.0);


figure
[X,Y] = meshgrid(0:box_len/(ngrid-1):box_len);
contour(X,Y,chi);
for j=1:natom
    hold on
    plot(coord(j),coord(j),'x')
end


figure
[X,Y] = meshgrid(0:box_len/(ngrid-1):box_len);
mesh(X,Y,chi);
for j=1:natom
    hold on
    plot(coord(j),coord(j),'x')
end
grid off


for i=1:ngrid
    [vexch] = calc_exx_potential(x,vks,q_total,q_total,tsmear,norb,...
    false,use_acfd_exx,false,v_LS,false);
end