clear all
close all


% >>>>>>>>>>> common settings  <<<<<<<<<<
maxiter = 1;
total_var = true;
range_sep = false;
rc = 3.0;            % range for range-seperation vc
soft_coul = 1.0;     % soften the signularity of vc at r=0; (not affect global code!)


vac   = 10.0/27.2114; % in Hartree
reg_z = 1e-3;         % regularization parameter for solving z 
reg_vxc = 1e-3;       % regularization parameter for solving total vexx and vrpa
do_plot       = false;
do_patching   = true;
localizeOrbital = false;
do_exx = true;
do_rpa = false;
use_acfd_exx  = true;
one_step = false;



% ====== system setup ============
ion_soft = 1.0;                       % soft constant for v_ext potential
nspin  = 1;                           % number of spin
tsmear = 0.1/27.2114;                 % in hartree
natom   = 12;
atom_Z  = ones(natom,1)*1.2;          % 14 H atoms
atom_Z_real  = ones(natom,1)*1.0;     % 14 H atoms
q_total   = natom*1;                  % total electron number in system



% === define alternating H chain ===
eq_dist = 2.2;
bond = 2.2;   % equilirium distance (for LDA energy) for eq_dist=2.2
dist = (eq_dist*(natom-1) - bond*natom/2)/(natom/2-1);
coord = zeros(natom,1);
coord(1) = 15.0;
for i=1:natom-1
    if (mod(i,2)==1)
        coord(i+1)=coord(i) + bond;
    else
        coord(i+1)=coord(i) + dist;
    end
end





% %%%random displacement for all H atoms
% rand_disp = [     
%    -0.1623
%     0.4001
%    -0.1308
%    -0.3888
%     0.2803
%    -0.1103
%    -0.2583
%    -0.0961
%    -0.4035
%    -0.3680
%     0.4421
%     0.4561
%     0.0752
%    -0.4402
%    -0.2652
%    -0.1468
%     0.3212
%    -0.4846
%    -0.4570
%    -0.3310
% ];
% for i=2:natom
%     coord(i) = coord(i) + rand_disp(i);
% end



%>>>>>>>>  get box length <<<<<<<<<<<<<<<<<<<
box_len = coord(end)+10;            % box stars at zero, in bohr
ngrid   = floor(box_len*2)          % include the last point
norb    = ngrid;                    % number of orbitals to solve.


%>>>>>>>>>>> EXX and RPA parameters <<<<<<<<<
omega_max = 10;
nfreq     = 15;
nlambda   = 8;  % integration over lambda for RPA


%>>>>>>>>>>>>>> definition of xcep <<<<<<<<<<
comm_chempot = false;
xcep_comm_ef = false;

buffer = cell(natom,natom);
nbuf   = 2;
for j=1:natom
  buffer{j} = union(max(1,j-nbuf):1:j-1, j+1:1:min(j+nbuf,natom));
  buffer{j}
end



ksdft
xcep
%debug_XC_force

