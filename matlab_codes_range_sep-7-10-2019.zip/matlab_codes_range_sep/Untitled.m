x = [1.7
2
2.5]

a=[-17.440706
-17.446342
-17.433533
]

p=polyfit(x,a,2)

aa = p(1)
bb = p(2)
cc = p(3)

xx = -bb/2/aa
aa*xx^2 + bb*xx + cc
