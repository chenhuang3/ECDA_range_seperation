

% Initialize KS potential for cluster and env.
vks_clu = zeros(length(vext),1);
vks_env = zeros(length(vext),1);
for j=1:ngrid        
     for i=1:natom
         dist = coord(i) - x(j);
         pot = -atom_Z(i)/sqrt(dist*dist+1.0);     
         location = find(atom_list_clu==i);
         if  length(location)==1           
             % this atom belongs to cluster
             vks_clu(j) = vks_clu(j) + pot;
         else
             % this atom belong to env.
             vks_env(j) = vks_env(j) + pot;
         end
     end     
end
vext_clu = vks_clu ;
vext_env = vks_env;
vemb = zeros( size(vext_clu,1), 1 );

for iter=1:20
    
    % ----- BFGS minimize (-W) functional -----
    fprintf('solve for vemb (L-BFGS) ...\n\n');
    f_handler = @(vemb)(W_density(vemb,nspin,x,comm_chempot,box_len,ngrid,norb,...
            tsmear,q_clu,q_env,vks_clu,vks_env,ref_rho));    
    options = optimset('GradObj','on','Display','Iter','MaxIter',10);    
    [vemb,final_W] = fminlbfgs(f_handler,vemb,options);
    
    [W,grad,rho_clu,rho_env]=W_density(vemb,nspin,x,comm_chempot,box_len,ngrid,norb,...
        tsmear,q_clu,q_env,vks_clu,vks_env,ref_rho);
    
    vks_clu_old = vks_clu;
    vks_env_old = vks_env;
    
    % update vks_clu and vks_env
    fprintf('update vks of cluster and env.\n');        
    vks_clu =0.d0;
    vks_env =0.d0;
    % exchange
    [ex,vks_clu] = cal_ex(x, rho_clu);
    [ex,vks_env] = cal_ex(x, rho_env);
    % hartree 
    [ex,vtmp] = cal_hartree(x, rho_clu); vks_clu = vks_clu + vtmp;
    [ex,vtmp] = cal_hartree(x, rho_env); vks_env = vks_env + vtmp;
    % external 
    vks_clu = vks_clu + vext_clu;
    vks_env = vks_env + vext_env;
    
    % mixing 
    vks_clu = (vks_clu_old+vks_clu)/2.0;
    vks_env = (vks_env_old+vks_env)/2.0;    
    
end



