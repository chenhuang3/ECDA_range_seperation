function plot2file(fname,x,data,s_title)

ncol = size(data,2);
figure('Visible','off');

for g=1:ncol
    plot(x,data(:,g));
    hold on
end

title(s_title)
print('-depsc2','-r300',fname);
fprintf('(plot2file) plotted %s\n',fname);

end