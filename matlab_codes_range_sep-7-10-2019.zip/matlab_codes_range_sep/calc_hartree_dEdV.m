function [ dEdV ] = calc_hartree_dEdV(ngrid,norb,tsmear,q,x,vks,h,box_len,acfd,levelShift,v_LS)
%
% finie difference for computing dE_exx / dV_KS
%
deltaV = 0.001;

fprintf('\n\n\n !!!!!!!!!! dHartree_dEdV !!!!!!!!!!!() ...\n\n\n')

for j = 1:ngrid
    
    % fourth order
    vks_tmp = vks;
    vks_tmp(j) = vks(j)+2*deltaV;
    if levelShift
        [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
    else
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    end
    [occ,mu] = get_occ(norb,ee,q,tsmear,false);
    rho = sum(ev.^2*occ,2);
    [eh1,vhart] = cal_hartree (x,rho);
    
    vks_tmp = vks;
    vks_tmp(j) = vks(j)-2*deltaV;
    if levelShift
        [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
    else
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    end
    [occ,mu] = get_occ(norb,ee,q,tsmear,false);
    rho = sum(ev.^2*occ,2);
    [eh2,vhart] = cal_hartree (x,rho);
    
    vks_tmp = vks;
    vks_tmp(j) = vks(j)+deltaV;
    if levelShift
        [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
    else
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    end
    [occ,mu] = get_occ(norb,ee,q,tsmear,false);
    rho = sum(ev.^2*occ,2);
    [eh3,vhart] = cal_hartree (x,rho);
    
    vks_tmp = vks;
    vks_tmp(j) = vks(j)-deltaV;
    if levelShift
        [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks_tmp)+v_LS);
    else
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    end
    [occ,mu] = get_occ(norb,ee,q,tsmear,false);
    rho = sum(ev.^2*occ,2);
    [eh4,vhart] = cal_hartree (x,rho);
    
    dEdV(j) = (-eh1+eh2+8*eh3-8*eh4)/12/deltaV;
end

% divid the spacing to make [r,r+h] -> r
dEdV = dEdV / h;

end

