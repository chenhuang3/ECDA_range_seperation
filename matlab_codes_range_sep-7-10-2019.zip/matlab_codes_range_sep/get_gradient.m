function  [yp] = get_gradient(x,f,order)

pp=spline(x,f);
p_der=fnder(pp,1);
yp=ppval(p_der,x);

end