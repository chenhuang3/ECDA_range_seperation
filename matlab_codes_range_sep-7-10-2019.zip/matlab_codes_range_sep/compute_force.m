function [force] = compute_force(ngrid,natom,x,coord,...
    atom_weight,dAtomW_dR,dClusterW_dR,clu_weight,exx_eps_clu,atom_Z,deps_dN_clu,...
    hvec,zg,ion_soft,rho)

h = x(2)-x(1);


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Force due to ion-electron energy
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
force_eion = zeros(natom,1);
delta = 0.001;
% due to the atom weights 
for j=1:natom
    coord1 = coord;
    coord1(j) = coord1(j)+delta;
    [vext]  = make_external_pot(ion_soft,x,natom,atom_Z,coord1,ngrid);
    etmp1 = dot(rho,vext)*h;

    coord1 = coord;
    coord1(j) = coord1(j)-delta;
    [vext]  = make_external_pot(ion_soft,x,natom,atom_Z,coord1,ngrid);
    etmp2 = dot(rho,vext)*h;     
    force_eion(j) = (etmp1-etmp2)/delta/2;
end



%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Force due to ion-ion energy
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
force_ii = zeros(natom,1);
delta = 0.001;
for j=1:natom    
    coord1 = coord;    
    coord1(j) = coord1(j) + delta;
    [eion1] = make_ionic_energy(natom, coord1, atom_Z);
    
    coord1 = coord;
    coord1(j) = coord1(j) - delta;    
    [eion2] = make_ionic_energy(natom, coord1, atom_Z);    
    
    force_ii(j) = (eion1-eion2)/2/delta;
end

fprintf('\n\n==== ion-ion + ele-ion forces =====\n');
format long
disp(force_ii+force_eion)



%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Forces due to XC energy 
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% due to change of atom weights w.r.t {R}
force_xc1 = zeros(natom,1);
for ia=1:natom % loop over all atom {R}
    for j=1:natom % loop over clusters 
        force_xc1(ia) = force_xc1(ia) + dot(exx_eps_clu(:,j),dAtomW_dR(:,j,ia))*h;
    end
end


% due to the change of cluster's KS potential
forceA = zeros(natom,1);
forceC = zeros(natom,1);
ncluster = natom;

for ia=1:natom    % loop over all atoms to move {R}
    for j=1:ncluster   % loop over cluster        
        envW = 1 - clu_weight(:,j);        
        forceA(ia) = forceA(ia) + sum(hvec(:,j).*dClusterW_dR(:,j,ia))*h;                    
        forceC(ia) = forceC(ia) - zg(j,ia);            
    end
end


%=============================================
% due to change of cluster's electron number 
%=============================================
force_Nclu = zeros(natom,1);
for ia=1:natom 
    for j = 1:ncluster
        dNdR = dot(rho,dClusterW_dR(:,j,ia))*h;
        force_Nclu(ia) = force_Nclu(ia) + dot(deps_dN_clu(:,j),atom_weight(:,j))*h*dNdR;
    end
end


force_xc2 = forceA + forceC;

force = force_eion + force_ii + force_xc1 + force_xc2 + force_Nclu;


% ---------- output -----------
fprintf('force_xc1 [due to dweight/dR]:\n')
disp(force_xc1)
fprintf('force_xc2 [due to deps/dR]:\n')
disp(force_xc2)
fprintf('force_xc1+force_xc2: \n')
disp(force_xc1+force_xc2)
fprintf('force_Nclu: \n')
disp(force_Nclu)
fprintf('total force:\n')
disp(force)
format short 


end
