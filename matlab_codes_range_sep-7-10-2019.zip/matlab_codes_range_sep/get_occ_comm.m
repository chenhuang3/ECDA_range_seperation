%
% equlibrating teh chemical potential over cluster and env.
%

function [occ_clu,occ_env,mu] = get_occ_comm(norb,ee_clu,q_clu,ee_env,q_env,tsmear,print)

    occ_clu = zeros(norb,1);
    occ_env = zeros(norb,1);
    
    max_iter = 100000;
    
    % high and low bounds and the eigenvalues
    b_mu = min(ee_clu(1),ee_env(1))-100.0;
    u_mu = max(ee_clu(norb),ee_env(norb));
    
    ne = q_clu + q_env;
    db = 2.0;
        
    % bisecting to get the mu and occ 
    for i=1:max_iter
    
      mu = ( b_mu + u_mu )/2.0;
    
      % get total electron number in the subsystem
      tmp_Q = 0.0;
      for j = 1:norb
         expo = (ee_clu(j)-mu)/ tsmear;
         occ_clu(j) = db*1.0/( exp( expo ) +1.0);
         expo = (ee_env(j)-mu)/ tsmear;
         occ_env(j) = db*1.0/( exp( expo ) +1.0);
         tmp_Q = tmp_Q + occ_clu(j) + occ_env(j);
      end
      
      % bisecting
      if tmp_Q > ne 
         u_mu = mu;
      else 
         b_mu = mu;      
      end
      
      % converge?
      if abs(tmp_Q-ne)<1e-12 && abs(b_mu-u_mu)<1e-8
        break;
      end
    end
    %%%%%%%%%%%%% end of bisecting %%%%%%%%%%%%%%%%%%%
    
    
    if print
        fprintf('cluster occ: \n');
        for j=1:norb       
            fprintf('%3d  ei: %16.6f  occ: %12.6f\n',j,ee_clu(j),occ_clu(j));
        end
        fprintf('env occ: \n');
        for j=1:norb       
            fprintf('%3d  ei: %16.6f  occ: %12.6f\n',j,ee_env(j),occ_env(j));
        end
    end
    
    if i==max_iter 
       disp('error in get_occ');
       stop
    end
    
    
end
