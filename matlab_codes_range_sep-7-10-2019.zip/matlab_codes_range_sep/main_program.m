% >>>>>>>>>>>>>>> External parameters <<<<<<<<<<<<<<

% load input files 
  system_H8
%  system_H8_evenSpacing

% run KS-DFT to get initial inputs for epp
  ksdft 

% run energy perturbation patching 
  epp 


