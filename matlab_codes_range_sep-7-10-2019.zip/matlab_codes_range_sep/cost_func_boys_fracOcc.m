%
%  inwfr:   the orbitals to be unitary transformed (they are normalized to 1)
%  new_wfr: not normalized!
%
function [f,g] = cost_func_boys_fracOcc(norb,points,new_wfr,inwfr,h)

  %%%%%%%%%% get the orbital centers <r^2> %%%%%%%%
  
  for i=1:norb
     arr = new_wfr(:,i).^2;     
     
     % <x> is defined as <x>=<wf|x|wf>/<wf,wf>     
     x(i) = sum(arr.*points)*h / sum(arr); 
  end

  %
  % cost function 
  % 
  L = 0.0;
  for ii=1:norb 
     for jj=1:norb 
          L = L + ( x(ii)-x(jj) )^2;
     end
  end
  
  %
  % gradient dL/dU_ij 
  %
  dL_dUmatrix = zeros(norb);
  
  for a=1:norb            
      for b=1:norb
     
        arr = new_wfr(:,b).*inwfr(:,a);
        factor = sum(arr.*(points-x(b)))*h / sum(new_wfr(:,b).^2);        
                
        for j=1:norb 
            dtmp = x(b) - x(j);
            dL_dUmatrix(a,b) = dL_dUmatrix(ii,jj) + 8.0*dtmp*factor;
        end       
      end
     
  end
  
  f = L;
  g = dL_dUmatrix;
  
  
end