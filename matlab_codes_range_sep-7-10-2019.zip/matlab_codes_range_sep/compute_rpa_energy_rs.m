%  Compute RPA energy
%
%  output: rpa is the RPA energy
%          eps_rps is the RPA energy density, E_{RPA} = \int eps_rpa(r) dr
%
%  part=1:  long range part
%  part=2:  short range part
%
function [rpa, eps] = compute_rpa_energy_rs(part,Usr,Ulr,omega_max,nfreq,x,ev,ee,...
    occ,print,mu,tsmear,nlambda,rc)


if nargin~=14
    fprintf('compute_rpa_energy_rs => number of arugments is not 12, stop bug!')
    stop
end


if print
    fprintf('\n >>> Enter compute_rpa_energy_rs() <<< \n');
    fprintf('rc:    %f\n',rc);
    fprintf('omega_max: %8.2f  nfreq: %d\n',omega_max,nfreq);
    if strcmp(part,'LR_KOHN')
        fprintf('long range (ACFDT from short-range as in Kohn paper) correlation.\n');
    elseif strcmp(part,'LR_ISO')
        fprintf('long range (just ACFDT on isolated Ulr system)\n')
    elseif strcmp(part,'SR_ISO')
        fprintf('short range corr based on isolated Usr system.\n');
    elseif strcmp(part,'SR_KOHN')
        fprintf('short range (ACFDT from long-range) corr.\n');
    else
        fprintf('undefined part in compute_rpa_energy_rs(), stop, bug!\n\n')
        stop
    end
end


ngrid = size(ev,1);
dx = x(2)-x(1);
soft_cutoff = 1.0;


%====================
% make Coulumb matrix
%====================
coul = zeros(ngrid);
for q=1:ngrid
    for q2=1:ngrid
        dist = x(q)-x(q2);
        coul(q,q2) = 1.0/sqrt(dist*dist + soft_cutoff);
    end
end


%=======================================
% make Gauss-Legendre points and weights
%=======================================
%[freq,int_w]=lgwt(nfreq,0,omega_max);
[freq,int_wfreq]=lgwt_RPA(nfreq,omega_max);

[lambda,int_wlambda]=lgwt(nlambda,0,1);



%======================================================
% short range (isolated system based on Usr)
%======================================================
if strcmp(part,'SR_ISO')
    rpa = 0.0;
    eps = zeros(ngrid,1);  

    % integration over freq
    for q=1:nfreq
        chi = calc_chi(mu, tsmear, ev, ee, occ, freq(q) );
        CHI = chi*dx;    % expand chi(x,x')  in basis functions (grid points)
        % short-range RPA energy
        mat = Usr*dx*CHI;
        rpa_tmp = trace(logm(eye(ngrid)-mat)+mat)/2/pi;
        rpa = rpa + rpa_tmp*int_wfreq(q);
        
        % short-range RPA energy density
        mat1 = logm(eye(ngrid)-mat) + mat;
        eps_tmp = diag(mat1)/2/pi;
        eps_tmp = eps_tmp/dx;      % convert to energy density
        eps_tmp = real(eps_tmp);
        eps = eps + eps_tmp*int_wfreq(q);
    end
end



%=============================================
% short-range (ACFDT from long-range system)
%=============================================
if strcmp(part,'SR_KOHN')    
    rpa = 0.0;
    eps = zeros(ngrid,1);
    for q=1:nfreq
        chi = calc_chi(mu, tsmear, ev, ee, occ, freq(q));
        CHI = chi*dx;    % expand chi(x,x')  in basis functions (grid points)
        rpa1 = 0.0;
        eps1 = zeros([ngrid,1]);
        % integral over lambda
        for ll=1:nlambda
            Mtmp = eye(ngrid) - CHI*(Ulr*dx + lambda(ll)*Usr*dx);
            mat = (Usr*dx)*inv(Mtmp)*CHI - Usr*dx*CHI;
            
            % correlation energy
            rpa_tmp = -trace(mat)/2/pi;
            rpa1 = rpa1 + rpa_tmp*int_wlambda(ll);
            
            % correlation energy density
            eps_tmp = -diag(mat)/2/pi/dx;
            eps1 = eps1 + eps_tmp*int_wlambda(ll);
        end
        rpa = rpa + rpa1*int_wfreq(q);
        eps = eps + eps1*int_wfreq(q);
    end
end



%====================================
% long range (isolated based on Ulr)
%====================================
if strcmp(part,'LR_ISO')
    rpa = 0.0;
    eps = zeros(ngrid,1); 
    for q=1:nfreq
        chi = calc_chi(mu, tsmear, ev, ee, occ, freq(q) );
        CHI = chi*dx;    % expand chi(x,x')  in basis functions (grid points)
        mat = Ulr*dx*CHI;
        rpa_tmp = trace(logm(eye(ngrid)-mat)+mat)/2/pi;
        rpa = rpa + rpa_tmp*int_wfreq(q);
        
        % short-range RPA energy density
        mat1 = logm(eye(ngrid)-mat) + mat;
        eps_tmp = diag(mat1)/2/pi;
        eps_tmp = eps_tmp/dx;      % convert to energy density
        eps_tmp = real(eps_tmp);
        eps = eps + eps_tmp*int_wfreq(q);
    end
end



%======================================================
% long range (Kohn's version) correlation energy
% ACFDT from short-range system 
%======================================================
if strcmp(part,'LR_KOHN')
    % long range ===========
    rpa = 0.0;
    eps = zeros(ngrid,1);
    for q=1:nfreq
        %fprintf('freq: %d\n',q)
        chi = calc_chi(mu, tsmear, ev, ee, occ, freq(q));
        CHI = chi*dx;    % expand chi(x,x')  in basis functions (grid points)
        rpa1 = 0.0;
        eps1 = zeros([ngrid,1]);
        % integral over lambda
        for ll=1:nlambda
            Mtmp = eye(ngrid) - CHI*(Usr*dx + lambda(ll)*Ulr*dx);
            mat = (Ulr*dx)*inv(Mtmp)*CHI - Ulr*dx*CHI;
            
            % energy
            rpa_tmp = -trace(mat)/2/pi;
            rpa1 = rpa1 + rpa_tmp*int_wlambda(ll);
            
            % energy density
            eps_tmp = -diag(mat)/2/pi/dx;
            eps1 = eps1 + eps_tmp*int_wlambda(ll);
        end
        rpa = rpa + rpa1*int_wfreq(q);
        eps = eps + eps1*int_wfreq(q);
    end
end




%plot(freq,rpa_w,'bo-');
if print
    fprintf('done RPA energy! RPA energy: %f\n\n',rpa);
end

end
