if (range_sep)
    [Usr, Ulr] = make_Ulr_Usr(ngrid,rc,soft_coul,x);
end



[rpa_energy,rpa_eps] = compute_rpa_energy(omega_max,nfreq,x,...
    ev,ee,occ,true,mu_system,tsmear);

% short range RPA energy (ACFDT from long-range correlation)
[rpa_energy_sr,rpa_eps_sr] = compute_rpa_energy_rs('SR_KOHN',Usr,Ulr,omega_max,nfreq,x,...
    ev,ee,occ,true,mu_system,tsmear,nlambda,rc);

% long range (isolated system)
[rpa_energy_lr2,rpa_eps_lr2] = compute_rpa_energy_rs('LR_ISO',Usr,Ulr,omega_max,nfreq,x,...
    ev,ee,occ,true,mu_system,tsmear,nlambda,rc);

% short range (isolated system)
[rpa_energy_sr2,rpa_eps_sr2] = compute_rpa_energy_rs('SR_ISO',Usr,Ulr,omega_max,nfreq,x,...
    ev,ee,occ,true,mu_system,tsmear,nlambda,rc);

% long range RPA energy, ACFDT from short-range correlation
[rpa_energy_lr,rpa_eps_lr] = compute_rpa_energy_rs('LR_KOHN',Usr,Ulr,omega_max,nfreq,x,...
    ev,ee,occ,true,mu_system,tsmear,nlambda,rc);

fprintf("sr_ISO + lr RPA: %12.8f   with  rc= %f\n",rpa_energy_sr2 + rpa_energy_lr,rc)
fprintf("sr + lr_ISO RPA: %12.8f   with  rc= %f\n",rpa_energy_sr + rpa_energy_lr2,rc)
