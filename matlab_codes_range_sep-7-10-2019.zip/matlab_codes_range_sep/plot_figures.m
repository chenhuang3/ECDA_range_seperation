function [ output_args ] = plot_figures( do_rpa, do_exx, x, ...
    vexx0, vrpa0, dEdV0_exx, dEdV0_rpa, ...  % reference data 
    vexx_patched_noshift, vrpa_patched_noshift, vxc_patched_noshift, ... % patched no EPP
    vexx_patched, vrpa_patched, vxc_patched, ... % patched w/ epp
    dEdV_exx_patched, dEdV_rpa_patched)

if (do_rpa && do_exx)
    f=figure('Visible','off');
    plot(x,vxc_patched,'r-',x,vexx0+vrpa0,'k-',x,vxc_patched_noshift,'b--');
    legend('epp','benchmark','no epp');
    print('-depsc2','-r300','vxc_compare.eps');
    f=figure('Visible','off');
    %
    f=figure('Visible','off');
    plot(x,dEdV_exx_patched+dEdV_rpa_patched,'ro-',x,dEdV0_rpa+dEdV0_exx,'k-');
    legend('patched','benchmark');
    print('-depsc2','-r300','dEdV_total_compare.eps');
end

if (do_exx)
    f=figure('Visible','off');
    plot(x,vexx_patched,'r-',x,vexx0,'k-',x,vexx_patched_noshift,'b--');
    legend('epp','benchmark','no epp');
    print('-depsc2','-r300','vexx_compare.eps');
    %
    f=figure('Visible','off');
    plot(x,dEdV_exx_patched,'ro-',x,dEdV0_exx,'k-');
    legend('patched','benchmark');
    print('-depsc2','-r300','dEdV_exx_compare.eps');
end

if (do_rpa)
    f=figure('Visible','off');
    plot(x,vrpa_patched,'r-',x,vrpa0,'k-',x,vrpa_patched_noshift,'b--');
    legend('epp','benchmark','no epp');
    print('-depsc2','-r300','vrpa_compare.eps');
    %
    f=figure('Visible','off');
    plot(x,dEdV_rpa_patched,'ro-',x,dEdV0_rpa,'k-');
    legend('patched','benchmark');
    print('-depsc2','-r300','dEdV_rpa_compare.eps');
end
end


