%
% compute the RPA correlation hole
%
% input: x0_index -> the index of the x point to consider its hole
%        ev: orbitals
%        ee: orbital energies
%        occ: occupation numbers
%
function [hole] = rpa_corr_hole(x,x0_index,rho,tsmear,mu,ev,ee,occ,nfreq,omega_max)

ngrid = size(ev,1);
dx = x(2)-x(1);

% make Coulumb matrix
coul = zeros(ngrid);
for q=1:ngrid
    for q2=1:ngrid
        dist = x(q)-x(q2);
        coul(q,q2) = 1.0/sqrt(dist*dist + 1.0);
    end
end

% make Gauss-Legendre points and weights
%[freq,int_w]=lgwt(nfreq,0,omega_max);
[freq,int_w]=lgwt_RPA(nfreq,omega_max);

fprintf('\ncomputing RPA correlation hole ...\n');
fprintf('omega_max: %8.2f  nfreq: %d\n',omega_max,nfreq);


nlambda = 10;
[lam,int_lambda]=lgwt(nlambda,0,1);

hole = zeros([ngrid,1]);

% integratoin over lambda
for l=1:nlambda
    
    % integration over frequency
    for q=1:nfreq
        
        chi = calc_chi(mu, tsmear, ev, ee, occ, freq(q));
        
        % compute chi(lambda)
        chi_lambda = inv(eye(ngrid) - lam(l)*chi*coul)*chi;
        
        for ip=1:ngrid
            hole(ip) = hole(ip) - 1/2/pi*int_lambda(l)*int_w(q)*...
                (chi_lambda(x0_index,ip)-chi(x0_index,ip))/rho(x0_index)*2;
        end
    end
end

%%%%%%%% RPA energy density at x0 point %%%%%%%
eps = 0.0;
for ip=1:ngrid
    eps = eps + 0.5*rho(x0_index)*coul(x0_index,ip)*hole(ip)*dx;
end
fprintf('Exchange energy density at x0 is %f\n\n',eps);

%%%%%%%%%%%% debug the code %%%%%%%%%%%%%%
[rpac,eps0] = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,true,mu,tsmear);
fprintf('exchange energy density from calc_exx_energy(): %f\n',eps0(x0_index));
fprintf('Exchange energy density at x0 is %f. Do they match?\n',eps);



end
