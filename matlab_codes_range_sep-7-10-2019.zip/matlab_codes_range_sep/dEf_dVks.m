%
% compute d(fermi_level) / d( vks(r)) 
% for a system with fixed electron number
%
function  [dfermi_dvks] = dEf_dVks(x,occ,ev,nband)

h=x(2)-x(1);

ss = 0.0;
for ib = 1:nband
    occ_tmp = occ(ib)/2.0;
    ss = ss + occ_tmp*(1-occ_tmp);
end

dfermi_dvks = zeros(nband,1);
for ib=1:nband
    occ_tmp = occ(ib)/2.0;
    dfermi_dvks = dfermi_dvks + occ_tmp*(1-occ_tmp)/ss*ev(:,ib).^2;
end



end