%
% get the occupation number for the given eigenvalues (ee)
% norb:  number of orbitals
% ee:   ee(1:norb) eigenvalues
% tsmear: smearing temperature (in hartree)
% mu: chemical potential
% ne: electron number
%
function [occ] = get_occ_for_Ef(norb, ee, tsmear, fermi)

occ = zeros(norb,1);
db = 2.0;

for j = 1:norb
    expo = (ee(j)-fermi)/ tsmear;
    occ(j) = db*1.0/( exp( expo ) +1.0);
end

end
