%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Anderson mixing of KS potential
%
%  update Kohn-Sham potential (Anderson mixing)
%  ref: http://www.physics.metu.edu.tr/~hande/teaching/741-lectures/lecture-10.pdf
%       https://wiki.fysik.dtu.dk/gpaw/documentation/densitymix/densitymix.html
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


resid2 = resid1;          % residual
resid1 = vks - vks_old;   % residual
if iter>=3
    if iter==3
        fid = fopen('iteration_epp.txt','a');
        fprintf(fid,'*** Anderson mixing ***\n');
        fclose(fid);
    end
    fprintf('\n>>>> anderson mixing <<<<   \n');
    % Anderson mixing
    anderson_mix = ...
        -dot(resid2,resid1-resid2)/dot(resid1-resid2,resid1-resid2)
    m_beta = 0.3;
    vks = (vks_old +m_beta*resid1)*anderson_mix ...
        + (vks_old2+m_beta*resid2)*(1-anderson_mix);
else
    fprintf('\n>>>> simple mixing with coeff=0.1 <<<<  \n');
    alpha = 0.9;
    vks = vks_old*alpha + (1-alpha)*vks;
end
