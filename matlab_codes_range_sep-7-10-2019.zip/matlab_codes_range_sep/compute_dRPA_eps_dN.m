%
% Compute dE_{RPA}/dN using finite difference method 
%
% In the future, we should be able to derive this analytically since we already have 
% dE_{RPA}/d(eigen), which is implemented in compute_dRPA_dEigen.m file
%
% Created on (1/6/2019) by Chen Huang
% 
function [deps_dN] = compute_dRPA_eps_dN(range_sep,part,Usr,Ulr,nlambda,rc,...
                                         x,q,omega_max,nfreq,tsmear,box_len,vks)

ngrid = length(x);
norb = ngrid;

delta_q = 1e-2;

[ee,ev] = solve_ks_eq(ngrid,norb,0.0,box_len,vks);


fprintf('\n\n>>> enter compute_dRPA_eps_dN() <<< \n')
fprintf('range_sep: %d\n',range_sep)
fprintf('part: %s\n\n',part)


% N + delta_q
[occ,mu] = get_occ(norb,ee,q+delta_q,tsmear,false);
if range_sep==false
   [etmp,eps1] = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,false,mu,tsmear);
else
   [etmp,eps1] = compute_rpa_energy_rs(part,Usr,Ulr,omega_max,nfreq,x,ev,ee, ...
                                       occ,false,mu,tsmear,nlambda,rc);
end


% N - delta_q
[occ,mu] = get_occ(norb,ee,q-delta_q,tsmear,false);
if range_sep==false
   [etmp,eps2] = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,false,mu,tsmear);
else
   [etmp,eps2] = compute_rpa_energy_rs(part,Usr,Ulr,omega_max,nfreq,x,ev,ee, ...
                                       occ,false,mu,tsmear,nlambda,rc);
end


deps_dN = (eps1-eps2)/2/delta_q;

end
