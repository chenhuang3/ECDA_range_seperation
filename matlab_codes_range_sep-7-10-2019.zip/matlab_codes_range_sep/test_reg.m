close all
clear all

% >>>>>>>>>>> common settings  <<<<<<<<<<

use_total_chi = true;
do_plot       = false;
do_patching   = true;
shift_epp     = false;
localizeOrbital = 1;
do_exx = true;
do_rpa = true;
use_acfd_exx = true;
do_cpp       = false;

% >>>>>>>>>> system setup <<<<<<<<<<<<<

ion_soft = 1.0;                      % soft constant for v_ext potential
nspin = 1;                           % number of spin
tsmear = 0.0001/27.2114;             % in hartree
ngrid = 120;                         % include the last point
box_len = 65;                        % box stars at zero, in bohr
natom   = 18;
%atom_Z = ones(natom,1)*3.6;          % 14 H atoms
atom_Z = [1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2  ...
          3.6 3.6 3.6 3.6 3.6 3.6 3.6 3.6 ];
%dx= 2.5;
%a1 = 8;
% 10 H atoms and 4 Li atoms
coord = [10.0 11.5 13.0 14.5 16.0 17.5 19.0 20.5 22.0 23.5  ...
         26.0 30.0 34.0 38.0 42.0 46.0 50.0 54.0 ];
%coord = [a1:dx:a1+dx*(natom-1)];     % cooridates
norb = ngrid;                         % number of orbitals to solve.
q_total = 34;                          % total electron number in system

%>>>>>>>>>>> EXX and RPA parameters <<<<<<<<<
omega_max = 10;
nfreq  = 15;

%>>>>>>>>>>>>>> definition of xcpp <<<<<<<<<<<<<<<
comm_chempot = true;
sub_tsmear = 0.1/27.2114;
buffer    = cell(natom,100);
buffer{1} =  [2  3  4];
buffer{2} =  [1  3  4  5];
buffer{3} =  [1  2  4  5  6];
buffer{4} =  [1  2  3  5  6  7];
buffer{5} =  [2  3  4  6  7  8];
buffer{6} =  [3  4  5  7  8  9];
buffer{7} =  [4  5  6  8  9  10];
buffer{8} =  [5  6  7  9  10 11];
buffer{9} =  [6  7  8  10 11 12];
buffer{10} = [7  8  9  11 12 13];
buffer{11} = [8  9  10 12 13 14];
buffer{12} = [9  10 11 13 14 15];
buffer{13} = [10 11 12 14 15 16];
buffer{14} = [11 12 13 15 16 17];
buffer{15} = [12 13 14 16 17 18];
buffer{16} = [13 14 15 17 18];
buffer{17} = [14 15 16 18];
buffer{18} = [15 16 17];

ksdft

epp