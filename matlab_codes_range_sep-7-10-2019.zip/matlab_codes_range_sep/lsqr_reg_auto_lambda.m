%
%  solve Ax=b with lsqr() method
%  regularizing the gradient of solution x.
%  lamdba: penalty coefficient
%  A: square matrix
%

function [x]=lsqr_reg_auto_lambda(A,b,tol,maxiter,cluster_id,reg_operator)


clear lam match gnorm
fprintf('enter lsqr_reg_auto_lambda().\n');

n = size(A,1);
lambda = 1e-5;
lam_min = lambda;
show_plots = false;

if cluster_id > 100
    xctype='exx';
    cluster_id = cluster_id-200;
else
    xctype='rpa';
end



%%%%%%%% NOTICE: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% enforcing regularizing |x| %%%%%%%%%%
reg_operator = 2;
fprintf('NOTICE: Enforcing use Tikhonov regularization, regularizing grad(x) does not work! \n');

switch reg_operator
    case 1
        kappa_thresh=2;
        fprintf('reg_operato=1 => regularize the gradient\n');
    case 2
        kappa_thresh=0.2;
        fprintf('reg_operato=2 => regularize the norm\n');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%
% test a series of lambda
%%%%%%%%%%%%%%%%%%%%%%%%%%%

for ipen = 1:10000
    if lambda>10
        lam_max = lambda;
        break
    end
    lambda = lambda*1.5;
    %fprintf('lambda: %e\n',lambda);
    switch reg_operator
        case 1
            grad = zeros([n,n]);
            for i=1:n
                if i==1
                    % x1-x3)
                    grad(1,1)=-30;
                    grad(1,2)=16;
                    grad(1,3:n)=-1;
                elseif i==n
                    grad(n,n-2)=-1;
                    grad(n,n-1)=16;
                    grad(n,n)=-30;
                else
                    grad(i,i-2)=-1;                    
                    grad(i,i-1)=16;
                    grad(i,i)  =-30;
                    grad(i,i+1) = 1.0;
                    grad(i,i) = -2.0;
                end
            end
        case 2
            % just the identity matrix to measure the norm of the x
            grad = eye([n,n]);
        otherwise
            disp('undefined reg_operator')
            stop
    end
    
    AA = [A;lambda*grad];
    bb = [b;zeros(n,1)];
    opts1=optimset('Display','off');
    [x,flag] = lsqr(AA,bb,tol,maxiter);
    
    lam(ipen,1) = lambda;              % lambda list
    gnorm(ipen,1) = norm(grad*x);  % |gradient of x|
    match(ipen,1) = norm(A*x-b);
    
end


%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
% plot
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


log_gnorm = log(gnorm);

if show_plots
    figure
    plot(log(match),log_gnorm,'o-')
    xlabel('|Ax-b|')
    ylabel('|grad(x)|')
    
elseif cluster_id ~= -1
    % plot to file
    f=figure('Visible','off');
    plot(log(match),log_gnorm,'o-')
    xlabel('|Ax-b|')
    ylabel('|grad(x)|')
    file_name1 = sprintf('L_curve_%d_%s.eps',cluster_id,xctype);
    print('-depsc2','-r300',file_name1);
end


%aa = [log(match) lam];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% determine optimal lambda
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%log_gnorm = smooth(log(match),log_gnorm,0.1,'rloess');

%
% Do the spline of the original data!
% Do not do it on the interpolated match and gnorm!!!
% because, the interpolated data points will have error,
% and you do not want to perform fnder() on them
%
% The correct proceudre is to do the spline() and fnder() on the original
% data, and then interpolate the obtained derivaties.
%

pp = spline(log(match),log_gnorm);
[ kappa ] = get_curvature(pp,log(match));
lam_list = [log(lam_min):0.1:log(lam_max)];
match_list = pchip(log(lam),log(match),lam_list);  % pchip avoids overshooting
kappa_list = pchip(log(match),kappa,match_list);   % pchip avoids overshooting


% plotting ............

if (show_plots)
    figure
    semilogx(lam,kappa,'o-r')
    xlabel('log({\lambda})')
    ylabel('curvature')
elseif cluster_id ~= -1
    % plot to file
    f=figure('Visible','off');
    semilogx(lam,kappa,'o-r')
    xlabel('log(lambda)')
    ylabel('curvature')
    file_name1 = sprintf('L_curve_lambda_curvature_%d_%s.eps',cluster_id,xctype);
    print('-depsc2','-r300',file_name1);
end


%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
% Search for the first positive peak
%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

assigned = -1;

for j=length(lam_list)-1:-1:2
    if kappa_list(j)>kappa_thresh
        if kappa_list(j+1)<kappa_list(j) && kappa_list(j-1)<kappa_list(j)
            opt_lambda = exp(lam_list(j));
            opt_match = exp(match_list(j));
            max_kappa = kappa_list(j);
            assigned = 1;
            fprintf('\nopt_lambda: %f\n', opt_lambda);
            break
        end
    end
end


if (assigned==-1)
    j = 1;
    opt_lambda = exp(lam_list(j))
    opt_match = exp(match_list(j));
    max_kappa = kappa_list(j);
    fprintf('!!!!!!!!!!! CANNOT FIND lambda, use the lam_min !!!!!!!!!!!\n')
end
%
%
%
%     j = 80;
%     opt_lambda = exp(lam_list(j))
%     opt_match = exp(match_list(j));
%     max_kappa = kappa_list(j);
%     fprintf('\n\n\n\n !!!!!!!!!!! CANNOT FIND lambda, use the lam_min !!!!!!!!!!!\n\n\n\n')


if show_plots
    figure
    semilogx(exp(lam_list),kappa_list,'-b',opt_lambda,max_kappa,'rx','markersize',12)
    xlabel('{\lambda}')
    ylabel('curvature')
    
elseif cluster_id ~= -1
    
    f=figure('Visible','off');
    semilogx(exp(lam_list),kappa_list,'-b',opt_lambda,max_kappa,'rx','markersize',12)
    xlabel('{\lambda}')
    ylabel('curvature')
    file_name1 = sprintf('L_curve_lambda_curv_mark_%d_%s.eps',cluster_id,xctype);
    print('-depsc2','-r300',file_name1);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solve Ax=b with the optimal lambda
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('resolve Ax=b with optimal lambda: %e\n',opt_lambda);
AA = [A;opt_lambda*grad];
bb = [b;zeros(n,1)];
x = lsqr(AA,bb,tol,maxiter);
opt_gnorm = norm(grad*x);

% plot opt_lambda on figure

if show_plots
    figure
    loglog(match,gnorm,'-o','markersize',6)
    hold on
    loglog(opt_match,opt_gnorm,'r+','markersize',14,'LineWidth',1.5)
    xlabel('|Ax-b|')
    ylabel('|grad(x)|')
    
elseif cluster_id ~= -1
    
    f=figure('Visible','off');
    loglog(match,gnorm,'-o','markersize',6)
    hold on
    loglog(opt_match,opt_gnorm,'r+','markersize',14,'LineWidth',1.5)
    xlabel('|Ax-b|')
    ylabel('|grad(x)|')
    file_name1 = sprintf('L_curve_mark_%d_%s.eps',cluster_id,xctype);
    print('-depsc2','-r300',file_name1);
end

end




