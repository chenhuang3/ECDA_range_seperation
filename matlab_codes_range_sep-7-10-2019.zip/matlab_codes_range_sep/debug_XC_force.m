% ============================================================================
%  exchange correlation potential patching code 
% ============================================================================


fprintf('\n\n\n  >>> performing xcpp version(March 6 2017) <<< \n\n')

%%
% check parameters
%
maxiter = 100000;
if (tsmear ~= sub_tsmear)
    fprintf('tsmear ~= sub_tsmear  erorr ! stop \n')
    stop
end
if (fix_fermi~=0)
    fprintf('set fix_fermi to 0, better results are obtained with fixed cluster electron number\n');
    stop
end

[atom_weight,clu_weight,env_weight,dAtomW_dR,dClusterW_dR] = ...
    make_weights(natom,ngrid,coord,x,do_plot,rho,buffer);

save -ascii x_coordiate.txt x


%% initialization for XCPP

dEdV_exx_patched = zeros(ngrid,1);
dEdV_rpa_patched = zeros(ngrid,1);
q_clu_list = zeros(ngrid,1);
q_env_list = zeros(ngrid,1);
exx_eps = zeros(ngrid,1);
rpa_eps = zeros(ngrid,1);
dExc_dVks = zeros([ngrid,1]);
exx_eps0 = zeros(ngrid,1);
rpa_eps0 = zeros(ngrid,1);
ex0 = 0;  % benchmark of exx energy of total system
rpa0 = 0; % benchmark of rpa energy of total system
v_LS = zeros([ngrid,ngrid]);

exx_eps_clu = zeros(ngrid,natom);
rpa_eps_clu = zeros(ngrid,natom);

y_exx = zeros(ngrid,natom);
y_rpa = zeros(ngrid,natom);

h_exx = zeros(ngrid,natom);
h_rpa = zeros(ngrid,natom);


vks_old = vks;
vks_old2 = vks;
vks_old3 = vks;

ngrid = size(x,1);
h = x(2)-x(1);                      % grid spacing
tol_ksdft = 1e-5;                   % tolerance for stopping KSDFT
old_ke = 0.0;                       % for convergence test
ke = 0.0;                           % for convergence test
ecorr = 0.0;                        % correlation energy
iter = 0;                           % iter number
resid1 = zeros([length(vext),1]);   % for Anderson mixing
vxc_cluster = zeros(ngrid,natom);      % store vxc of each cluster
etotal = -1;


fid = fopen('iteration_epp.txt','w');
program_info(fid);
fprintf(fid,'---- parameters ---- \n');
fprintf(fid,'ngrid          : %4d\n',ngrid);
fprintf(fid,'natom          : %4d\n',natom);
fprintf(fid,'q_total        : %8.2f\n',q_total);
fprintf(fid,'box_len        : %8.4f\n',box_len);
fprintf(fid,'localizeOrb    : %2d\n', localizeOrbital);
fprintf(fid,'tsmear         : %8.4f (eV)\n',tsmear*27.2114);
fprintf(fid,'use_acfd_exx   : %2d\n',use_acfd_exx);
fprintf(fid,'omega_max      : %6.2f\n',omega_max);
fprintf(fid,'nfreq          : %3d\n',nfreq);
fprintf(fid,'do_exx         : %2d\n',do_exx);
fprintf(fid,'do_rpa         : %2d\n',do_rpa);
fprintf(fid,'do_patching    : %2d\n',do_patching);
fprintf(fid,'vac            : %12.4f\n',vac);
fprintf(fid,'reg_z          : %12.4e\n',reg_z);
fprintf(fid,'reg_vxc        : %12.4e\n\n\n',reg_vxc);
fclose(fid);

if one_step
    fprintf('\n**** XCPP runs for just one iteration ****\n')
end

nLocOrb = zeros(natom);
exc_atom = zeros(natom,1);
exc_atom_benchmark = zeros(natom,1);
%%


mix_type = 1; %1: potential mixing, 2: density mixing


%%
% ===================================
%            KS-DFT loop
% ===================================
for iter=1:maxiter
    
    fprintf('\n------ KS-DFT (XCEP) iter: %3d------\n\n',iter);
    
    %% solve KS equation
    [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
    fprintf('\n\nKS equation solved\n\n');
    fprintf('\neigenvalues and occupation numbers: \n');
    [occ,mu] = get_occ(norb,ee,q_total,tsmear,true);
    fprintf('Fermi level: %12.6f [patched vks]\n',mu);
    
    %% entropy
    [TS_total] = get_entropy(ngrid,occ,tsmear);
    
    if (mix_type == 2)
        vks_old3 = vks_old2;
        vks_old2 = vks_old;
        vks_old  = rho;
    end
    
    % new charge density
    rho = sum(ev.^2*occ,2);
    ref_rho = rho;
    
    if (mix_type==2)
        anderson_mixing_rho;
    end
    
    % get number of electrons on each atom via Becke-AIM
    [q_atom] = compute_atom_charge(natom,x,atom_weight,rho);
    
    % plot new density
    figure('Visible','off');hold on;plot(x,rho);
    tmp2 = zeros(size(coord));
    plot(coord,tmp2,'ro');legend('density');
    print('-depsc2','-r300','new_density.eps');
    
    % kinetic energy
    old_ke = ke;
    ke = 0.0;
    for iband = 1:norb
        tmpke = ee(iband) - dot(ev(:,iband),ev(:,iband).*vks)*h;
        ke = ke + tmpke*occ(iband);
    end
    % Hartree
    [eh,vhart] = cal_hartree(x, rho);
    
    
    %% benchmark results (vks is not from patching) for comparison only
    if iter>=2 && do_patching
        [ee_benmk,ev_benmk] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_benchmark);
        [occ_benmk,mu_benmk] = get_occ(norb,ee_benmk,q_total,tsmear,true);
        fprintf('Fermi level: %12.6f [using vks_benchmark = vhart + vext + vrpa0 + vexx0]\n\n',mu_benmk);
    end
    
    %% localization (boys)
    if do_patching && localizeOrbital
        fprintf('\nperforming localization ...\n');
        % how many occupied orbitals to select?
        occ_tol = 1e-8;
        norb_localize = 0;
        for i=1:norb
            if occ(i)<2.0-occ_tol && occ(i)>occ_tol
                disp('occ must be 2.0 or 0.0! ')
                occ(i)
                stop
            else
                if abs(occ(i)-2.0)<occ_tol
                    norb_localize = norb_localize + 1;
                end
            end
        end
        fprintf('norb_localize: %d\n\n',norb_localize);
        %%%%[locWfr,locOcc] = localization_MOs_fracOcc(x,ev(:,1:norb_localized));
        [locWfr] = localization_MOs(x,ev(:,1:norb_localize));
        fprintf('\nBoys localization is done. \n');
        
        % plotting ....
        figure('Visible','off');
        for i=1:norb_localize
            hold on;
            plot(x,locWfr(:,i));
        end
        tmp2 = zeros(size(coord));
        plot(coord,tmp2,'rx');
        title('localized orbitals')
        print('-depsc2','-r300','locWfr_Boys.eps');
        if iter==1
            save -ascii locWfr.txt locWfr;
        else
            save -ascii locWfr_iter0.txt locWfr;
        end
    end
    
    
    %% Exchange & RPA energy and potential
    vrpa = zeros([ngrid,1]);
    vexch = zeros([ngrid,1]);
    rpa_energy = 0.0;
    ex = 0.0;
    
    if do_patching == false
        if do_exx
            % EXX
            if use_acfd_exx
                [ex] = calc_exx_energy(ev,ee,occ,x);
            else
                [ex] = calc_HF_energy(ev,ee,occ,x);
            end
            level_shift = false;
            [vexch] = calc_exx_potential(x,vks,q_total,q_total,tsmear,norb,...
                false,use_acfd_exx,level_shift,v_LS,false,mu);
        else
            % LDA exchange & correlation
            [ex,vexch] = cal_ex(x,rho);
            [ecLDA,vcorrLDA] = cal_LDA_correlation(x,rho);
        end
        % RPA potential and energy
        if (do_rpa)
            [rpa_energy,rpa_eps] = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,true,mu,tsmear);
            level_shift = false;
            fd_chi = false;
            use_total_chi = false;
            vrpa = calc_rpa_potential(vks,norb,tsmear,omega_max,...
                q_total,q_total,nfreq,x,fd_chi,level_shift,v_LS,use_total_chi,mu,reg_vxc);
        end
    end
    %%
    
    
    %%
    % ================
    %  Start patching
    % ================
    if (do_patching)
        
        %%
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % compute benchmarks
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        fprintf('\ncomputing benchmark dE_exx/dvks...\n');
        % benchmark EXX energy and potential
        levelShift = false;
        use_total_chi = false;
        [vexx0,dEdV0_exx] = calc_exx_potential(x,vks,q_total,q_total,tsmear, ...
            norb,false,use_acfd_exx,levelShift,v_LS,use_total_chi,mu,reg_vxc);
        if use_acfd_exx
            [ex0,exx_eps0] = calc_exx_energy(ev,ee,occ,x);
        else
            [ex0,exx_eps0] = calc_HF_energy(ev,ee,occ,x);
        end
        fprintf('total system benchmaark EXX: %16.6f\n',ex0);
        
        % benchmark RPA potential.
        vrpa0 = zeros(ngrid,1);
        rpa0  = 0.0;
        if (do_rpa)
            fprintf('\ncomputing benchmark RPA potential ...\n');
            use_total_chi = false;
            [vrpa0,dEdV0_rpa] = calc_rpa_potential(vks,norb,tsmear,omega_max,...
                q_total,q_total,nfreq,x,false,false,v_LS,use_total_chi,mu,reg_vxc);
            % RPA energy
            [rpa0,rpa_eps0] = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,true,mu,tsmear);
            fprintf('total system benchmark RPA energy: %16.6f\n',rpa0);
        end
        vxc0 = vrpa0 + vexx0;
        %%
        
        % solve the response equation of the system
        if (fix_fermi)
            [chi_system] = calc_chi0_finite_diff_fix_fermi(norb,box_len,mu,vks,h,tsmear);
        else
            [chi_system] = calc_chi0_finite_diff(norb,box_len,vks,q_total,h,tsmear,false,v_LS);
        end
        %%
        
        %--------------------------------
        % working on each cluster
        %--------------------------------
        dErpa_dV_tmp = zeros([ngrid,natom]);
        dExx_dV_tmp = zeros(ngrid,natom);
        exx_eps = 0.0;
        rpa_eps = 0.0;
        
        for ia=1:natom
            
            fprintf('\n\n >>> working on atom: %d <<< \n\n',ia);
            
            %% ------------------------------------
            % Density localization
            % -------------------------------------
            fprintf('vac: %12.4f\n', vac);            
            % clu and env truncated KS potential
            vks_clu = clu_weight(:,ia).*vks + (1-clu_weight(:,ia))*(mu + vac);
            vks_env = env_weight(:,ia).*vks + (1-env_weight(:,ia))*(mu + vac);
            % estimate electron number in clu and env
            q_clu_list(ia) = sum(ref_rho.*clu_weight(:,ia))*(x(2)-x(1));
            q_env_list(ia) = q_total - q_clu_list(ia);
            
            fprintf('running DFET, comm_chempot: %d\n',comm_chempot);
            % BFGS minimize (-W) functional
            vemb = zeros(ngrid,1);
            f_handler = @(vemb)(W_density(vemb,nspin,x,comm_chempot,box_len, ...
                ngrid,norb,sub_tsmear,q_total,q_clu_list(ia),q_env_list(ia),...
                vks_clu,vks_env,ref_rho));
            options = optimset('GradObj','on','Display','Iter','MaxIter',10000);
            [vemb,final_W] = fminlbfgs(f_handler,vemb,options);
            
            % Get the cluster info
            [W,g,rho_clu,rho_env,Ef_emb] = W_density(vemb,nspin,x,comm_chempot,box_len,...
                ngrid,norb,sub_tsmear,q_total,q_clu_list(ia),q_env_list(ia),...
                vks_clu,vks_env,ref_rho);
            %plot(x,rho_clu,'b*',x,rho_env,'ro',x,ref_rho,'k-');
            fprintf('max(abs(rho_diff)): %e\n',max(abs(rho_clu+rho_env-ref_rho)));
            
            % Reconstruct cluster's KS system
            q_clu = sum(rho_clu)*h;
            q_env = q_total - q_clu;
            fprintf('q_clu: %f  q_env: %f [cluster_ID: %3d]\n', q_clu,q_env,ia);
            [ee_clu,ev_clu] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_clu+vemb);
            [occ_clu,mu_cluster] = get_occ(norb,ee_clu,q_clu,tsmear,false);
            
            % zmp
            
            %%
            
            
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            %  cluster's EXX and RPA energy densities
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            if do_exx
                if use_acfd_exx
                    [extmp,exx_eps_clu(:,ia)] = calc_exx_energy(ev_clu,ee_clu,occ_clu,x);
                else
                    [extmp,exx_eps_clu(:,ia)] = calc_HF_energy(ev_clu,ee_clu,occ_clu,x);
                end
            end
            if do_rpa
                [e_tmp,rpa_eps_clu(:,ia)] = compute_rpa_energy(...
                    omega_max,nfreq,x,ev_clu,ee_clu,occ_clu,true,mu_cluster,tsmear);
            end
            %%
            
            
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            %  dExc/dVks for EXX and RPA
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            if do_exx
                xc_type = 1; % EXX
                [dExx_dV_tmp(:,ia),y_exx(:,ia),h_exx(:,ia)] = ...
                    compute_dExc_dVks_cluster_NEW(range_sep,Usr,Ulr,nlambda,rc,ia,xc_type,xcep_comm_ef, ...
                    fix_fermi,tsmear,Ef_emb,q_clu,q_env,q_total,box_len,x,atom_weight,...
                    vks,vks_clu,vks_env,vemb,...
                    clu_weight,env_weight,chi_system,nfreq,omega_max,reg_z);
            end
            if do_rpa
                xc_type = 2; % RPA
                [dErpa_dV_tmp(:,ia),y_rpa(:,ia),h_rpa(:,ia)] = ...
                    compute_dExc_dVks_cluster_NEW(range_sep,Usr,Ulr,nlambda,rc,ia,xc_type,xcep_comm_ef, ...
                    fix_fermi,tsmear,Ef_emb,q_clu,q_env,q_total,box_len,x,atom_weight,...
                    vks,vks_clu,vks_env,vemb,...
                    clu_weight,env_weight,chi_system,nfreq,omega_max,reg_z);
            end
            
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            % assemble EXX and RPA energy density
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            if (do_exx)
                exx_eps = exx_eps + exx_eps_clu(:,ia).*atom_weight(:,ia);
            end
            if (do_rpa)
                rpa_eps = rpa_eps + rpa_eps_clu(:,ia).*atom_weight(:,ia);
            end
            
        end % loop over atoms
        
        % get dE_EXX/dV
        figure
        dExx_dVks = sum(dExx_dV_tmp,2);
        plot(x,dExx_dVks,x,dEdV0_exx);
        plot2file('xcep_dEdV_EXX_compare.eps',x,[dExx_dVks,dEdV0_exx],'dEXX/dV compare');
        
        % get dE_RPA/dV
        dErpa_dVks = sum(dErpa_dV_tmp,2);
        if do_rpa
            figure
            plot(x,dErpa_dVks,x,dEdV0_rpa)
            plot2file('xcep_dEdV_RPA_compare.eps',x,[dErpa_dVks,dEdV0_rpa],'dRPA/dV compare');
            vtmp1 = dErpa_dVks + dExx_dVks;
            vtmp2 = dEdV0_rpa + dEdV0_exx;
            vtmp3 = [x,vtmp2,vtmp1];
            save -ascii xcep_dEdVxc_compare.txt vtmp3;
        end
        
        
        %~~~~~~~~~~~~~~~~~~~~~~~~~
        % get the EXX potential
        %~~~~~~~~~~~~~~~~~~~~~~~~~
        dExx_dVks = dExx_dVks - sum(dExx_dVks)/ngrid;
        reg_lambda = 1e-4;
        tol = 1e-16;
        maxiter = 10000;
        vexx_xcep = cgls(chi_system,dExx_dVks,reg_lambda,tol,maxiter);
        vexx_xcep = vexx_xcep / h;
        % plot
        figure;
        plot(x,vexx0,x,vexx_xcep)
        title('V_{EXX} compare');
        plot2file('xcep_vexx_compare.eps',x,[vexx0,vexx_xcep],'V_{EXX} Compare');
        
        
        %~~~~~~~~~~~~~~~~~~~~~
        % get RPA potentail
        %~~~~~~~~~~~~~~~~~~~~~
        if do_rpa
            dErpa_dVks = dErpa_dVks - sum(dErpa_dVks)/ngrid;
            reg_lambda = 1e-4;
            tol = 1e-16;
            maxiter = 10000;
            vrpa_xcep = cgls(chi_system,dErpa_dVks,reg_lambda,tol,maxiter);
            vrpa_xcep = vrpa_xcep / h;
            % -------- plot -----------
            % RPA
            figure;
            plot(x,vrpa0,x,vrpa_xcep);title('vrpa compare')
            plot2file('xcep_vrpa_compare.eps',x,[vrpa0,vrpa_xcep],'V_{RPA} compare');
            % EXX+RPA
            figure
            vxc_xcep = vrpa_xcep + vexx_xcep;
            plot(x,vxc0,x,vxc_xcep)
            title('vrpa+vexx compare')
            plot2file('xcep_vxc_compare.eps',x,[vxc0,vxc_xcep],'Vxc compare');
            vtmp = [x,vxc0,vxc_xcep];
            save -ascii xcep_vxc_compare.txt vtmp;
        else
            vxc_xcep = vexx_xcep;
        end
        
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % get the total EXX and RPA energy (sum up)
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        ex = sum(exx_eps)*(x(2)-x(1));
        rpa_energy = sum(rpa_eps)*(x(2)-x(1));
        fprintf('patched rpa_energy: %12.6f \n',rpa_energy);
        fprintf('patched exx_energy: %12.6f \n',ex);
        
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % EXX and RPA energy per atom
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        for ia=1:natom
            exc_atom(ia) = sum((exx_eps+rpa_eps).*atom_weight(:,ia))*(x(2)-x(1));
            exc_atom_benchmark(ia) = sum((rpa_eps0+exx_eps0).*atom_weight(:,ia))*(x(2)-x(1));
        end
        
        % backup for Harris functional
        vxc_old   = vxc_xcep;
        vhart_old = vhart;
        system_rho_old = ref_rho;
        
        atom_exc_analysis
        
    end    
    % end of patching
    %~~~~~~~~~~~~~~~~
    
    
    
    %% ===============================
    %    Total energy & Harris energy
    %=================================
    old_etotal = etotal;
    etotal     = ke + ex  + rpa_energy + eh + dot(rho,vext)*h + e_ion - TS_total;
    
    % Harris functional
    vks_tmp = vxc_xcep + vhart + vext;
    [ee_tmp,ev_tmp]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_tmp);
    [occ_tmp,mu_tmp] = get_occ(norb,ee_tmp,q_total,tsmear,false);
    ee_sum = sum(ee_tmp.*occ_tmp); % band energy
    
    e_harris = ee_sum ...
        - sum(vxc_xcep.*ref_rho)*h ...
        - 0.5*sum(vhart.*ref_rho)*h ...2q
        + ex + rpa_energy ...
        + e_ion - TS_total;
    
    fprintf('\n\nkinetic:       %14.6f\n',ke);
    fprintf('exchange:      %14.6f   exx0: %14.6f \n',ex,ex0);
    fprintf('ecorr:         %14.6f   rpa0: %14.6f \n',rpa_energy,rpa0);
    fprintf('ehartr:        %14.6f\n',eh);
    fprintf('e_external:    %14.6f\n',dot(rho,vext)*h);
    fprintf('e_ion:         %14.6f\n',e_ion);
    fprintf('-TS:           %14.6f\n',-TS_total);
    fprintf('--------------------------------\n');
    fprintf('etotal(sum)  : %14.6f\n',etotal);
    fprintf('harris energy: %14.6f\n',e_harris);
    fprintf('diff:          %14.6f\n',etotal - e_harris);
    
    
    
    %% Forces
    force = compute_force(ngrid,natom,x,coord,...
        dAtomW_dR,dClusterW_dR,exx_eps_clu,atom_Z,h_exx+h_rpa,ion_soft,rho);
    %%

    
    stop    
    
end







