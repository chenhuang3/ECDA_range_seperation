function [ exx, eps ] = calc_exx_energy( ev, ee, occ, x, acfd)

  nband = size(ev,2);
  ngrid = size(ev,1);
  dx = x(2)-x(1);
  
  % make Coulumb matrix
  coul = zeros(ngrid);   
  for q=1:ngrid
      for q2=1:ngrid
          dist = x(q)-x(q2);
          coul(q,q2) = 1.0/sqrt(dist*dist + 1.0);
      end
  end
    
  exx =  0.0;
  
  %%% code is not spin polarized %%%%%%%%
  eps = zeros(ngrid,1);
  
  for ib=1:nband
      for ib2=1:nband
          factor = (1-sign(ee(ib2)-ee(ib)));
          if occ(ib)<1e-12 || factor < 1e-12
              continue
          end
          vec1 = ev(:,ib).*ev(:,ib2);        
          vec2 = coul*vec1*dx;
          eps = eps - occ(ib)/2.0*factor*vec1.*vec2;
          exx = exx - occ(ib)/2.0*factor*sum(vec1.*vec2)*dx;           
      end
  end
  
  %fprintf('exx energy: %12.6f\n',exx);
  
end

