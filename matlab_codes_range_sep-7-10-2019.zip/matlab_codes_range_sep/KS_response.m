function [ chi ] = KS_response( occ, phi )

 % compute the KS linear response function 
 % phi: KS orbitals
 % occ: occupation numbers
 % chi: response function
 
end

