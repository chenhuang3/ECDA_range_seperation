
function [ vcpot, dEdV ] = calc_rpa_potential_rs(part,Usr,Ulr,nlambda,rc,vks,norb,tsmear,omega_max,...
    q_cluster,q_total,nfreq,x,fd_chi,levelShift,v_LS,use_total_chi,mu,reg_vxc)



fprintf('\n\n>>> enter calc_rpa_potential_rs <<<...\n');
fprintf(' part: %s\n',part);
fprintf(' chemical potential: %f\n',mu);
fprintf(' omega_max: %12.5f  \nnfreq: %4d\n',omega_max,nfreq);
fprintf(' level_shift: %d  \nuse_total_chi: %d\n',levelShift,use_total_chi);

h = x(2)-x(1);
box_len = x(end);
ngrid = size(x,1);
print = false;
match_IE = true;
nbuffer = 5;

omega_tiny = 1e-6;
analytical_method = true;


%~~~~~~~~~~~~~~~~~~~~~
% compute dE/dV
%~~~~~~~~~~~~~~~~~~~~~

% finite difference method
[ dEdV ] = calc_rpa_dEdV_rs(part,Usr,Ulr,ngrid,norb,omega_max,nfreq,...
    tsmear,q_cluster,x,vks,h,box_len,levelShift,v_LS,nlambda,rc);
dEdV_fd = dEdV;



%===========================================================================
% compute static KS response:
% chi(r,r') = d rho(r') / d vks(r)
% chi computed from calc_chi0_finite_diff() is different from that
% from calc_chi(), since it has been normalized by the volume element 'h'.
%===========================================================================
if fd_chi
    fprintf('Use finite difference to compute chi_static for integer occ.\n')
    [ chi ] = calc_chi0_finite_diff(norb,box_len,vks,q_cluster,h,tsmear,levelShift,v_LS);
else
    fprintf('Analytical way for computing chi_static.\n')
    if levelShift
        if use_total_chi
            fprintf('\nUse reponse of total system to avoid null space of response of subsystem ***\n');
            [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
            [occ,mu] = get_occ(norb,ee,q_total,tsmear,false);
            [ chi ]  = calc_chi(mu, tsmear, ev, ee, occ, omega_tiny);
        else
            fprintf('*** WARNING **** Use cluster reponse, be aware of its null space!!! *** \n');
            [ee,ev]  = solve_ks_eq_nloc_v(ngrid,norb,0.0,box_len,diag(vks)+v_LS);
            [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
            [ chi ]  = calc_chi(mu, tsmear, ev, ee, occ, omega_tiny);
        end
    else
        % density partitioning
        [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
        [occ,mu] = get_occ(norb,ee,q_cluster,tsmear,false);
        [ chi ]  = calc_chi(mu, tsmear, ev, ee, occ, omega_tiny);
    end
end
chi = (chi+chi')/2.0;


%===============================================
% Solve OEP equation
%   dE_dV(r) = \int dr' chi(r,r')*dE/dn(r)
%
% CGLS method with regularization
% http://web.stanford.edu/group/SOL/software/cgls
%===============================================

fprintf('  solve v_rpa using CGLS\n');
fprintf('  reg. parameter -> reg_vxc: %f\n',reg_vxc);

tol     = 1e-16;
maxiter = 10000;
pot = cgls(chi,dEdV,reg_vxc,tol,maxiter);
pot = pot/h;
vcpot = pot;

fprintf('done calc_rpa_potential_rs()\n\n');

end


