%
%  solve Ax=b with lsqr() method
%  regularizing the gradient of solution x. 
%  lamdba: penalty coefficient  
%  A: square matrix 
%

function [x] = lsqr_reg(A,b,lambda,tol,maxiter)

n = size(A,1);

%lambda = 10;

fprintf('\nRegularized lsqr_reg() is used. lambda: %e. To regularize |x|!!!! \n\n',lambda);


% regularizing the gradient does not work! 
% you must use the standard Tikhonov regularization method 
% which regularize the norm of solution |x|

% just the identity matrix to measure the norm of the x
grad = eye([n,n]);


% gradient operator (a linear operator)
%grad = zeros([n,n]);
%for i=1:n
%    if i==1
%        % x1-x3)
%        grad(1,1)=1;
%        grad(1,2)=-1;
%        grad(1,3:n)=0.0;
%    elseif i==n
%        grad(n,1:n-2)=0.0;
%        grad(n,n-1)=1.0;
%        grad(n,n)=-1.0;
%    else
%        grad(i,1:n)=0.0;
%        grad(i,i-1)=1/2;
%        %grad(i,i+1)=-1/2;
%        grad(i,i)  =-1/2;
%        %grad(i,i-1) = 1.0;
%        %grad(i,i+1) = 1.0;
%        %grad(i,i) = -2.0;
%    end
%end

AA = [A;lambda*grad];
bb = [b;zeros(n,1)];
x = lsqr(AA,bb,tol,maxiter);

grad_norm = norm(grad*x);  % |gradient of x|
match = norm(A*x-b);

%grad_norm  

end
