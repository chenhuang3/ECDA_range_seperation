% ============================================================================
%  exchange correlation potential patching code
% ============================================================================
fprintf('\n\n\n  ==> performing xcpp version (7/9/2019) <== \n\n')

max_iter_opt_fermi = 1000;

%=====================
% check parameters
%=====================
if (comm_chempot == true )
    fprintf('no longer use DFET to get cluster and env charges, set comm_chempot to false!\n');
    fprintf('clu and env electron numbers are determined by Becke weights.\n');
    stop
end


[atom_weight,clu_weight,env_weight,dAtomW_dR,dClusterW_dR] = ...
    make_weights(natom,ngrid,coord,x,do_plot,rho,buffer);

save -ascii x_coordiate.txt x

fprintf('coordinates: \n')
coord


%% initialization for ECDA
%=========================
rpa_atom = zeros(natom,1);
exx_atom = zeros(natom,1);
exc_atom = zeros(natom,1);

exc_atom_benchmark = zeros(natom,1);
exx_atom_benchmark = zeros(natom,1);
rpa_atom_benchmark = zeros(natom,1);

dEdV_exx_patched = zeros(ngrid,1);
dEdV_rpa_patched = zeros(ngrid,1);
q_clu_list = zeros(natom,1);
q_env_list = zeros(natom,1);
exx_eps = zeros(ngrid,1);
rpa_eps = zeros(ngrid,1);
dExc_dVks = zeros([ngrid,1]);
exx_eps0 = zeros(ngrid,1);
rpa_eps0 = zeros(ngrid,1);
ex0 = 0;  % benchmark of exx energy of total system
rpa0 = 0; % benchmark of rpa energy of total system
v_LS = zeros([ngrid,ngrid]);


bar_clu_Ef = zeros(natom); % store the chemical potential of cluster 
bar_env_Ef = zeros(natom);     % store the chemical potential of environment


exx_eps_clu = zeros(ngrid,natom);
rpa_eps_clu = zeros(ngrid,natom);
deps_dN_clu_EXX = zeros(ngrid,natom);
deps_dN_clu_RPA = zeros(ngrid,natom);

h_exx = zeros(ngrid,natom);
h_rpa = zeros(ngrid,natom);
zg_exx = zeros(natom,natom);  % first index: cluster, 2nd index: atom {R}
zg_rpa = zeros(natom,natom);  % first index: cluster, 2nd index: atom {R}


vks_old = vks;
vks_old2 = vks;
vks_old3 = vks;

ngrid = size(x,1);
h = x(2)-x(1);                      % grid spacing
tol_ksdft = 1e-5;                   % tolerance for stopping KSDFT
old_ke = 0.0;                       % for convergence test
old_etotal  = 0.0;
old_etotal2 = 0.0;
ke = 0.0;                           % for convergence test
ecorr = 0.0;                        % correlation energy
iter = 0;                           % iter number
resid1 = zeros([length(vext),1]);   % for Anderson mixing
vxc_cluster = zeros(ngrid,natom);   % store vxc of each cluster
etotal = -1;



% compute short-range and long-range Coulomb potential in fourier space
if (range_sep)
    [Usr, Ulr] = make_Ulr_Usr(ngrid,rc,soft_coul,x);
end


fid = fopen('iteration_epp.txt','w');
program_info(fid);
fprintf(fid,'---- parameters ---- \n');
fprintf(fid,'ngrid          : %4d\n',ngrid);
fprintf(fid,'natom          : %4d\n',natom);
fprintf(fid,'q_total        : %8.2f\n',q_total);
fprintf(fid,'box_len        : %8.4f\n',box_len);
fprintf(fid,'localizeOrb    : %2d\n', localizeOrbital);
fprintf(fid,'tsmear         : %8.4f (eV)\n',tsmear*27.2114);
fprintf(fid,'use_acfd_exx   : %2d\n',use_acfd_exx);
fprintf(fid,'omega_max      : %6.2f\n',omega_max);
fprintf(fid,'nfreq          : %3d\n',nfreq);
fprintf(fid,'do_exx         : %2d\n',do_exx);
fprintf(fid,'do_rpa         : %2d\n',do_rpa);
fprintf(fid,'do_patching    : %2d\n',do_patching);
fprintf(fid,'vac            : %12.4f\n',vac);
fprintf(fid,'reg_z          : %12.4e\n',reg_z);
fprintf(fid,'reg_vxc        : %12.4e\n\n',reg_vxc);
fclose(fid);

if one_step
    fprintf('\n**** XCPP runs for just one iteration ****\n')
end

%%



%===================================
%      ECDA loop
%===================================
for iter=1:maxiter
    
    fprintf('\n------ KS-DFT/ECDA iter: %3d------\n\n',iter);
    
    %% solve KS equation
    [ee,ev]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks);
    save -ascii vks.dat vks;

    fprintf('\n\nKS equation solved\n\n');
    if do_patching
      fprintf('\neigenvalues and occupation numbers (XCEP): \n');
    else 
      fprintf('\neigenvalues and occupation numbers: \n');
    end
    [occ,mu_system] = get_occ(norb,ee,q_total,tsmear,true);
    fprintf('Fermi level: %12.6f [patched vks]\n',mu_system);    

    % entropy
    [TS_total] = get_entropy(ngrid,occ,tsmear);    

    % new charge density
    rho = sum(ev.^2*occ,2);
    ref_rho = rho;

    % get d(Fermi)/d(vks)
    [dmu_dvks] = compute_dfermi_dvks(x,ee,ev,q_total,tsmear);    

    % get number of electrons on each atom via Becke-AIM
    [q_atom] = compute_atom_charge(natom,x,atom_weight,rho);
    
    % plot new density
    figure('Visible','off');hold on;plot(x,rho);
    tmp2 = zeros(size(coord));
    plot(coord,tmp2,'ro');legend('density');
    print('-depsc2','-r300','new_density.eps');
    
    % kinetic energy
    old_ke = ke;
    ke = 0.0;
    for iband = 1:norb
        tmpke = ee(iband) - dot(ev(:,iband),ev(:,iband).*vks)*h;
        ke = ke + tmpke*occ(iband);
    end

    [eh,vhart] = cal_hartree(x, rho); % Hartree energy
    
    
    %% benchmark results (vks is not from patching) for comparison only
    if iter>=2 && do_patching
        fprintf('\neigenvalues from benchmark (solve the system using global EXX+RPA potential\n')
        [ee_benmk,ev_benmk]  = solve_ks_eq(ngrid,norb,0.0,box_len,vks_benchmark);
        [occ_benmk,mu_benmk] = get_occ(norb,ee_benmk,q_total,tsmear,true);
        fprintf('Fermi level: %12.6f [using vks_benchmark = vhart + vext + vrpa0 + vexx0]\n\n',mu_benmk);
    end
    
    
    %% Exchange & RPA energy and potential
    vrpa  = zeros([ngrid,1]);
    vexch = zeros([ngrid,1]);
    rpa_energy = 0.0;
    ex = 0.0;   
    
    if do_patching == false
        if do_exx
            % EXX =============            
            if use_acfd_exx
                [ex,exx_eps] = calc_exx_energy(ev,ee,occ,x);
            else
                [ex] = calc_HF_energy(ev,ee,occ,x);
            end
            level_shift = false;
            [vexch] = calc_exx_potential(x,vks,q_total,q_total,tsmear,norb,...
                false,use_acfd_exx,level_shift,v_LS,false,mu_system,reg_vxc);
        else
            % LDA exchange & correlation
            [ex,vexch] = cal_ex(x,rho);
            [ecLDA,vcorrLDA] = cal_LDA_correlation(x,rho);
        end
        
        % RPA potential and energy
        if (do_rpa)
            [rpa_energy,rpa_eps] = compute_rpa_energy(omega_max,nfreq,x,...
                ev,ee,occ,true,mu_system,tsmear);
            
            level_shift = false;
            fd_chi = false;
            use_total_chi = false;
            vrpa = calc_rpa_potential(vks,norb,tsmear,omega_max,...
                q_total,q_total,nfreq,x,fd_chi,level_shift,v_LS,use_total_chi,mu_system,reg_vxc);
        end
    end
    
    
    %%
    %==================
    %  Start patching
    %==================
    if (do_patching)
        
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % compute benchmarks
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        fprintf('\ncomputing benchmark dE_exx/dvks...\n');

        % benchmark EXX energy and potential
        levelShift = false;
        use_total_chi = false;
        [vexx0,dEdV0_exx] = calc_exx_potential(x,vks,q_total,q_total,tsmear, ...
            norb,false,use_acfd_exx,levelShift,v_LS,use_total_chi,mu_system,reg_vxc);
        if use_acfd_exx
            [ex0,exx_eps0] = calc_exx_energy(ev,ee,occ,x);
        else
            [ex0,exx_eps0] = calc_HF_energy(ev,ee,occ,x);
        end
        fprintf('total system benchmaark EXX: %16.6f\n',ex0);
        
        
        % benchmark RPA potential.
        vrpa0 = zeros(ngrid,1);
        rpa0  = 0.0;
        if (do_rpa)
            fprintf('\ncomputing benchmark RPA potential ...\n');
            use_total_chi = false;
            [vrpa0,dEdV0_rpa] = calc_rpa_potential(vks,norb,tsmear,omega_max,...
                q_total,q_total,nfreq,x,false,false,v_LS,use_total_chi,mu_system,reg_vxc);
            
            % RPA energy
            [rpa0,rpa_eps0] = compute_rpa_energy(omega_max,nfreq,x,ev,ee,occ,true,mu_system,tsmear);
            fprintf('total system benchmark RPA energy: %16.6f\n',rpa0);            
        end
        vxc0 = vrpa0 + vexx0;
        %%
       
        [chi_system] = calc_chi0_finite_diff(norb,box_len,vks,q_total,h,tsmear,false,v_LS);
        

        %--------------------------------
        % working on each cluster
        %--------------------------------
        dErpa_dV_tmp = zeros([ngrid,natom]);
        dErpa_dV_tmp_part1 = zeros([ngrid,natom]);
        dErpa_dV_tmp_part2 = zeros([ngrid,natom]);
        dExx_dV_tmp = zeros(ngrid,natom);
        dExx_dV_tmp_part1 = zeros(ngrid,natom);
        dExx_dV_tmp_part2 = zeros(ngrid,natom);
        
        exx_eps = 0.0;
        rpa_eps = 0.0;
        
       
        % RPA energy and pot due to long-range RPA
        if (do_rpa && range_sep==true)
            [rpa_energy_lr,rpa_eps_lr] = compute_rpa_energy_rs('LR_KOHN',Usr,Ulr,omega_max,nfreq,x,...
                ev,ee,occ,true,mu_system,tsmear,nlambda,rc);

            [vrpa_lr,~] = calc_rpa_potential_rs('LR_KOHN',Usr,Ulr,nlambda,rc,vks,norb,tsmear,omega_max,...
                q_total,q_total,nfreq,x,false,false,v_LS,use_total_chi,mu_system,reg_vxc);
        end
        
        
        %%
        for ia=1:natom            
            fprintf('\n\n    ==> working on atom: %d <== \n\n',ia);   
            
            %=======================
            % Density localization
            %=======================            

            q_clu_list(ia) = sum(ref_rho.*clu_weight(:,ia))*(x(2)-x(1)); 
            q_env_list(ia) = q_total - q_clu_list(ia);
            fprintf('running DFET => comm_chempot: %d\n',comm_chempot);
            fprintf('                q_clu: %f\n',q_clu_list(ia))
            fprintf('                q_env: %f\n',q_env_list(ia))
            fprintf('vac: %12.4f Hartree\n', vac);
            
            %==================================
            % iteration on local fermi levels
            %==================================
            vemb = zeros(ngrid,1);      
            vks_clu = clu_weight(:,ia).*vks + (1-clu_weight(:,ia))*(mu_system + vac);
            vks_env = env_weight(:,ia).*vks + (1-env_weight(:,ia))*(mu_system + vac);
            
            % define W function
            f_handler = @(vemb)(W_density(vemb,nspin,x,comm_chempot,box_len, ...
                ngrid,norb,tsmear,q_total,q_clu_list(ia),q_env_list(ia),vks_clu,vks_env,ref_rho));
            
            % Optimize W
            optimizer = 1;
            if optimizer ==1
                % MATLAB optimizer
                %options = optimoptions('fminunc','Algorithm','trust-region',...
                options = optimoptions('fminunc','Algorithm','quasi-newton',...
                    'Display','none','GradObj','on', ... %'SpecifyObjectiveGradient',true,...
                    'MaxIter',400,'TolFun',1e-6);
                [vemb,final_W] = fminunc(f_handler,vemb,options);
            else
                % BFGS
                options = optimset('GradObj','on','Display','Iter','MaxIter',10000);
                [vemb,final_W] = fminlbfgs(f_handler,vemb,options);
            end
            
            % Get the cluster info
            [W,g,rho_clu,rho_env,Ef_emb,mu_clu_tmp,~] = W_density(vemb,nspin,x,comm_chempot,box_len,...
                ngrid,norb,tsmear,q_total,q_clu_list(ia),q_env_list(ia),vks_clu,vks_env,ref_rho);
            
            % Reconstruct cluster's KS system
            q_clu = sum(rho_clu)*h;
            q_env = q_total - q_clu;
            fprintf('after WY OEP: q_clu: %f  q_env: %f [cluster_ID: %3d]\n', q_clu,q_env,ia);
            [ee_clu,ev_clu] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_clu+vemb);
            [occ_clu,mu_cluster] = get_occ(norb,ee_clu,q_clu,tsmear,false);
            
            % cluster density
            cluster_rho = sum(ev_clu.^2*occ_clu,2);
            
            % get enviroment's KS system
            [ee_env,ev_env] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_env+vemb);
            [occ_env,mu_env] = get_occ(norb,ee_env,q_env,tsmear,false);
            
            [dmu_dvks_clu] = compute_dfermi_dvks(x,ee_clu,ev_clu,q_clu,tsmear);
            [dmu_dvks_env] = compute_dfermi_dvks(x,ee_env,ev_env,q_env,tsmear);

            
            %==========================================
            %  cluster's EXX and RPA energy densities
            %==========================================
            if do_exx
                if use_acfd_exx
                    [extmp,exx_eps_clu(:,ia)] = calc_exx_energy(ev_clu,ee_clu,occ_clu,x);
                else
                    [extmp,exx_eps_clu(:,ia)] = calc_HF_energy(ev_clu,ee_clu,occ_clu,x);
                end
            end
            if do_rpa
                if range_sep == false
                    % regular RPA
                    [e_tmp,rpa_eps_clu(:,ia)] = compute_rpa_energy(omega_max,nfreq,x,...
                        ev_clu,ee_clu,occ_clu,true,mu_cluster,tsmear);
                else
                    % short range RPA energy
                    [e_tmp,rpa_eps_clu(:,ia)] = compute_rpa_energy_rs('SR_ISO',Usr,Ulr,omega_max,nfreq,x,...
                        ev_clu,ee_clu,occ_clu,true,mu_cluster,tsmear,nlambda,rc);
                end
            end
            
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            % deps_cluster/dN_clu
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~            
            [deps_dN_clu_EXX(:,ia)] = compute_dExx_eps_dN(x,occ_clu,ee_clu,ev_clu);
            [deps_dN_clu_RPA(:,ia)] = compute_dRPA_eps_dN(range_sep,'SR_ISO',Usr,Ulr,nlambda,rc,...
                                        x,q_clu,omega_max,nfreq,tsmear,box_len,vks_clu+vemb);
            
            
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            % dRho_dN_cluster & dRho_dN_env
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            [dRho_dN_clu] = compute_drho_dN(vks_clu+vemb,ngrid,norb,box_len,tsmear,q_clu);
            [dRho_dN_env] = compute_drho_dN(vks_env+vemb,ngrid,norb,box_len,tsmear,q_env);
            
            
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            %  dExc/dVks for EXX and RPA
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            if do_exx
                xc_type = 1; % EXX
                [dExx_dV_tmp(:,ia),h_exx(:,ia),zg_exx(ia,:),dExx_dV_tmp_part1(:,ia),dExx_dV_tmp_part2(:,ia)] = ...
                    compute_dExc_dVks_cluster_NEW(range_sep,'SR_ISO',Usr,Ulr,nlambda,rc,...
                       natom,ia,xc_type,xcep_comm_ef,ref_rho, ...
                       tsmear,mu_system,vac,q_clu,q_env,q_total,...
                       box_len,x,atom_weight,dClusterW_dR,dmu_dvks,dRho_dN_clu,dRho_dN_env,...
                       deps_dN_clu_EXX(:,ia),vks,vks_clu,vks_env,vemb,clu_weight,env_weight,chi_system,nfreq,omega_max,reg_z);
            end
            if do_rpa
                xc_type = 2; % RPA
                [dErpa_dV_tmp(:,ia),h_rpa(:,ia),zg_rpa(ia,:),dErpa_dV_tmp_part1(:,ia),dErpa_dV_tmp_part2(:,ia)] = ...
                    compute_dExc_dVks_cluster_NEW(range_sep,'SR_ISO',Usr,Ulr,nlambda,rc,...
                       natom,ia,xc_type,xcep_comm_ef,ref_rho, ...
                       tsmear,mu_system,vac,q_clu,q_env,q_total,...
                       box_len,x,atom_weight,dClusterW_dR,dmu_dvks,dRho_dN_clu,dRho_dN_env,...
                       deps_dN_clu_RPA(:,ia),vks,vks_clu,vks_env,vemb,clu_weight,env_weight,chi_system,nfreq,omega_max,reg_z);
            end            
            
            
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            % patch EXX and RPA energy density
            %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            if (do_exx)
                eps_tmp = exx_eps_clu(:,ia).*atom_weight(:,ia);
                exx_eps = exx_eps + eps_tmp;
                exx_atom(ia) = sum(eps_tmp)*h;
                fprintf('atom_EXX_energy: %f\n', exx_atom(ia));
            end
            if (do_rpa)
                eps_tmp = rpa_eps_clu(:,ia).*atom_weight(:,ia);
                rpa_eps = rpa_eps + eps_tmp;                
                rpa_atom(ia) = sum(eps_tmp)*h;
                fprintf('atom_RPA_energy: %f\n',rpa_atom(ia));
            end            
            exc_atom(ia) = exx_atom(ia)+rpa_atom(ia);
            
        end 
        % end of loop over atoms
        %========================
        
        
        
        %%
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % get dE_EXX/dV
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~
        figure; title('dExx/dv_{KS} compare');        
        tmp2 = zeros(size(coord)); 
        dExx_dVks = sum(dExx_dV_tmp,2);
        plot(x,dExx_dVks,x,dEdV0_exx,coord,tmp2,'ko');
        legend('ECDA','benchmark','atoms')
        plot2file('xcep_dEdV_EXX_compare.eps',x,[dExx_dVks,dEdV0_exx],'dEXX/dV_{KS} compare');
        
        
        %~~~~~~~~~~~~~~~~~~~~~~~~~
        % get dE_RPA/dV
        %~~~~~~~~~~~~~~~~~~~~~~~~~
        dErpa_dVks = sum(dErpa_dV_tmp,2);
        if do_rpa
            figure
            tmp2 = zeros(size(coord)); 
            plot(x,dErpa_dVks,x,dEdV0_rpa,coord,tmp2,'ko')
            legend('ECDA','benchmark','atoms')
            title('dE_{rpa}/dv_{KS} compare')
            plot2file('xcep_dEdV_RPA_compare.eps',x,[dErpa_dVks,dEdV0_rpa],'dRPA/dv_{KS} compare');
            vtmp1 = dErpa_dVks + dExx_dVks;
            vtmp2 = dEdV0_rpa + dEdV0_exx;
            vtmp3 = [x,vtmp2,vtmp1];
            save -ascii xcep_dEdVxc_compare.txt vtmp3;
            save -ascii dEdV_rpa_benchmark.txt dEdV0_rpa;
            save -ascii dEdV_exx_benchmark.txt dEdV0_exx;
        end
                
        % analyze part1 and part2
        dExx_dV_part1  = sum(dExx_dV_tmp_part1,2);
        dExx_dV_part2  = sum(dExx_dV_tmp_part2,2);
        dErpa_dV_part1 = sum(dErpa_dV_tmp_part1,2);
        dErpa_dV_part2 = sum(dErpa_dV_tmp_part2,2);

        save -ascii dExx_dV_part1.txt dExx_dV_part1;
        save -ascii dExx_dV_part2.txt dExx_dV_part2;
        save -ascii dErpa_dV_part1.txt dErpa_dV_part1;
        save -ascii dErpa_dV_part2.txt dErpa_dV_part2;
        
        
        %~~~~~~~~~~~~~~~~~~~~~~~~~
        % get the EXX potential
        %~~~~~~~~~~~~~~~~~~~~~~~~~
        dExx_dVks = dExx_dVks - sum(dExx_dVks)/ngrid;
        tol = 1e-16;
        maxiter = 10000;
        vexx_xcep = cgls(chi_system,dExx_dVks,reg_vxc,tol,maxiter);
        vexx_xcep = vexx_xcep / h;
        % plot
        figure;
        plot(x,vexx0,x,vexx_xcep)
        legend('ecda','benchmark')
        hold on
        tmp2 = zeros(size(coord));
        plot(coord,tmp2,'ro');
        title('v_{exx} compare');
        plot2file('xcep_vexx_compare.eps',x,[vexx0,vexx_xcep],'V_{EXX} Compare');
        
        
        %~~~~~~~~~~~~~~~~~~~~~
        % get RPA potentail
        %~~~~~~~~~~~~~~~~~~~~~
        if do_rpa
            dErpa_dVks = dErpa_dVks - sum(dErpa_dVks)/ngrid;
            tol = 1e-16;
            maxiter = 10000;
            vrpa_xcep = cgls(chi_system,dErpa_dVks,reg_vxc,tol,maxiter);
            vrpa_xcep = vrpa_xcep / h;
            if (range_sep) 
               fprintf('\n ==== added long-range rpa potential to vrpa ===== \n')
               vrpa_sr = vrpa_xcep;
               vrpa_xcep = vrpa_xcep + vrpa_lr;
            end
            % EXX+RPA
            if range_sep == false 
               vxc_xcep = vrpa_xcep + vexx_xcep;
            else 
               vxc_xcep = vrpa_xcep + vexx0;
            end 

            % plot v_RPA
            figure;
            plot(x,vrpa0,x,vrpa_xcep);
            hold on; tmp2 = zeros(size(coord)); plot(coord,tmp2,'ro');
            title('vrpa compare')
            plot2file('xcep_vrpa_compare.eps',x,[vrpa0,vrpa_xcep],'V_{RPA} compare');
            % long-range and short-range RPA pot
            if (range_sep==true)
               figure('Visible','off');
               plot(x,vrpa_sr,'r-',x,vrpa_lr,'b-',x,vrpa_xcep,'k-');
               title('compare vrpa, vrpa_{sr}, vrpa_{lr}')
               legend('vrpa_{sr}','vrpa_{lr}','vrpa_{total}');
               print('-depsc2','-r300','vrpa_sr_lr_compare.eps');
               figure('Visible','on');
            end 
            % plot v_xc
            figure
            plot(x,vxc0,x,vxc_xcep)
            hold on; tmp2 = zeros(size(coord)); plot(coord,tmp2,'ro');
            if range_sep == false 
               title('vrpa + vexx compare')
            else 
               title('vrpa + vexx0 compare')
            end
            plot2file('xcep_vxc_compare.eps',x,[vxc0,vxc_xcep],'Vxc compare');
            vtmp = [x,vxc0,vxc_xcep];
            save -ascii xcep_vxc_compare.txt vtmp;
        else
            vxc_xcep = vexx_xcep;
        end
        %%
        
        
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % get the total EXX and RPA energy (sum up)
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        ex = sum(exx_eps)*(x(2)-x(1));
        if (range_sep==false)
            rpa_energy = sum(rpa_eps)*(x(2)-x(1));
        else
            rpa_energy = sum(rpa_eps)*(x(2)-x(1)) + rpa_energy_lr;
        end
        fprintf('patched rpa_energy: %12.6f   benchmark rpa0: %12.6f\n',rpa_energy,rpa0);
        fprintf('patched exx_energy: %12.6f   benchmark ex0:  %12.6f\n',ex,ex0);
        
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        % EXX and RPA energy per atom
        %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        for ia=1:natom
            exc_atom_benchmark(ia) = sum((rpa_eps0+exx_eps0).*atom_weight(:,ia))*(x(2)-x(1));
            rpa_atom_benchmark(ia) = sum((rpa_eps0).*atom_weight(:,ia))*(x(2)-x(1));
            exx_atom_benchmark(ia) = sum((exx_eps0).*atom_weight(:,ia))*(x(2)-x(1));
        end
        
        % backup for Harris functional
        vxc_old   = vxc_xcep;
        vhart_old = vhart;
        system_rho_old = ref_rho;
        
        atom_exc_analysis
    end    
    % end of patching
    %======================

    
    
    
    %%
    %=================================
    %    Total energy & Harris energy
    %=================================
    old_etotal2 = old_etotal;
    old_etotal  = etotal;

    if (do_patching & range_sep==true)
        etotal = ke + ex0 + rpa_energy + eh + dot(rho,vext)*h + e_ion - TS_total;
    else 
        etotal = ke + ex + rpa_energy + eh + dot(rho,vext)*h + e_ion - TS_total;
    end
    
    fprintf('\n\nkinetic:       %14.6f\n',ke);
    fprintf('exchange:      %14.6f   exx0: %14.6f  diff: %14.6f\n',ex,ex0,ex-ex0);
    fprintf('ecorr:         %14.6f   rpa0: %14.6f  diff: %14.6f\n',rpa_energy,rpa0,rpa_energy-rpa0);
    fprintf('ehartr:        %14.6f\n',eh);
    fprintf('e_external:    %14.6f\n',dot(rho,vext)*h);
    fprintf('e_ion:         %14.6f\n',e_ion);
    fprintf('-TS:           %14.6f\n',-TS_total);
    fprintf('--------------------------------\n');
    fprintf('etotal(sum)  : %14.6f\n',etotal);
       
    
    %% Forces
    force = compute_force(ngrid,natom,x,coord,...
        atom_weight,dAtomW_dR,dClusterW_dR,clu_weight,exx_eps_clu,atom_Z,...
        deps_dN_clu_EXX+deps_dN_clu_RPA,h_exx+h_rpa,zg_exx+zg_rpa,ion_soft,rho);
    
    plotting;
    
    % potential mixing
    vks_old3 = vks_old2;
    vks_old2 = vks_old;
    vks_old  = vks;
    
    % >>>>> new KS potential <<<<<
    if (do_patching)
        vks = vxc_xcep + vhart + vext;
        % make the benchmark vks
        vks_benchmark = vxc0 + vhart + vext;
    else
        % Ordinary KS-DFT
        vks = vrpa + vhart + vexch + vext;
        save -ascii benchmark_vrpa.txt vrpa;
        save -ascii benchmark_vexx.txt vexch;
    end
    
    % Anderson mixing of potential
    anderson_mixing;
    
    [conv_flag] = output_iteration(maxiter,one_step,iter,resid1,etotal,...
        old_etotal,old_etotal2,ke,ex,rpa_energy,TS_total);
    
    if (conv_flag==1)
        break
    end
    
end
