%
% For given vks and v_emb, cluster's KS system is solved.
% chemical potentials between cluster and env can be equilibrated.
%

function [ee_clu,ev_clu,occ_clu] = get_cluster_fix_fermi(tsmear,...
    vks_clu,Ef_emb,box_len,vks,vemb)

ngrid = length(vks);
norb = ngrid;

[ee_clu,ev_clu] = solve_ks_eq(ngrid,norb,0.0,box_len,vks_clu+vemb);
[occ_clu] = get_occ_for_Ef(norb, ee_clu, tsmear, Ef_emb);

end
