%
% Give the spline object, it will compute the curvature at given points 
% input 
%    s: spline object (e.g. s=spline(x,y))
%    x: the points to compute curvature 
% output: 
%    kappa: curvature = 1/R
%    A1: first derivative
%    A2: second derivative
%
% Ref: https://www.mathworks.com/matlabcentral/newsreader/view_thread/261628

function [ kappa, A1, A2 ] = get_curvature(s,x)

% first derivative, pp form
s1 = s;
s1.order = s.order-1; 
s1.coefs = bsxfun(@times, s.coefs(:,1:end-1), s1.order:-1:1);

% second derivative, pp form
s2 = s1;
s2.order = s1.order-1; 
s2.coefs = bsxfun(@times, s1.coefs(:,1:end-1), s2.order:-1:1);

% Evaluate the curvature
% 100 points cover the same interval 
A1 = ppval(s1,x); % first derivative at x
A2 = ppval(s2,x); % second derivative at x
% curvature
kappa = A2./(1 + A1.^2).^(3/2);

end