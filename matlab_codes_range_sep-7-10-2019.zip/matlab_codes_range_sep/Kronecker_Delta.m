function [q] = Kronecker_Delta(m,n)
  if m == n
      q = 1;
  else
      q = 0;
  end
end